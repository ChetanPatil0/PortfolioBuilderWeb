
// import React, { useState, useEffect } from 'react';
// import { useAuth } from '../context/AuthContext';
// import portfolioService from '../services/portfolioService';
// import { useMessageModal } from '../context/MessageModalContext';
// import {
//   FiMonitor, FiTablet, FiSmartphone, FiRefreshCw, FiExternalLink,
//   FiSave, FiTrash2, FiPlus, FiChevronDown, FiChevronUp,
//   FiUser, FiInfo, FiBriefcase, FiBookOpen, FiCode, FiStar, FiMessageSquare, FiMail,
//   FiSettings,
// } from 'react-icons/fi';
// import PortfolioPreview from './PortfolioPreview';

// export default function PortfolioEditor() {
//   const { portfolio, refreshPortfolio, user } = useAuth();
//   const { showMessage } = useMessageModal();

//   const [expanded, setExpanded] = useState({ hero: true });
//   const [viewMode, setViewMode] = useState('desktop');
//   const [localPortfolio, setLocalPortfolio] = useState(null); // ← full object now
//   const [saving, setSaving] = useState(false);

//   // Initialize with FULL portfolio object from API (includes theme, settings, etc.)
//   useEffect(() => {
//     if (portfolio) {
//       setLocalPortfolio(JSON.parse(JSON.stringify(portfolio))); // deep copy
//     }
//   }, [portfolio]);

//   const toggleExpand = (key) => {
//     setExpanded(prev => ({ ...prev, [key]: !prev[key] }));
//   };

//   // Update ONLY the specific section inside localPortfolio.sections
//   const handleChange = (sectionKey, field, value, index = null) => {
//     setLocalPortfolio(prev => {
//       if (!prev) return prev;
//       const copy = JSON.parse(JSON.stringify(prev));

//       if (!copy.sections) copy.sections = {};
//       if (!copy.sections[sectionKey]) copy.sections[sectionKey] = { enabled: true, data: {} };

//       if (index !== null) {
//         if (!Array.isArray(copy.sections[sectionKey].data)) copy.sections[sectionKey].data = [];
//         copy.sections[sectionKey].data[index] = {
//           ...copy.sections[sectionKey].data[index],
//           [field]: value
//         };
//       } else {
//         copy.sections[sectionKey].data = {
//           ...copy.sections[sectionKey].data,
//           [field]: value
//         };
//       }

//       return copy;
//     });
//   };

//   const addItem = (sectionKey) => {
//     setLocalPortfolio(prev => {
//       if (!prev) return prev;
//       const copy = JSON.parse(JSON.stringify(prev));

//       if (!copy.sections) copy.sections = {};
//       if (!copy.sections[sectionKey]) copy.sections[sectionKey] = { enabled: true, data: [] };
//       if (!Array.isArray(copy.sections[sectionKey].data)) copy.sections[sectionKey].data = [];

//       copy.sections[sectionKey].data.push({});
//       return copy;
//     });
//   };

//   const removeItem = (sectionKey, index) => {
//     setLocalPortfolio(prev => {
//       if (!prev) return prev;
//       const copy = JSON.parse(JSON.stringify(prev));

//       if (Array.isArray(copy?.sections?.[sectionKey]?.data)) {
//         copy.sections[sectionKey].data.splice(index, 1);
//       }
//       return copy;
//     });
//   };

//   const saveAll = async () => {
//     setSaving(true);
//     try {
//       const updates = {};
//       if (localPortfolio?.sections) {
//         Object.keys(localPortfolio.sections).forEach(key => {
//           updates[`sections.${key}`] = localPortfolio.sections[key];
//         });
//       }

//       await portfolioService.updatePortfolio(updates);
//       await refreshPortfolio();

//       showMessage({
//         type: 'success',
//         title: 'Saved Successfully',
//         message: 'Your portfolio has been updated.',
//         primaryButtonText: 'View Live',
//         onPrimaryPress: () => window.open(`${window.location.origin}/${user.username}`, '_blank'),
//       });
//     } catch (err) {
//       showMessage({
//         type: 'error',
//         title: 'Save Failed',
//         message: err.message || 'Could not save changes.',
//       });
//     } finally {
//       setSaving(false);
//     }
//   };

//   const renderField = (sectionKey, label, fieldKey, type = 'text', index = null) => {
//     let value = index !== null
//       ? localPortfolio?.sections?.[sectionKey]?.data?.[index]?.[fieldKey] ?? ''
//       : localPortfolio?.sections?.[sectionKey]?.data?.[fieldKey] ?? '';

//     return (
//       <div className="space-y-1">
//         <label className="block text-xs font-medium text-gray-600">{label}</label>
//         {type === 'textarea' ? (
//           <textarea
//             value={value}
//             onChange={e => handleChange(sectionKey, fieldKey, e.target.value, index)}
//             rows={3}
//             className="w-full px-3 py-2 text-sm border border-gray-200 rounded-md focus:ring-1 focus:ring-purple-400 focus:border-purple-400 outline-none resize-y"
//           />
//         ) : (
//           <input
//             type={type}
//             value={value}
//             onChange={e => handleChange(sectionKey, fieldKey, e.target.value, index)}
//             className="w-full px-3 py-2 text-sm border border-gray-200 rounded-md focus:ring-1 focus:ring-purple-400 focus:border-purple-400 outline-none"
//           />
//         )}
//       </div>
//     );
//   };

//   const renderArrayItems = (sectionKey, fields) => {
//     const items = Array.isArray(localPortfolio?.sections?.[sectionKey]?.data)
//       ? localPortfolio.sections[sectionKey].data
//       : [];

//     if (items.length === 0) {
//       return <p className="text-sm text-gray-500 py-3 italic">No items added yet</p>;
//     }

//     return items.map((_, idx) => (
//       <div key={idx} className="p-4 bg-gray-50 rounded-lg mb-3 relative">
//         <button
//           onClick={() => removeItem(sectionKey, idx)}
//           className="absolute top-3 right-3 text-red-400 hover:text-red-600"
//         >
//           <FiTrash2 size={16} />
//         </button>
//         <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
//           {fields.map(f => renderField(sectionKey, f.label, f.key, f.type || 'text', idx))}
//         </div>
//       </div>
//     ));
//   };

//   const renderSectionContent = (key) => {
//     switch (key) {
//       case 'hero':
//         return (
//           <div className="space-y-5">
//             {renderField('hero', 'Full Name', 'name')}
//             {renderField('hero', 'Professional Title', 'title')}
//             {renderField('hero', 'Tagline', 'tagline')}
//             {renderField('hero', 'Bio', 'bio', 'textarea')}
//             {renderField('hero', 'CTA Button Text', 'ctaText')}
//           </div>
//         );

//       case 'about':
//         return (
//           <div className="space-y-5">
//             {renderField('about', 'Section Title', 'heading')}
//             {renderField('about', 'Description', 'text', 'textarea')}
//           </div>
//         );

//       case 'experience':
//         return (
//           <div className="space-y-5">
//             {renderArrayItems('experience', [
//               { label: 'Role', key: 'role' },
//               { label: 'Company', key: 'company' },
//               { label: 'Duration', key: 'duration' },
//               { label: 'Description', key: 'description', type: 'textarea' },
//             ])}
//             <button
//               onClick={() => addItem('experience')}
//               className="w-full py-2.5 bg-purple-50 hover:bg-purple-100 text-purple-700 rounded-md text-sm font-medium transition flex items-center justify-center gap-1.5"
//             >
//               <FiPlus size={14} /> Add Experience
//             </button>
//           </div>
//         );

//       case 'education':
//         return (
//           <div className="space-y-5">
//             {renderArrayItems('education', [
//               { label: 'School', key: 'school' },
//               { label: 'Degree', key: 'degree' },
//               { label: 'Field', key: 'field' },
//               { label: 'Duration', key: 'duration' },
//             ])}
//             <button
//               onClick={() => addItem('education')}
//               className="w-full py-2.5 bg-purple-50 hover:bg-purple-100 text-purple-700 rounded-md text-sm font-medium transition flex items-center justify-center gap-1.5"
//             >
//               <FiPlus size={14} /> Add Education
//             </button>
//           </div>
//         );

//       case 'projects':
//         return (
//           <div className="space-y-5">
//             {renderArrayItems('projects', [
//               { label: 'Project Title', key: 'title' },
//               { label: 'Description', key: 'description', type: 'textarea' },
//               { label: 'Live URL', key: 'liveUrl' },
//               { label: 'GitHub URL', key: 'githubUrl' },
//             ])}
//             <button
//               onClick={() => addItem('projects')}
//               className="w-full py-2.5 bg-purple-50 hover:bg-purple-100 text-purple-700 rounded-md text-sm font-medium transition flex items-center justify-center gap-1.5"
//             >
//               <FiPlus size={14} /> Add Project
//             </button>
//           </div>
//         );

//       case 'skills':
//         return (
//           <div className="space-y-5">
//             {renderArrayItems('skills', [
//               { label: 'Skill Name', key: 'name' },
//               { label: 'Proficiency (0-100)', key: 'level', type: 'number' },
//               { label: 'Category', key: 'category' },
//             ])}
//             <button
//               onClick={() => addItem('skills')}
//               className="w-full py-2.5 bg-purple-50 hover:bg-purple-100 text-purple-700 rounded-md text-sm font-medium transition flex items-center justify-center gap-1.5"
//             >
//               <FiPlus size={14} /> Add Skill
//             </button>
//           </div>
//         );

//       case 'testimonials':
//         return (
//           <div className="space-y-5">
//             {renderArrayItems('testimonials', [
//               { label: 'Name', key: 'name' },
//               { label: 'Role / Company', key: 'role' },
//               { label: 'Testimonial Text', key: 'text', type: 'textarea' },
//               { label: 'Rating (1-5)', key: 'rating', type: 'number' },
//             ])}
//             <button
//               onClick={() => addItem('testimonials')}
//               className="w-full py-2.5 bg-purple-50 hover:bg-purple-100 text-purple-700 rounded-md text-sm font-medium transition flex items-center justify-center gap-1.5"
//             >
//               <FiPlus size={14} /> Add Testimonial
//             </button>
//           </div>
//         );

//       case 'contact':
//         return (
//           <div className="space-y-5">
//             {renderField('contact', 'Section Heading', 'heading')}
//             {renderField('contact', 'Email', 'email')}
//             {renderField('contact', 'Phone', 'phone')}
//             {renderField('contact', 'Location', 'location')}
//             <div className="flex items-center justify-between pt-2">
//               <label className="text-sm font-medium text-gray-700">Enable Contact Form</label>
//               <label className="relative inline-flex items-center cursor-pointer">
//                 <input
//                   type="checkbox"
//                   checked={localPortfolio?.sections?.[key]?.data?.showForm !== false}
//                   onChange={e => handleChange(key, 'showForm', e.target.checked)}
//                   className="sr-only peer"
//                 />
//                 <div className="w-11 h-6 bg-gray-200 rounded-full peer peer-checked:bg-purple-600 after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:after:translate-x-5"></div>
//               </label>
//             </div>
//           </div>
//         );

//       case 'settings':
//         return (
//           <div className="space-y-6">
//             <div>
//               <label className="block text-sm font-medium text-gray-700 mb-1">Portfolio URL</label>
//               <div className="flex border border-gray-200 rounded-md overflow-hidden">
//                 <span className="px-3 py-2.5 bg-gray-50 text-gray-600 text-sm">portfolio.app/</span>
//                 <input
//                   value={user?.username || ''}
//                   readOnly
//                   className="flex-1 px-3 py-2.5 text-sm bg-white focus:outline-none"
//                 />
//               </div>
//             </div>

//             <div className="flex items-center justify-between">
//               <label className="text-sm font-medium text-gray-700">Make Public</label>
//               <label className="relative inline-flex items-center cursor-pointer">
//                 <input
//                   type="checkbox"
//                   checked={portfolio?.settings?.isPublic !== false}
//                   onChange={async (e) => {
//                     await portfolioService.setPublic(e.target.checked);
//                     refreshPortfolio();
//                   }}
//                   className="sr-only peer"
//                 />
//                 <div className="w-11 h-6 bg-gray-200 rounded-full peer peer-checked:bg-purple-600 after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:after:translate-x-5"></div>
//               </label>
//             </div>

//             <div className="flex items-center justify-between">
//               <label className="text-sm font-medium text-gray-700">Contact Form</label>
//               <label className="relative inline-flex items-center cursor-pointer">
//                 <input
//                   type="checkbox"
//                   checked={localPortfolio?.sections?.contact?.data?.showForm !== false}
//                   onChange={e => handleChange('contact', 'showForm', e.target.checked)}
//                   className="sr-only peer"
//                 />
//                 <div className="w-11 h-6 bg-gray-200 rounded-full peer peer-checked:bg-purple-600 after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:after:translate-x-5"></div>
//               </label>
//             </div>
//           </div>
//         );

//       default:
//         return <div className="text-sm text-gray-500 py-6">Coming soon...</div>;
//     }
//   };

//   return (
//     <div className="h-screen flex flex-col bg-gray-50">
//       {/* Top Bar */}
//       <div className="h-14 border-b bg-white flex items-center justify-between px-6 shadow-sm flex-shrink-0">
//         <h1 className="text-lg font-bold text-gray-900">Portfolio Editor</h1>

//         <div className="flex items-center gap-3">
//           <div className="flex bg-gray-100 rounded-lg overflow-hidden">
//             {['Desktop', 'Tablet', 'Mobile'].map(mode => (
//               <button
//                 key={mode}
//                 onClick={() => setViewMode(mode.toLowerCase())}
//                 className={`px-5 py-1.5 text-sm font-medium transition ${
//                   viewMode === mode.toLowerCase() ? 'bg-purple-600 text-white' : 'text-gray-700 hover:bg-gray-200'
//                 }`}
//               >
//                 {mode}
//               </button>
//             ))}
//           </div>

//           <button className="p-2 hover:bg-gray-100 rounded-lg transition">
//             <FiRefreshCw size={18} className="text-gray-600" />
//           </button>

//           <button className="px-4 py-1.5 bg-indigo-600 text-white text-sm rounded-lg hover:bg-indigo-700 flex items-center gap-2">
//             <FiExternalLink size={16} /> New Tab
//           </button>

//           <button
//             onClick={saveAll}
//             disabled={saving}
//             className={`px-5 py-1.5 text-white text-sm font-medium rounded-lg shadow transition flex items-center gap-2 ${
//               saving ? 'bg-gray-400 cursor-not-allowed' : 'bg-gradient-to-r from-purple-600 to-pink-500 hover:brightness-110'
//             }`}
//           >
//             <FiSave size={16} />
//             {saving ? 'Saving...' : 'Save All'}
//           </button>

//           <button className="px-5 py-1.5 bg-purple-700 text-white text-sm font-medium rounded-lg shadow hover:bg-purple-800">
//             Publish
//           </button>
//         </div>
//       </div>

//       {/* Main Content */}
//       <div className="flex flex-1 overflow-hidden">
//         {/* Left Sidebar */}
//         <aside className="w-96 border-r bg-white overflow-y-auto">
//           <div className="p-5 space-y-3">
//             {['hero', 'about', 'experience', 'education', 'projects', 'skills', 'testimonials', 'contact', 'settings'].map(key => (
//               <div key={key} className="bg-white rounded-lg overflow-hidden">
//                 <button
//                   onClick={() => toggleExpand(key)}
//                   className="w-full px-4 py-3.5 flex items-center justify-between bg-gray-50 hover:bg-gray-100 transition text-sm font-medium"
//                 >
//                   <div className="flex items-center gap-3">
//                     {key === 'hero' && <FiUser size={16} className="text-purple-600" />}
//                     {key === 'about' && <FiInfo size={16} className="text-purple-600" />}
//                     {key === 'experience' && <FiBriefcase size={16} className="text-purple-600" />}
//                     {key === 'education' && <FiBookOpen size={16} className="text-purple-600" />}
//                     {key === 'projects' && <FiCode size={16} className="text-purple-600" />}
//                     {key === 'skills' && <FiStar size={16} className="text-purple-600" />}
//                     {key === 'testimonials' && <FiMessageSquare size={16} className="text-purple-600" />}
//                     {key === 'contact' && <FiMail size={16} className="text-purple-600" />}
//                     {key === 'settings' && <FiSettings size={16} className="text-purple-600" />}
//                     <span className="capitalize font-medium text-gray-900">
//                       {key === 'settings' ? 'Settings' : key}
//                     </span>
//                     {key !== 'hero' && key !== 'settings' && Array.isArray(localPortfolio?.sections?.[key]?.data) && (
//                       <span className="text-xs bg-gray-200 px-2 py-0.5 rounded-full text-gray-700">
//                         {localPortfolio.sections[key].data.length}
//                       </span>
//                     )}
//                   </div>
//                   {expanded[key] ? <FiChevronUp size={16} /> : <FiChevronDown size={16} />}
//                 </button>

//                 {expanded[key] && (
//                   <div className="p-5">
//                     {renderSectionContent(key)}
//                   </div>
//                 )}
//               </div>
//             ))}
//           </div>
//         </aside>

//         {/* Right - Preview (passes FULL updated portfolio object) */}
//         <PortfolioPreview 
//   localPortfolio={localPortfolio} 
//   viewMode={viewMode} 
//   setViewMode={setViewMode} 
// />
//       </div>
//     </div>
//   );
// }

import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import portfolioService from '../services/portfolioService';
import { useMessageModal } from '../context/MessageModalContext';
import {
  FiSave, FiTrash2, FiPlus, FiChevronDown, FiChevronUp,
  FiUser, FiInfo, FiBriefcase, FiBookOpen, FiCode, FiStar,
  FiMessageSquare, FiMail, FiSettings, FiGlobe, FiLock, FiCopy, FiCheck, FiEye, FiEyeOff,
} from 'react-icons/fi';
import { Formik, Form, Field, ErrorMessage, FieldArray } from 'formik';
import * as Yup from 'yup';
import PortfolioPreview from './PortfolioPreview';
import LoadingSpinner from '../components/common/LoadingSpinner';
import { COLORS } from '../constants/colors';

export default function PortfolioEditor() {
  const { portfolio, refreshPortfolio, user } = useAuth();
  const { showMessage } = useMessageModal();

  const [expanded, setExpanded] = useState({ hero: true });
  const [localPortfolio, setLocalPortfolio] = useState(null);
  const [globalSaving, setGlobalSaving] = useState(false);
  const [copied, setCopied] = useState(false);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  useEffect(() => {
    if (portfolio) {
      setLocalPortfolio(JSON.parse(JSON.stringify(portfolio)));
    }
  }, [portfolio]);

  useEffect(() => {
    if (localPortfolio && portfolio) {
      const hasChanges = JSON.stringify(localPortfolio) !== JSON.stringify(portfolio);
      setHasUnsavedChanges(hasChanges);
    }
  }, [localPortfolio, portfolio]);

  const toggleExpand = (key) => {
    setExpanded((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const liveUrl = `${window.location.origin}/${user?.username || ''}`;
  const isPublic = portfolio?.settings?.isPublic !== false;

  const copyLink = () => {
    navigator.clipboard.writeText(liveUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  const saveAll = async () => {
    if (!localPortfolio || !hasUnsavedChanges) return;
    setGlobalSaving(true);
    try {
      const updates = {};
      Object.keys(localPortfolio.sections || {}).forEach((key) => {
        updates[`sections.${key}`] = localPortfolio.sections[key];
      });
      await portfolioService.updatePortfolio(updates);
      await refreshPortfolio();
      showMessage({ type: 'success', title: 'Saved', message: 'Portfolio updated.' });
      setHasUnsavedChanges(false);
    } catch (err) {
      showMessage({ type: 'error', title: 'Save failed', message: err.message || 'Error.' });
    } finally {
      setGlobalSaving(false);
    }
  };

  const handleSectionSave = (sectionKey, values) => {
    setLocalPortfolio((prev) => {
      if (!prev) return prev;
      const copy = JSON.parse(JSON.stringify(prev));
      if (!copy.sections) copy.sections = {};
      copy.sections[sectionKey] = { ...copy.sections[sectionKey], data: values };
      return copy;
    });
    // showMessage({ type: 'success', title: 'Saved', message: 'Section updated locally.', autoCloseMs: 1600 });
  };

  const toggleSectionEnabled = (sectionKey) => {
    setLocalPortfolio((prev) => {
      if (!prev) return prev;
      const copy = JSON.parse(JSON.stringify(prev));
      if (!copy.sections?.[sectionKey]) copy.sections[sectionKey] = { enabled: true, data: {} };
      copy.sections[sectionKey].enabled = !copy.sections[sectionKey].enabled;
      return copy;
    });
  };

  const RequiredLabel = ({ children }) => (
    <label className="block text-xs font-medium text-gray-700">
      {children} <span style={{ color: COLORS.danger }}>*</span>
    </label>
  );

  const renderField = (name, label, type = 'text', required = false, placeholder = '', fullWidth = false) => (
    <div className={`space-y-1 ${fullWidth ? 'col-span-full' : ''}`}>
      {required ? <RequiredLabel>{label}</RequiredLabel> : <label className="block text-xs font-medium text-gray-700">{label}</label>}
      <Field
        as={type === 'textarea' ? 'textarea' : 'input'}
        type={type !== 'textarea' ? type : undefined}
        name={name}
        rows={type === 'textarea' ? 5 : undefined}
        placeholder={placeholder}
        className="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-md focus:ring-2 focus:ring-purple-500 focus:border-purple-400 outline-none resize-y"
      />
      <ErrorMessage name={name} component="div" className="text-xs text-red-600 mt-1" />
    </div>
  );

  const renderSectionContent = (key) => {
    const section = localPortfolio?.sections?.[key] || {};
    const data = section.data || (Array.isArray(section.data) ? [] : {});

    if (!localPortfolio) return <LoadingSpinner size="md" />;

    switch (key) {
      case 'hero':
        return (
          <Formik
            initialValues={{
              name: data.name || '',
              title: data.title || '',
              bio: data.bio || '',
              avatar: data.avatar || '',
              bannerImage: data.bannerImage || '',
              ctaText: data.ctaText || 'View Work',
              ctaLink: data.ctaLink || '',
            }}
            validationSchema={Yup.object({
              name: Yup.string().required('Required'),
              title: Yup.string().required('Required'),
            })}
            onSubmit={(values) => handleSectionSave('hero', values)}
          >
            {({ dirty, resetForm }) => (
              <Form className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  {renderField('name', 'Full Name', 'text', true)}
                  {renderField('title', 'Professional Title', 'text', true)}
                  {renderField('ctaText', 'CTA Button Text')}
                  {renderField('ctaLink', 'CTA Link (optional)')}
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  {renderField('avatar', 'Avatar URL')}
                  {renderField('bannerImage', 'Banner Image URL')}
                </div>
                {renderField('bio', 'Bio', 'textarea', false, 'Write about yourself...', true)}
                {dirty && (
                  <div className="flex justify-end gap-3 pt-4">
                    <button type="button" onClick={resetForm} className="px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-md text-sm">Cancel</button>
                    <button type="submit" className="px-5 py-2 bg-gradient-to-r from-[#7C3AED] to-[#F472B6] text-white rounded-md text-sm shadow-sm hover:brightness-105 flex items-center gap-2">
                      <FiSave size={14} /> Save
                    </button>
                  </div>
                )}
              </Form>
            )}
          </Formik>
        );

      case 'about':
        return (
          <Formik
            initialValues={{
              heading: data.heading || 'About Me',
              text: data.text || '',
              image: data.image || '',
              resumeDownload: data.resumeDownload || '',
            }}
            validationSchema={Yup.object({
              heading: Yup.string().required(),
              text: Yup.string().required(),
            })}
            onSubmit={(values) => handleSectionSave('about', values)}
          >
            {({ dirty, resetForm }) => (
              <Form className="space-y-6">
                {renderField('heading', 'Section Heading', 'text', true)}
                {renderField('text', 'About Text', 'textarea', true, 'Tell your story...', true)}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  {renderField('image', 'Profile / About Image URL')}
                  {renderField('resumeDownload', 'Resume Download URL')}
                </div>
                {dirty && (
                  <div className="flex justify-end gap-3 pt-4">
                    <button type="button" onClick={resetForm} className="px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-md text-sm">Cancel</button>
                    <button type="submit" className="px-5 py-2 bg-gradient-to-r from-[#7C3AED] to-[#F472B6] text-white rounded-md text-sm shadow-sm hover:brightness-105 flex items-center gap-2">
                      <FiSave size={14} /> Save
                    </button>
                  </div>
                )}
              </Form>
            )}
          </Formik>
        );

      case 'experience':
      case 'education':
      case 'projects':
      case 'skills':
      case 'testimonials':
      case 'services':
        const isExperience = key === 'experience';
        const isEducation = key === 'education';
        const isProjects = key === 'projects';
        const isSkills = key === 'skills';
        const isTestimonials = key === 'testimonials';
        const isServices = key === 'services';

        const items = Array.isArray(data) ? data : [];

        const getInitialItem = () => {
          if (isExperience) return { company: '', role: '', duration: '', location: '', description: '', current: false, logo: '' };
          if (isEducation) return { school: '', degree: '', field: '', duration: '', grade: '', logo: '' };
          if (isProjects) return { title: '', description: '', techStack: [], liveUrl: '', githubUrl: '', image: '', featured: false, videoDemo: '' };
          if (isSkills) return { name: '', level: 50, category: '', icon: '' };
          if (isTestimonials) return { name: '', role: '', company: '', text: '', avatar: '', rating: 5 };
          if (isServices) return { title: '', price: '', description: '', features: [], icon: '', popular: false };
          return {};
        };

        return (
          <div className="space-y-6">
            {items.length === 0 && <p className="text-sm text-gray-500 italic">No entries yet</p>}

            {items.map((item, index) => (
              <Formik
                key={index}
                initialValues={item || getInitialItem()}
                validationSchema={
                  isExperience ? Yup.object({ role: Yup.string().required(), company: Yup.string().required() }) :
                  isProjects ? Yup.object({ title: Yup.string().required(), description: Yup.string().required() }) :
                  isSkills ? Yup.object({ name: Yup.string().required() }) :
                  isTestimonials ? Yup.object({ name: Yup.string().required(), text: Yup.string().required() }) :
                  isServices ? Yup.object({ title: Yup.string().required(), description: Yup.string().required() }) :
                  Yup.object({})
                }
                onSubmit={(values) => {
                  setLocalPortfolio(prev => {
                    const copy = JSON.parse(JSON.stringify(prev));
                    copy.sections[key].data[index] = values;
                    return copy;
                  });
                }}
              >
                {({ dirty, resetForm, values, setFieldValue }) => (
                  <Form className="p-4 bg-gray-50 rounded-lg border border-gray-100 relative">
                    <button
                      type="button"
                      onClick={() => setLocalPortfolio(prev => {
                        const copy = JSON.parse(JSON.stringify(prev));
                        copy.sections[key].data.splice(index, 1);
                        return copy;
                      })}
                      className="absolute top-3 right-12 text-red-500 hover:text-red-700"
                    >
                      <FiTrash2 size={16} />
                    </button>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {isExperience && (
                        <>
                          {renderField('role', 'Role', 'text', true)}
                          {renderField('company', 'Company', 'text', true)}
                          {renderField('duration', 'Duration')}
                          {renderField('location', 'Location')}
                          {renderField('description', 'Description', 'textarea', false, '', true)}
                          <div className="flex items-center gap-2">
                            <Field type="checkbox" name="current" className="h-4 w-4 text-purple-600 rounded" />
                            <label className="text-sm text-gray-700">Current Position</label>
                          </div>
                          {renderField('logo', 'Company Logo URL')}
                        </>
                      )}

                      {isEducation && (
                        <>
                          {renderField('school', 'School', 'text', true)}
                          {renderField('degree', 'Degree', 'text', true)}
                          {renderField('field', 'Field')}
                          {renderField('duration', 'Duration')}
                          {renderField('grade', 'Grade / GPA')}
                          {renderField('logo', 'School Logo URL')}
                        </>
                      )}

                      {isProjects && (
                        <>
                          {renderField('title', 'Project Title', 'text', true)}
                          {renderField('description', 'Description', 'textarea', true, '', true)}
                          <div className="col-span-full">
                            <label className="block text-xs font-medium text-gray-700">Tech Stack (comma separated)</label>
                            <Field
                              name="techStack"
                              as="input"
                              value={values.techStack?.join(', ') || ''}
                              onChange={(e) => {
                                const val = e.target.value;
                                setFieldValue('techStack', val ? val.split(',').map(s => s.trim()).filter(Boolean) : []);
                              }}
                              placeholder="React, Node.js, Tailwind, etc."
                              className="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-md"
                            />
                          </div>
                          {renderField('liveUrl', 'Live URL')}
                          {renderField('githubUrl', 'GitHub URL')}
                          {renderField('image', 'Project Image URL')}
                          {renderField('videoDemo', 'Video Demo URL')}
                          <div className="flex items-center gap-2">
                            <Field type="checkbox" name="featured" className="h-4 w-4 text-purple-600 rounded" />
                            <label className="text-sm text-gray-700">Featured Project</label>
                          </div>
                        </>
                      )}

                      {isSkills && (
                        <>
                          {renderField('name', 'Skill Name', 'text', true)}
                          {renderField('level', 'Proficiency (0–100)', 'number', true)}
                          {renderField('category', 'Category')}
                          {renderField('icon', 'Icon URL or class')}
                        </>
                      )}

                      {isTestimonials && (
                        <>
                          {renderField('name', 'Name', 'text', true)}
                          {renderField('role', 'Role')}
                          {renderField('company', 'Company')}
                          {renderField('text', 'Testimonial Text', 'textarea', true, '', true)}
                          {renderField('avatar', 'Avatar URL')}
                          {renderField('rating', 'Rating (1–5)', 'number', true)}
                        </>
                      )}

                      {isServices && (
                        <>
                          {renderField('title', 'Service Title', 'text', true)}
                          {renderField('price', 'Price')}
                          {renderField('description', 'Description', 'textarea', true, '', true)}
                          <div className="col-span-full">
                            <label className="block text-xs font-medium text-gray-700">Features (one per line)</label>
                            <FieldArray name="features">
                              {({ push, remove }) => (
                                <div>
                                  {values.features?.map((feat, idx) => (
                                    <div key={idx} className="flex gap-2 mb-2">
                                      <Field
                                        name={`features.${idx}`}
                                        className="flex-1 px-3 py-2 text-sm border border-gray-200 rounded-md"
                                      />
                                      <button type="button" onClick={() => remove(idx)} className="text-red-500">
                                        ×
                                      </button>
                                    </div>
                                  ))}
                                  <button
                                    type="button"
                                    onClick={() => push('')}
                                    className="text-purple-600 text-sm hover:underline"
                                  >
                                    + Add Feature
                                  </button>
                                </div>
                              )}
                            </FieldArray>
                          </div>
                          {renderField('icon', 'Icon URL or class')}
                          <div className="flex items-center gap-2">
                            <Field type="checkbox" name="popular" className="h-4 w-4 text-purple-600 rounded" />
                            <label className="text-sm text-gray-700">Mark as Popular</label>
                          </div>
                        </>
                      )}
                    </div>

                    {dirty && (
                      <div className="flex justify-end gap-3 mt-4 pt-3 border-t border-gray-100">
                        <button type="button" onClick={resetForm} className="px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-md text-sm">Cancel</button>
                        <button type="submit" className="px-5 py-2 bg-gradient-to-r from-[#7C3AED] to-[#F472B6] text-white rounded-md text-sm shadow-sm hover:brightness-105 flex items-center gap-2">
                          <FiSave size={14} /> Save Item
                        </button>
                      </div>
                    )}
                  </Form>
                )}
              </Formik>
            ))}

            <button
              type="button"
              onClick={() => setLocalPortfolio(prev => {
                const copy = JSON.parse(JSON.stringify(prev));
                if (!copy.sections?.[key]?.data) copy.sections[key] = { data: [] };
                copy.sections[key].data.push(getInitialItem());
                return copy;
              })}
              className="w-full py-2.5 bg-purple-50 hover:bg-purple-100 text-purple-700 rounded-md text-sm font-medium flex items-center justify-center gap-1.5"
            >
              <FiPlus size={14} /> Add {key.charAt(0).toUpperCase() + key.slice(1).replace('s','')}
            </button>
          </div>
        );

      case 'settings':
        return (
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Portfolio URL</label>
              <div className="flex border border-gray-200 rounded-md overflow-hidden">
                <span className="px-3 py-2.5 bg-gray-50 text-gray-600 text-sm">portfolio.app/</span>
                <input value={user?.username || ''} readOnly className="flex-1 px-3 py-2.5 text-sm bg-white focus:outline-none" />
              </div>
            </div>

            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-gray-700">Make Public</label>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" checked={isPublic} onChange={async e => {
                  await portfolioService.setPublic(e.target.checked);
                  refreshPortfolio();
                }} className="sr-only peer" />
                <div className="w-11 h-6 bg-gray-200 rounded-full peer peer-checked:bg-purple-600 after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:after:translate-x-5"></div>
              </label>
            </div>

            <div className="pt-4 border-t border-gray-100">
              <h4 className="text-sm font-medium text-gray-800 mb-3">Section Visibility</h4>
              <div className="grid grid-cols-2 gap-3">
                {['hero','about','experience','education','projects','skills','services','testimonials','contact'].map(sKey => (
                  <div key={sKey} className="flex items-center justify-between bg-gray-50 p-3 rounded-md">
                    <span className="capitalize text-sm text-gray-700">{sKey}</span>
                    <button
                      onClick={() => toggleSectionEnabled(sKey)}
                      className="text-purple-600 hover:text-purple-800 text-sm font-medium flex items-center gap-1.5"
                    >
                      {localPortfolio?.sections?.[sKey]?.enabled !== false ? (
                        <FiEye size={16} />
                      ) : (
                        <FiEyeOff size={16} />
                      )}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  if (!localPortfolio) {
    return (
      <div className="h-screen flex items-center justify-center bg-gray-50">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col bg-gray-50">
      <div className="h-14 bg-white flex items-center justify-between px-6 shadow-sm flex-shrink-0 border-b border-gray-100">
        <div className="flex items-center gap-4">
          <span className="text-lg font-semibold text-gray-900">Portfolio Editor</span>
        </div>

        <div className="flex items-center gap-4">
          <div
            className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium border ${
              isPublic ? 'bg-green-50 text-green-800 border-green-200' : 'bg-amber-50 text-amber-800 border-amber-200'
            }`}
          >
            {isPublic ? <FiGlobe size={15} /> : <FiLock size={15} />}
            <span>{isPublic ? 'Public' : 'Private'}</span>
          </div>

          <div className="flex items-center bg-gray-50 border border-gray-200 rounded-lg overflow-hidden">
            <div className="px-3 py-2 text-sm text-gray-600 truncate max-w-[240px]">
              {liveUrl.replace(/^https?:\/\//, '')}
            </div>
            <button
              onClick={copyLink}
              className="p-2.5 border-l border-gray-200 hover:bg-gray-100"
              title={copied ? 'Copied!' : 'Copy link'}
            >
              {copied ? <FiCheck className="text-green-600" size={16} /> : <FiCopy size={16} />}
            </button>
          </div>

          <a
            href={liveUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="px-4 py-1.5 bg-white border border-gray-300 text-gray-700 hover:bg-gray-50 rounded-lg text-sm font-medium flex items-center gap-2"
          >
            <FiEye size={14} /> View Live
          </a>

          <button
            onClick={saveAll}
            disabled={globalSaving || !hasUnsavedChanges}
            className={`px-5 py-1.5 text-white text-sm font-medium rounded-lg shadow transition flex items-center gap-2 min-w-[110px] ${
              globalSaving || !hasUnsavedChanges ? 'bg-gray-400 cursor-not-allowed' : 'bg-gradient-to-r from-[#7C3AED] via-[#C084FC] to-[#F472B6] hover:brightness-105'
            }`}
          >
            <FiSave size={16} />
            {globalSaving ? 'Saving...' : 'Save All'}
          </button>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        <aside className="w-96 bg-white overflow-y-auto border-r border-gray-100">
          <div className="p-5 space-y-3">
            {['hero','about','experience','education','projects','skills','services','testimonials','contact','settings'].map((key) => (
              <div key={key} className="bg-white rounded-lg border border-gray-100 overflow-hidden shadow-sm">
                <div className="flex items-center justify-between px-4 py-3 bg-gray-50 border-b border-gray-100">
                  <button onClick={() => toggleExpand(key)} className="flex items-center gap-3 flex-1 text-left">
                    <div className="flex items-center gap-3">
                      {key === 'hero' && <FiUser size={16} className="text-purple-600" />}
                      {key === 'about' && <FiInfo size={16} className="text-purple-600" />}
                      {key === 'experience' && <FiBriefcase size={16} className="text-purple-600" />}
                      {key === 'education' && <FiBookOpen size={16} className="text-purple-600" />}
                      {key === 'projects' && <FiCode size={16} className="text-purple-600" />}
                      {key === 'skills' && <FiStar size={16} className="text-purple-600" />}
                      {key === 'services' && <FiStar size={16} className="text-purple-600" />}
                      {key === 'testimonials' && <FiMessageSquare size={16} className="text-purple-600" />}
                      {key === 'contact' && <FiMail size={16} className="text-purple-600" />}
                      {key === 'settings' && <FiSettings size={16} className="text-purple-600" />}
                      <span className="capitalize font-medium text-gray-900">
                        {key === 'settings' ? 'Settings' : key}
                      </span>
                    </div>
                    {expanded[key] ? <FiChevronUp size={16} /> : <FiChevronDown size={16} />}
                  </button>

                  {key !== 'settings' && (
                    <button
                      onClick={() => toggleSectionEnabled(key)}
                      className="text-gray-500 hover:text-purple-600"
                      title={localPortfolio?.sections?.[key]?.enabled !== false ? 'Hide' : 'Show'}
                    >
                      {localPortfolio?.sections?.[key]?.enabled !== false ? <FiEye size={16} /> : <FiEyeOff size={16} />}
                    </button>
                  )}
                </div>

                {expanded[key] && <div className="p-5">{renderSectionContent(key)}</div>}
              </div>
            ))}
          </div>
        </aside>

        <PortfolioPreview localPortfolio={localPortfolio} />
      </div>
    </div>
  );
}