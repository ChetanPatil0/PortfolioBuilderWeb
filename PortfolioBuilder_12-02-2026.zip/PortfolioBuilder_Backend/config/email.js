import nodemailer from 'nodemailer';

const transporter = nodemailer.createTransport({
  service: 'Gmail',
  port: 587,
  secure: false,
  auth: {
  user: 'svp.app@svp.edu.in',
    pass: 'qhsk bxaa smlz ckpa',
  },
});

// Verify connection on startup
transporter.verify((error) => {
  if (error) {
    console.error('Email config error:', error);
  } else {
    console.log('Email server ready');
  }
});

/**
 * USER AUTO-REPLY EMAIL
 */
const sendAutoReplyEmail = async (
  toEmail,
  fromName,
  fromEmail,
  message
) => {
  const mailOptions = {
    from: `"${process.env.MAIL_FROM_NAME}" <${process.env.EMAIL_USER}>`,
    to: toEmail,
    subject: 'Copy of your message submission',
    html: `
      <div style="font-family: Inter, Arial, sans-serif; max-width: 600px; margin: 20px auto; padding: 30px; background: #f9fafb; border-radius: 12px; border: 1px solid #e5e7eb;">
        <h2 style="color: #111827;">Hello ${fromName},</h2>

        <p style="color: #374151;">
          This email confirms that your message has been successfully submitted.
          Below is a copy of the information you provided.
        </p>

        <div style="background:#ffffff;padding:20px;border-radius:8px;margin-top:20px;">
          <p><strong>Name:</strong> ${fromName}</p>
          <p><strong>Email:</strong>
            <a href="mailto:${fromEmail}" style="color:#6366f1;">
              ${fromEmail}
            </a>
          </p>
        </div>

        <div style="background:#ffffff;padding:20px;border-radius:8px;margin-top:16px;">
          <p><strong>Message:</strong></p>
          <p style="background:#f3f4f6;padding:15px;border-radius:8px;white-space:pre-wrap;">
            ${message.replace(/\n/g, '<br>')}
          </p>
        </div>

        <small style="color:#6b7280;display:block;margin-top:24px;text-align:center;">
          Sent on ${new Date().toLocaleString()}
        </small>
      </div>
    `,
  };

  await transporter.sendMail(mailOptions);
};

/**
 * ADMIN EMAIL (AUTO-SENDS USER COPY INSIDE)
 */
export const sendContactEmail = async (
  toEmail,
  fromName,
  fromEmail,
  message
) => {
  const mailOptions = {
    from: `"${process.env.MAIL_FROM_NAME}" <${process.env.EMAIL_USER}>`,
    to: toEmail,
    replyTo: fromEmail,
    subject: `New message from ${fromName}`,
    html: `
      <div style="font-family: Inter, Arial, sans-serif; max-width: 600px; margin: 20px auto; padding: 30px; background: #f9fafb; border-radius: 12px; border: 1px solid #e5e7eb;">
        <h2 style="color:#111827;margin-bottom:20px;">
          New Contact Form Submission
        </h2>

        <div style="background:#ffffff;padding:20px;border-radius:8px;margin-bottom:16px;">
          <p><strong>Name:</strong> ${fromName}</p>
          <p><strong>Email:</strong>
            <a href="mailto:${fromEmail}" style="color:#6366f1;">
              ${fromEmail}
            </a>
          </p>
        </div>

        <div style="background:#ffffff;padding:20px;border-radius:8px;">
          <p><strong>Message:</strong></p>
          <p style="background:#f3f4f6;padding:15px;border-radius:8px;white-space:pre-wrap;">
            ${message.replace(/\n/g, '<br>')}
          </p>
        </div>

        <small style="color:#6b7280;display:block;margin-top:24px;">
          Received on ${new Date().toLocaleString()}
        </small>
      </div>
    `,
  };

  // 1️⃣ Send admin email
  await transporter.sendMail(mailOptions);

  // 2️⃣ Immediately send user auto-reply
  await sendAutoReplyEmail(fromEmail, fromName, fromEmail, message);
};
