
import api from "./api";

const themeService = {
  getAllThemes: () => api.get("/theme/gallery"),

  activateTheme: (themeId) =>
    api.post("/theme/activate", { themeId }),
};

export default themeService;
