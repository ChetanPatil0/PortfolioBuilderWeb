// src/pages/PreviewLocal.jsx
import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import PortfolioRenderer from './PortfolioRenderer';

export default function PreviewLocal() {
  const [searchParams] = useSearchParams();
  const [previewData, setPreviewData] = useState(null);

  console.log('local portfolio data 3 (raw param): ', searchParams.get('data'));

  useEffect(() => {
    const dataParam = searchParams.get('data');
    if (dataParam) {
      try {
        const decoded = decodeURIComponent(dataParam);
        console.log('decoded string: ', decoded.substring(0, 200) + '...'); // first 200 chars for debug

        const parsed = JSON.parse(decoded);
        console.log('parsed object: ', parsed);

        // Pass the FULL parsed object directly (no extra wrapping)
        setPreviewData(parsed);
      } catch (err) {
        console.error('Preview parse error:', err);
        setPreviewData({}); // safe empty object
      }
    }
  }, [searchParams]);

  if (!previewData) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100 text-gray-600">
        Loading preview...
      </div>
    );
  }

  return (
    <PortfolioRenderer
      portfolioData={previewData}
      isPreview={false}           // false = show header/navbar/footer like live
      onContactSubmit={() => {}}
      messageStatus=""
    />
  );
}