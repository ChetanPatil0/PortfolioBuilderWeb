import { Outlet } from "react-router-dom";
import Sidebar from "./Sidebar";
import Navbar from "./Navbar";
import Footer from "./Footer";
import { useState } from "react";

export default function DashboardLayout() {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <div className="h-screen overflow-hidden bg-gray-50">
      {/* Navbar */}
      <header className="fixed top-0 left-0 right-0 h-16 bg-white z-50">
        <Navbar />
      </header>

      {/* Body */}
      <div className="pt-16 h-full flex">
        {/* Sidebar */}
        <aside
          className={`
            h-[calc(100vh-4rem)]
            bg-white 
            transition-all duration-300
            ${collapsed ? "w-[6%]" : "w-[16%]"}
            flex-shrink-0
          `}
        >
          <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} />
        </aside>

        {/* Main Content (SCROLLABLE) */}
        <main
          className={`
            h-[calc(100vh-4rem)]
            transition-all duration-300
            ${collapsed ? "w-[94%]" : "w-[82%]"}
            overflow-y-auto
          `}
        >
          <div className="p-2 min-h-full flex flex-col">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
}
