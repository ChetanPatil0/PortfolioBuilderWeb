import { Router } from "express";
import passport from "passport";
import {
  register,
  login,
  googleSuccess,
  logout,
  getMe,
} from "../controllers/authController.js";
import { protect } from "../middleware/auth.js";

const router = Router();

router.post("/register", register);
router.post("/login", login);
// router.get( "/google", passport.authenticate("google", { scope: ["profile", "email"] }));
// router.get( "/google/callback",passport.authenticate("google", { failureRedirect: "/login", failureMessage: true,}),googleSuccess);

router.get("/logout", logout);
router.get("/me", protect, getMe);

export default router;
