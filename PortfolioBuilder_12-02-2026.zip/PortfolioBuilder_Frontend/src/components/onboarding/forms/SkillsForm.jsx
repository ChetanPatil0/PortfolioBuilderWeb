// src/components/onboarding/forms/SkillsForm.jsx
import { Formik, Form, Field, FieldArray, ErrorMessage } from "formik";
import * as Yup from "yup";
import { Plus, Trash2 } from "lucide-react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const validationSchema = Yup.object({
  skills: Yup.array()
    .of(
      Yup.object({
        name: Yup.string().required("Skill name is required"),
        level: Yup.number()
          .min(0)
          .max(100)
          .required("Skill level is required"),
        category: Yup.string().required("Category is required"),
      })
    )
    .min(1, "Add at least one skill"),
});

export default function SkillsForm({ data = {}, onNext, onBack }) {
  const initialValues = {
    skills: data.skills || [],
  };

  const handleSubmit = (values, { setSubmitting }) => {
    setTimeout(() => {
      onNext({ skills: values.skills });
      toast.success("Skills saved!");
      setSubmitting(false);
    }, 600);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <ToastContainer position="top-right" autoClose={3000} />

      <div className="bg-white rounded-3xl shadow-xl w-full max-w-4xl overflow-hidden">
        {/* Purple Header */}
        <div className="bg-gradient-to-r from-purple-600 to-purple-500 text-white font-bold py-4 text-center text-xl rounded-t-3xl">
          Add Your Skills
        </div>

        <div className="p-4 lg:p-6">
          <Formik
            initialValues={initialValues}
            enableReinitialize
            validationSchema={validationSchema}
            onSubmit={handleSubmit}
          >
            {({ values, setFieldValue, isSubmitting }) => (
              <Form className="space-y-8">
                <FieldArray name="skills">
                  {({ push, remove }) => (
                    <>
                      {/* Add Skill Button */}
                      <button
                        type="button"
                        onClick={() =>
                          push({
                            name: "",
                            level: 80,
                            category: "General",
                          })
                        }
                        className="flex items-center gap-3 px-6 py-3 bg-gradient-to-r from-purple-600 to-purple-500 text-white font-semibold rounded-lg shadow hover:from-purple-700 hover:to-purple-600 transition"
                      >
                        <Plus size={20} /> Add Skill
                      </button>

                      {values.skills.length > 0 ? (
                        values.skills.map((skill, index) => (
                          <div
                            key={index}
                            className="p-6 border border-gray-300 rounded-2xl space-y-6 shadow-sm"
                          >
                            {/* Skill Name */}
                            <div>
                              <label className="block text-gray-700 text-sm font-medium mb-1">
                                Skill Name <span className="text-red-500">*</span>
                              </label>
                              <Field
                                name={`skills.${index}.name`}
                                placeholder="React.js"
                                className="w-full px-4 py-3 border rounded-lg"
                              />
                              <ErrorMessage
                                name={`skills.${index}.name`}
                                component="div"
                                className="text-red-500 text-xs"
                              />
                            </div>

                            {/* Skill Level */}
                            <div>
                              <label className="block text-gray-700 text-sm font-medium mb-2">
                                Skill Level: <strong>{skill.level}%</strong>
                              </label>
                              <input
                                type="range"
                                min="0"
                                max="100"
                                value={skill.level}
                                onChange={(e) =>
                                  setFieldValue(
                                    `skills.${index}.level`,
                                    Number(e.target.value)
                                  )
                                }
                                className="w-full"
                              />
                              <ErrorMessage
                                name={`skills.${index}.level`}
                                component="div"
                                className="text-red-500 text-xs"
                              />
                            </div>

                            {/* Category */}
                            <div>
                              <label className="block text-gray-700 text-sm font-medium mb-1">
                                Category <span className="text-red-500">*</span>
                              </label>
                              <Field
                                as="select"
                                name={`skills.${index}.category`}
                                className="w-full px-4 py-3 border rounded-lg"
                              >
                                <option value="General">General</option>
                                <option value="Frontend">Frontend</option>
                                <option value="Backend">Backend</option>
                                <option value="DevOps">DevOps</option>
                                <option value="UI/UX">UI/UX</option>
                                <option value="Mobile">Mobile</option>
                              </Field>
                              <ErrorMessage
                                name={`skills.${index}.category`}
                                component="div"
                                className="text-red-500 text-xs"
                              />
                            </div>

                            {/* Remove Button */}
                            <div className="flex justify-end">
                              <button
                                type="button"
                                onClick={() => remove(index)}
                                className="text-red-600 flex items-center gap-2 font-medium"
                              >
                                <Trash2 size={18} /> Remove
                              </button>
                            </div>
                          </div>
                        ))
                      ) : (
                        <div className="text-gray-500">No skills added yet.</div>
                      )}
                    </>
                  )}
                </FieldArray>

                {/* Navigation */}
                <div className="flex justify-between items-center pt-8 border-t border-gray-200 mt-6">
                  <button
                    type="button"
                    onClick={onBack}
                    className="px-8 py-3 text-base font-medium text-gray-700 border-2 border-gray-300 rounded-lg hover:bg-gray-50 transition"
                  >
                    ← Back
                  </button>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-12 py-3 bg-gradient-to-r from-purple-600 to-purple-500 text-white font-bold rounded-lg hover:from-purple-700 hover:to-purple-600 shadow-lg disabled:opacity-70"
                  >
                    {isSubmitting ? "Saving..." : "Next →"}
                  </button>
                </div>
              </Form>
            )}
          </Formik>
        </div>
      </div>
    </div>
  );
}
