import { Formik, Form, Field, FieldArray, ErrorMessage } from "formik";
import * as Yup from "yup";
import { Plus, Trash2 } from "lucide-react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const validationSchema = Yup.object({
  experience: Yup.array()
    .of(
      Yup.object({
        company: Yup.string().required("Company is required"),
        role: Yup.string().required("Role is required"),
        duration: Yup.string().required("Duration is required"),
        current: Yup.boolean(),
      })
    )
    .min(1, "Add at least one experience entry"),
});

export default function ExperienceForm({ data = {}, onNext, onBack, isLast }) {
  const initialValues = {
    experience: data.experience || [],
  };

  const handleSubmit = (values, { setSubmitting }) => {
    setTimeout(() => {
      onNext({ experience: values.experience });
      toast.success("Experience section saved!");
      setSubmitting(false);
    }, 600);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <ToastContainer position="top-right" autoClose={3000} />

      <div className="bg-white rounded-3xl shadow-xl w-full max-w-4xl overflow-hidden">

        {/* Purple Header */}
        <div className="bg-gradient-to-r from-purple-600 to-purple-500 text-white font-bold py-4 text-center text-xl rounded-t-3xl">
          Add Your Experience
        </div>

        <div className="p-4 lg:p-6">
          <Formik
            initialValues={initialValues}
            validationSchema={validationSchema}
            onSubmit={handleSubmit}
          >
            {({ values, isSubmitting }) => (
              <Form className="space-y-8">
                <FieldArray name="experience">
                  {({ push, remove }) => (
                    <>
                      {/* Add Button */}
                      <button
                        type="button"
                        onClick={() =>
                          push({
                            company: "",
                            role: "",
                            duration: "",
                            current: false,
                          })
                        }
                        className="flex items-center gap-3 px-6 py-3 bg-gradient-to-r from-purple-600 to-purple-500 text-white font-semibold rounded-lg shadow hover:from-purple-700 hover:to-purple-600 transition"
                      >
                        <Plus size={22} /> Add Experience
                      </button>

                      {/* Experience Items */}
                      {values.experience.map((exp, index) => (
                        <div
                          key={index}
                          className="p-6 border border-gray-300 rounded-2xl space-y-6 shadow-sm"
                        >
                          {/* Company */}
                          <div>
                            <label className="block text-gray-700 text-sm font-medium mb-1">
                              Company <span className="text-red-500">*</span>
                            </label>
                            <Field
                              name={`experience.${index}.company`}
                              placeholder="Company Name"
                              className="w-full px-4 py-3 text-base border border-gray-300 rounded-lg focus:border-purple-500 outline-none transition"
                            />
                            <ErrorMessage
                              name={`experience.${index}.company`}
                              component="div"
                              className="text-red-500 text-xs mt-1"
                            />
                          </div>

                          {/* Role */}
                          <div>
                            <label className="block text-gray-700 text-sm font-medium mb-1">
                              Role <span className="text-red-500">*</span>
                            </label>
                            <Field
                              name={`experience.${index}.role`}
                              placeholder="Senior Developer"
                              className="w-full px-4 py-3 text-base border border-gray-300 rounded-lg focus:border-purple-500 outline-none transition"
                            />
                            <ErrorMessage
                              name={`experience.${index}.role`}
                              component="div"
                              className="text-red-500 text-xs mt-1"
                            />
                          </div>

                          {/* Duration */}
                          <div>
                            <label className="block text-gray-700 text-sm font-medium mb-1">
                              Duration <span className="text-red-500">*</span>
                            </label>
                            <Field
                              name={`experience.${index}.duration`}
                              placeholder="2020 - Present"
                              className="w-full px-4 py-3 text-base border border-gray-300 rounded-lg focus:border-purple-500 outline-none transition"
                            />
                            <ErrorMessage
                              name={`experience.${index}.duration`}
                              component="div"
                              className="text-red-500 text-xs mt-1"
                            />
                          </div>

                          {/* Checkbox */}
                          <label className="flex items-center gap-3">
                            <Field
                              type="checkbox"
                              name={`experience.${index}.current`}
                              className="h-5 w-5"
                            />
                            <span className="text-base text-gray-700">
                              Currently working here
                            </span>
                          </label>

                          {/* Remove Button */}
                          <button
                            type="button"
                            onClick={() => remove(index)}
                            className="text-red-600 flex items-center gap-2 font-medium"
                          >
                            <Trash2 size={22} /> Remove
                          </button>
                        </div>
                      ))}
                    </>
                  )}
                </FieldArray>

                {/* Navigation Buttons */}
                <div className="flex justify-between items-center pt-8 border-t border-gray-200 mt-6">
                  <button
                    type="button"
                    onClick={onBack}
                    className="px-8 py-3 text-base font-medium text-gray-700 border-2 border-gray-300 rounded-lg hover:bg-gray-50 transition"
                  >
                    ← Back
                  </button>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-12 py-3 bg-gradient-to-r from-purple-600 to-purple-500 text-white font-bold text-base rounded-lg hover:from-purple-700 hover:to-purple-600 transition disabled:opacity-70 shadow-lg"
                  >
                    {isSubmitting ? "Saving..." : isLast ? "Finish Setup" : "Next →"}
                  </button>
                </div>

              </Form>
            )}
          </Formik>
        </div>
      </div>
    </div>
  );
}
