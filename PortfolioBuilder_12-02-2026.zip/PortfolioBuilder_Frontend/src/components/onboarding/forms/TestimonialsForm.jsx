// src/components/onboarding/forms/TestimonialsForm.jsx
import { useState } from "react";
import { Plus, Trash2 } from "lucide-react";

export default function TestimonialsForm({ data = {}, onNext, onBack }) {
  const [items, setItems] = useState(data.testimonials || []);

  const add = () =>
    setItems([
      ...items,
      { name: "", role: "", company: "", text: "", rating: 5 },
    ]);

  const update = (i, field, value) => {
    const updated = [...items];
    updated[i][field] = value;
    setItems(updated);
  };

  const remove = (i) => setItems(items.filter((_, idx) => idx !== i));

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="bg-white rounded-3xl shadow-xl w-full max-w-4xl overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-600 to-purple-500 text-white font-bold py-4 text-center text-xl rounded-t-3xl">
          Client Testimonials
        </div>

        {/* Content */}
        <div className="p-6 space-y-8">
          {/* Add button */}
          <button
            onClick={add}
            className="flex items-center gap-3 px-6 py-3 bg-gradient-to-r from-purple-600 to-purple-500 text-white font-semibold rounded-xl shadow hover:from-purple-700 hover:to-purple-600 transition"
          >
            <Plus size={22} /> Add Testimonial
          </button>

          {/* Testimonials */}
          {items.map((t, i) => (
            <div
              key={i}
              className="p-6 border border-gray-300 rounded-2xl space-y-6 shadow-sm bg-white"
            >
              <input
                value={t.name}
                onChange={(e) => update(i, "name", e.target.value)}
                placeholder="Client Name"
                className="w-full px-4 py-3 text-lg font-semibold border rounded-lg"
              />

              <input
                value={t.role}
                onChange={(e) => update(i, "role", e.target.value)}
                placeholder="Client Role (e.g., CEO)"
                className="w-full px-4 py-3 border rounded-lg"
              />

              <input
                value={t.company}
                onChange={(e) => update(i, "company", e.target.value)}
                placeholder="Company Name"
                className="w-full px-4 py-3 border rounded-lg"
              />

              <textarea
                value={t.text}
                onChange={(e) => update(i, "text", e.target.value)}
                rows={4}
                placeholder="Testimonial text..."
                className="w-full px-4 py-3 border rounded-lg resize-none"
              />

              {/* Rating */}
              <div>
                <label className="block text-gray-700 font-medium mb-1">
                  Rating (1–5)
                </label>
                <input
                  type="number"
                  min={1}
                  max={5}
                  value={t.rating}
                  onChange={(e) => update(i, "rating", e.target.value)}
                  className="w-28 px-4 py-2 border rounded-lg"
                />
              </div>

              {/* Remove */}
              <div className="flex justify-end">
                <button
                  onClick={() => remove(i)}
                  className="text-red-600 flex items-center gap-2 font-medium"
                >
                  <Trash2 size={20} /> Remove
                </button>
              </div>
            </div>
          ))}

          {/* Navigation */}
          <div className="flex justify-between pt-8 border-t">
            <button
              onClick={onBack}
              className="px-10 py-3 text-base font-medium text-gray-700 border-2 border-gray-300 rounded-xl hover:bg-gray-50 transition"
            >
              ← Back
            </button>

            <button
              onClick={() => onNext({ testimonials: items })}
              className="px-12 py-3 bg-gradient-to-r from-purple-600 to-purple-500 text-white font-bold rounded-xl hover:from-purple-700 hover:to-purple-600 shadow-lg"
            >
              Next →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
