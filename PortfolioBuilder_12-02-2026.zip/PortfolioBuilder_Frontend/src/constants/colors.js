export const COLORS = {
  primary: '#6D28D9',      // purple-700 ish main
  primaryLight: '#A78BFA',  // lighter purple for gradients/hover
  primaryDark: '#5B21B6',   // darker for hover
  gradientStart: '#7C3AED', // purple
  gradientMid: '#7C3AED',   // pinkish
  gradientEnd: '#F472B6',   // coral/pink
  textPrimary: '#1F2937',   // gray-800 dark text
  textSecondary: '#4B5563', // gray-600
  textLight: '#9CA3AF',     // gray-400
  bgLight: '#F9FAFB',       // gray-50
  white: '#FFFFFF',
  error: '#EF4444',
};