export default function Footer() {
  return (
    <footer className="bg-black text-white py-12">
      <div className="max-w-7xl mx-auto px-6 text-center">
        <h2 className="text-3xl font-bold mb-4">Your Portfolio is Live</h2>
        <p className="text-lg opacity-80 mb-8">
          Built with love • Powered by the best portfolio platform
        </p>
        <div className="flex justify-center gap-8 text-sm opacity-60 mb-8">
          <a href="#" className="hover:opacity-100 transition">Privacy</a>
          <a href="#" className="hover:opacity-100 transition">Terms</a>
          <a href="#" className="hover:opacity-100 transition">Support</a>
        </div>
        <p className="text-sm opacity-50">
          © 2025 Portfolio Builder. All rights reserved.
        </p>
      </div>
    </footer>
  );
}