

import { Link } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import { FiLogOut, FiSettings, FiHome, FiUser, FiMenu } from "react-icons/fi";
import { useState } from "react";

export default function Navbar({ setSidebarOpen }) {
  const { user, logout } = useAuth();
  const [dropdownOpen, setDropdownOpen] = useState(false);

  const initials = user?.name
    ? user.name.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2)
    : user?.username?.[0]?.toUpperCase() || "U";

  return (
    <nav className="h-full">
      <div className="h-full px-6 flex items-center justify-between">
        {/* Left - Logo + Mobile Menu */}
        <div className="flex items-center gap-4">
          <button
            onClick={() => setSidebarOpen(true)}
            className="lg:hidden p-2 rounded-lg hover:bg-gray-100"
          >
            <FiMenu size={24} />
          </button>

          <Link to="/dashboard" className="flex items-center gap-3">
            <div className="w-10 h-10 bg-black rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-xl">P</span>
            </div>
            <span className="font-bold text-xl hidden sm:block">Portfolio</span>
          </Link>
        </div>

        {/* Right - Profile Dropdown */}
        <div className="relative">
          <button
            onClick={() => setDropdownOpen(!dropdownOpen)}
            className="flex items-center gap-3 p-2 rounded-xl hover:bg-gray-100 transition"
          >
            <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-white font-bold text-lg shadow-md">
              {initials}
            </div>
            <div className="hidden sm:block text-left">
              <p className="text-sm text-gray-500">Welcome</p>
              <p className="font-medium text-base">{user?.name || user?.username}</p>
            </div>
          </button>

          {/* Dropdown Menu */}
          {dropdownOpen && (
            <>
              {/* Overlay */}
              <div
                className="fixed inset-0 z-40"
                onClick={() => setDropdownOpen(false)}
              />

              {/* Dropdown */}
              <div className="absolute right-0 mt-3 w-64 bg-white rounded-2xl shadow-2xl border border-gray-200 z-50 overflow-hidden">
                <div className="p-4 border-b border-gray-100">
                  <p className="font-semibold text-lg">{user?.name}</p>
                  <p className="text-sm text-gray-600">@{user?.username}</p>
                </div>

                <div className="py-2">
                  <Link
                    to="/dashboard"
                    onClick={() => setDropdownOpen(false)}
                    className="flex items-center gap-3 px-6 py-3 hover:bg-gray-100 transition"
                  >
                    <FiHome size={20} />
                    <span className="text-base">Dashboard</span>
                  </Link>

                  <Link
                    to="/profile"
                    onClick={() => setDropdownOpen(false)}
                    className="flex items-center gap-3 px-6 py-3 hover:bg-gray-100 transition"
                  >
                    <FiUser size={20} />
                    <span className="text-base">My Profile</span>
                  </Link>

                  <Link
                    to="/settings"
                    onClick={() => setDropdownOpen(false)}
                    className="flex items-center gap-3 px-6 py-3 hover:bg-gray-100 transition"
                  >
                    <FiSettings size={20} />
                    <span className="text-base">Settings</span>
                  </Link>
                </div>

                <div className="border-t border-gray-100">
                  <button
                    onClick={() => {
                      setDropdownOpen(false);
                      logout();
                    }}
                    className="w-full flex items-center gap-3 px-6 py-3 hover:bg-gray-100 transition text-red-600"
                  >
                    <FiLogOut size={20} />
                    <span className="text-base font-medium">Logout</span>
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}