// scripts/addPrebuiltThemes.js
// Run this once: node scripts/addPrebuiltThemes.js
// Adds 10 beautiful, diverse prebuilt themes to your database

import mongoose from 'mongoose';
import dotenv from 'dotenv';
import Theme from '../models/Theme.js';
import connectDB from '../config/db.js';

dotenv.config();
connectDB();

const themes = [
  {
    name: 'Clean Professional',
    description: 'Minimal and elegant theme perfect for professionals',
    previewImage: 'https://images.unsplash.com/photo-1498050108023-c63003c99b5e?w=1200&q=80',
    thumbnail: 'https://images.unsplash.com/photo-1498050108023-c63003c99b5e?w=600&q=80',
    category: 'all',
    tags: ['minimal', 'clean', 'professional', 'light'],
    design: {
      palette: {
        mode: 'light',
        colors: {
          primary: '#2563eb',
          secondary: '#3b82f6',
          accent: '#60a5fa'
        }
      },
      typography: {
        fontFamily: { heading: 'Inter, sans-serif', body: 'Inter, sans-serif' }
      },
      background: { type: 'solid', solid: '#ffffff' }
    },
    layoutConfig: {
      hero: 'centered',
      projects: 'grid',
      skills: 'bars',
      experience: 'cards',
      contact: { enabled: true }
    }
  },
  {
    name: 'Developer Dark',
    description: 'Modern dark theme for developers and coders',
    previewImage: 'https://images.unsplash.com/photo-1517180105309-9bd9e6867c3e?w=1200&q=80',
    thumbnail: 'https://images.unsplash.com/photo-1517180105309-9bd9e6867c3e?w=600&q=80',
    category: 'developer',
    tags: ['dark', 'code', 'developer', 'tech'],
    design: {
      palette: {
        mode: 'dark',
        colors: {
          primary: '#0ea5e9',
          secondary: '#38bdf8',
          accent: '#22d3ee'
        }
      },
      typography: {
        fontFamily: { heading: 'JetBrains Mono, monospace', body: 'Inter, sans-serif' }
      },
      background: { type: 'solid', solid: '#0f172a' }
    },
    layoutConfig: {
      hero: 'fullscreen',
      projects: 'masonry',
      skills: 'circles',
      experience: 'timeline',
      contact: { enabled: true }
    }
  },
  {
    name: 'Creative Agency',
    description: 'Bold and colorful theme for creative agencies and designers',
    previewImage: 'https://images.unsplash.com/photo-1558655146-9f40138ed1cb?w=1200&q=80',
    thumbnail: 'https://images.unsplash.com/photo-1558655146-9f40138ed1cb?w=600&q=80',
    category: 'designer',
    tags: ['bold', 'colorful', 'creative', 'agency'],
    design: {
      palette: {
        mode: 'light',
        colors: {
          primary: '#ec4899',
          secondary: '#f43f5e',
          accent: '#fb7185'
        }
      },
      typography: {
        fontFamily: { heading: 'Poppins, sans-serif', body: 'Poppins, sans-serif' }
      },
      background: {
        type: 'gradient',
        colors: ['#fdf4ff', '#fce7f3'],
        direction: 'to bottom right'
      }
    },
    layoutConfig: {
      hero: 'split',
      projects: 'carousel',
      skills: 'grid',
      experience: 'cards',
      contact: { enabled: true }
    }
  },
  {
    name: 'Photography Dark',
    description: 'Image-focused dark theme for photographers',
    previewImage: 'https://images.unsplash.com/photo-1502920917128-1dd8b6b9e9e2?w=1200&q=80',
    thumbnail: 'https://images.unsplash.com/photo-1502920917128-1dd8b6b9e9e2?w=600&q=80',
    category: 'photographer',
    tags: ['photography', 'dark', 'gallery', 'image'],
    design: {
      palette: {
        mode: 'dark',
        colors: {
          primary: '#f97316',
          secondary: '#fb923c',
          accent: '#fdba74'
        }
      },
      typography: {
        fontFamily: { heading: 'Playfair Display, serif', body: 'Inter, sans-serif' }
      },
      background: { type: 'solid', solid: '#0c0a09' }
    },
    layoutConfig: {
      hero: 'fullscreen',
      projects: 'masonry',
      skills: 'bars',
      experience: 'list',
      contact: { enabled: true }
    }
  },
  {
    name: 'Freelancer Gradient',
    description: 'Vibrant gradient theme for freelancers',
    previewImage: 'https://images.unsplash.com/photo-1557804506-669a67965ba0?w=1200&q=80',
    thumbnail: 'https://images.unsplash.com/photo-1557804506-669a67965ba0?w=600&q=80',
    category: 'freelancer',
    tags: ['gradient', 'modern', 'freelancer', 'vibrant'],
    design: {
      palette: {
        mode: 'light',
        colors: {
          primary: '#7c3aed',
          secondary: '#a78bfa',
          accent: '#c4b5fd'
        }
      },
      typography: {
        fontFamily: { heading: 'Space Grotesk, sans-serif', body: 'Inter, sans-serif' }
      },
      background: {
        type: 'gradient',
        colors: ['#faf5ff', '#e9d5ff'],
        direction: 'to bottom'
      }
    },
    layoutConfig: {
      hero: 'centered',
      projects: 'horizontal',
      skills: 'circles',
      experience: 'timeline',
      contact: { enabled: true }
    }
  },
  {
    name: 'Minimal White',
    description: 'Ultra-clean white space theme',
    previewImage: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=1200&q=80',
    thumbnail: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=600&q=80',
    category: 'minimal',
    tags: ['minimal', 'white', 'simple', 'clean'],
    design: {
      palette: {
        mode: 'light',
        colors: {
          primary: '#000000',
          secondary: '#262626',
          accent: '#525252'
        }
      },
      typography: {
        fontFamily: { heading: 'Helvetica, sans-serif', body: 'Helvetica, sans-serif' }
      },
      background: { type: 'solid', solid: '#ffffff' }
    },
    layoutConfig: {
      hero: 'minimal',
      projects: 'grid',
      skills: 'bars',
      experience: 'list',
      contact: { enabled: true }
    }
  },
  {
    name: 'Corporate Blue',
    description: 'Professional corporate theme with blue accent',
    previewImage: 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=1200&q=80',
    thumbnail: 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=600&q=80',
    category: 'agency',
    tags: ['corporate', 'professional', 'business', 'blue'],
    design: {
      palette: {
        mode: 'light',
        colors: {
          primary: '#1e40af',
          secondary: '#2563eb',
          accent: '#3b82f6'
        }
      },
      typography: {
        fontFamily: { heading: 'Roboto, sans-serif', body: 'Roboto, sans-serif' }
      },
      background: { type: 'solid', solid: '#f0f9ff' }
    },
    layoutConfig: {
      hero: 'split',
      projects: 'grid',
      skills: 'bars',
      experience: 'cards',
      contact: { enabled: true }
    }
  },
  {
    name: 'Bold Creative',
    description: 'High-contrast bold theme for creatives',
    previewImage: 'https://images.unsplash.com/photo-1581291518633-83b4ebd1d83e?w=1200&q=80',
    thumbnail: 'https://images.unsplash.com/photo-1581291518633-83b4ebd1d83e?w=600&q=80',
    category: 'bold',
    tags: ['bold', 'creative', 'contrast', 'dark'],
    design: {
      palette: {
        mode: 'dark',
        colors: {
          primary: '#f59e0b',
          secondary: '#f97316',
          accent: '#fb923c'
        }
      },
      typography: {
        fontFamily: { heading: 'Bebas Neue, sans-serif', body: 'Inter, sans-serif' }
      },
      background: { type: 'solid', solid: '#451a03' }
    },
    layoutConfig: {
      hero: 'fullscreen',
      projects: 'carousel',
      skills: 'grid',
      experience: 'timeline',
      contact: { enabled: true }
    }
  },
  {
    name: 'Writer Minimal',
    description: 'Clean, reading-focused theme for writers and bloggers',
    previewImage: 'https://images.unsplash.com/photo-1455390582262-044cdead277a?w=1200&q=80',
    thumbnail: 'https://images.unsplash.com/photo-1455390582262-044cdead277a?w=600&q=80',
    category: 'writer',
    tags: ['writer', 'minimal', 'reading', 'serif'],
    design: {
      palette: {
        mode: 'light',
        colors: {
          primary: '#374151',
          secondary: '#4b5563',
          accent: '#6b7280'
        }
      },
      typography: {
        fontFamily: { heading: 'Georgia, serif', body: 'Georgia, serif' }
      },
      background: { type: 'solid', solid: '#fffbeb' }
    },
    layoutConfig: {
      hero: 'centered',
      projects: 'grid',
      skills: 'bars',
      experience: 'list',
      contact: { enabled: true }
    }
  },
  {
    name: 'Modern Glass',
    description: 'Contemporary glassmorphism design with smooth effects',
    previewImage: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=1200&q=80',
    thumbnail: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&q=80',
    category: 'all',
    tags: ['modern', 'glass', 'blur', 'contemporary'],
    design: {
      palette: {
        mode: 'light',
        colors: {
          primary: '#8b5cf6',
          secondary: '#a78bfa',
          accent: '#c4b5fd'
        }
      },
      typography: {
        fontFamily: { heading: 'Manrope, sans-serif', body: 'Manrope, sans-serif' }
      },
      background: {
        type: 'gradient',
        colors: ['#fafaff', '#f0eaff'],
        direction: 'to bottom'
      }
    },
    layoutConfig: {
      hero: 'fullscreen',
      projects: 'horizontal',
      skills: 'circles',
      experience: 'cards',
      contact: { enabled: true }
    }
  }
];

const seedThemes = async () => {
  try {
    // Optional: Remove existing prebuilt themes first
    await Theme.deleteMany({ type: 'prebuilt' });
    console.log('Cleared existing prebuilt themes');

    // Insert new themes
    const inserted = await Theme.insertMany(
      themes.map(theme => ({
        ...theme,
        type: 'prebuilt',
        visibility: 'public'
      }))
    );

    console.log(`Successfully added ${inserted.length} prebuilt themes!`);
    console.log('Theme names:');
    inserted.forEach(t => console.log(`- ${t.name} (${t.themeId})`));

    process.exit(0);
  } catch (err) {
    console.error('Error seeding themes:', err);
    process.exit(1);
  }
};

seedThemes();