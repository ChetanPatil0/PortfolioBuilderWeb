
import React, { useEffect } from 'react';
import { X, CheckCircle, AlertCircle, Info, CalendarClock } from 'lucide-react';

const icons = {
  success: <CheckCircle size={40} />,
  error: <AlertCircle size={40} />,
  warning: <AlertCircle size={40} />,
  info: <Info size={40} />,
  reschedule: <CalendarClock size={40} />,
  custom: null,
};

const colorMap = {
  success: 'text-emerald-600 border-emerald-600 bg-emerald-600',
  error:   'text-red-600 border-red-600 bg-red-600',
  warning: 'text-amber-600 border-amber-600 bg-amber-600',
  info:    'text-blue-600 border-blue-600 bg-blue-600',
  reschedule: 'text-indigo-600 border-indigo-600 bg-indigo-600',
  custom:  'text-gray-600 border-gray-600 bg-gray-600',
};

export const MessageModal = ({
  visible,
  type = 'info',
  title = '',
  message,
  primaryButtonText,
  onPrimaryPress,
  secondaryButtonText,
  onSecondaryPress,
  icon,
  customColor,           // e.g. "purple-600"
  autoCloseMs,
  onClose,
  className = '',
}) => {
  const color = customColor ? customColor : (colorMap[type] || 'text-gray-600 border-gray-600 bg-gray-600');
  const [iconColor, borderColor, bgColor] = color.split(' ');

  useEffect(() => {
    if (!visible) return;
    if (primaryButtonText || secondaryButtonText) return;

    const timer = setTimeout(() => {
      onClose?.();
    }, autoCloseMs ?? 3200);

    return () => clearTimeout(timer);
  }, [visible, primaryButtonText, secondaryButtonText, onClose, autoCloseMs]);

  if (!visible) return null;

  const showButtons = !!(primaryButtonText || secondaryButtonText);

  return (
    <div
      className={`fixed inset-0 bg-black/55 backdrop-blur-sm flex items-center justify-center z-[9999] animate-fadeIn ${className}`}
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-md mx-4 bg-white dark:bg-gray-800 rounded-2xl shadow-2xl p-7 animate-scaleIn"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition"
          onClick={onClose}
          aria-label="Close"
        >
          <X size={24} />
        </button>

        <div
          className={`mx-auto mb-5 w-16 h-16 rounded-full border-4 bg-white/90 dark:bg-gray-900/70 flex items-center justify-center ${borderColor}`}
        >
          <div className={`${iconColor}`}>
            {icon || icons[type]}
          </div>
        </div>

        {title && (
          <h2 className={`text-2xl font-bold text-center mb-3 ${iconColor}`}>
            {title}
          </h2>
        )}

        <p className="text-gray-600 dark:text-gray-300 text-center text-[1.05rem] leading-relaxed mb-7">
          {message}
        </p>

        {showButtons && (
          <div className="flex flex-wrap gap-4 justify-center">
            {secondaryButtonText && (
              <button
                onClick={() => {
                  onSecondaryPress?.();
                  onClose?.();
                }}
                className="px-6 py-2.5 text-sm font-semibold rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-700/70 transition active:scale-97 min-w-[110px]"
              >
                {secondaryButtonText}
              </button>
            )}

            {primaryButtonText && (
              <button
                onClick={() => {
                  onPrimaryPress?.();
                  onClose?.();
                }}
                className={`px-6 py-2.5 text-sm font-semibold rounded-lg text-white hover:opacity-90 active:scale-97 transition min-w-[110px] ${bgColor}`}
              >
                {primaryButtonText}
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};