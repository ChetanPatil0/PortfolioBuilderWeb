// // controllers/portfolioController.js
// import Portfolio from '../models/Portfolio.js';
// import Theme from '../models/Theme.js';






// export const getMyPortfolio = async (req, res) => {
//   try {
//     let portfolio = await Portfolio.findOne({ user_id: req.user.user_id })
//       .populate('appearance.theme')
//       .lean();

//     if (!portfolio) {
//       // Auto-create on first visit
//       portfolio = await Portfolio.create({
//         user_id: req.user.user_id,
//         username: req.user.username,
//         sections: {}, // will use defaults
//         appearance: { theme: null },
//         settings: { isPublic: true }
//       });
//     }

//     // Always attach activeTheme for frontend
//     const activeTheme = portfolio.appearance?.theme || {
//       name: 'Default Light',
//       design: {
//         background: { type: 'color', color: '#ffffff' },
//         colors: { primary: '#3b82f6', text: '#1f2937', background: '#f8fafc' },
//         font: 'Inter'
//       }
//     };

//     res.json({
//       success: true,
//       portfolio: {
//         ...portfolio,
//         activeTheme // ← THIS IS THE KEY
//       }
//     });
//   } catch (err) {
//     console.error(err);
//     res.status(500).json({ message: 'Server error' });
//   }
// };

// // 2. UPDATE PORTFOLIO (Perfect — just add activeTheme in response)
// export const updatePortfolio = async (req, res) => {
//   try {
//     const updates = req.body;

//     const portfolio = await Portfolio.findOneAndUpdate(
//       { user_id: req.user.user_id },
//       { $set: updates },
//       { new: true, runValidators: true, upsert: true }
//     ).populate('appearance.theme');

//     const activeTheme = portfolio.appearance?.theme || {
//       name: 'Default Light',
//       design: { background: { type: 'color', color: '#ffffff' }, colors: { primary: '#3b82f6' } }
//     };

//     res.json({
//       success: true,
//       portfolio: {
//         ...portfolio.toObject(),
//         activeTheme
//       }
//     });
//   } catch (err) {
//     res.status(400).json({ message: err.message });
//   }
// };




// export const getPublicPortfolio = async (req, res) => {
//   try {
//     const { username } = req.params;

//     // 1. Find the portfolio (lean for performance)
//     const portfolio = await Portfolio.findOne({ username })
//       .populate('appearance.theme')
//       .lean();

//     // 2. Portfolio does not exist → 404
//     if (!portfolio) {
//       return res.status(404).json({ message: 'Portfolio not found' });
//     }

//     // 3. Check privacy – adjust the field name to match your schema
//     const isPrivate = portfolio.isPublic === false || portfolio.privacy === 'private';

//     // If it's private AND the requester is not the owner (or not logged in)
//     const isOwner = req.user && req.user.username === username;

//     if (isPrivate && !isOwner) {
//       return res.status(403).json({
//         message: 'This portfolio is private',
//         private: true,
//       });
//     }

//     // 4. Determine active theme
//     let activeTheme = portfolio.appearance?.theme;

//     // Preview mode (only allowed for the owner or when explicitly requested)
//     if (req.query.preview && isOwner) {
//       const previewTheme = await Theme.findOne({ themeId: req.query.preview }).lean();
//       if (previewTheme) activeTheme = previewTheme;
//     }

//     // Fallback default theme if nothing is set
//     if (!activeTheme) {
//       activeTheme = {
//         name: 'Default',
//         design: {
//           // your default design object
//           primaryColor: '#6366f1',
//           background: '#ffffff',
//           // …other defaults
//         },
//       };
//     }

//     // 5. Send the portfolio (hide sensitive fields if you want)
//     res.json({
//       portfolio: {
//         ...portfolio,
//         activeTheme,
//         // optionally omit sensitive paths
//         // _id: undefined,
//         // password: undefined,
//       },
//     });
//   } catch (err) {
//     console.error('getPublicPortfolio error →', err);
//     res.status(500).json({ message: 'Server error' });
//   }
// };




// controllers/portfolioController.js
import Portfolio from '../models/Portfolio.js';
import Theme from '../models/Theme.js';

export const getMyPortfolio = async (req, res) => {
  try {
    let portfolio = await Portfolio.findOne({ user_id: req.user.user_id })
      .populate({
        path: 'appearance.theme',
        select: 'design layoutConfig name previewImage'
      })
      .lean();

    if (!portfolio) {
      // Auto-create portfolio if not exists
      portfolio = await Portfolio.create({
        user_id: req.user.user_id,
        username: req.user.username,
        sections: {},
        appearance: { theme: null },
        settings: { isPublic: true },
        analytics: { views: 0 }
      });
    }

    const activeTheme = portfolio.appearance?.theme || {
      name: 'Default Light',
      design: {
        palette: { colors: { primary: '#6366f1' } },
        typography: { fontFamily: { heading: 'Inter' } }
      },
      layoutConfig: { hero: 'fullscreen', projects: 'grid' }
    };

    res.json({
      success: true,
      portfolio: {
        ...portfolio,
        activeTheme
      }
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
};

export const updatePortfolio = async (req, res) => {
  try {
    const updates = req.body;

    const portfolio = await Portfolio.findOneAndUpdate(
      { user_id: req.user.user_id },
      { $set: updates },
      { new: true, runValidators: true, upsert: true }
    ).populate({
      path: 'appearance.theme',
      select: 'design layoutConfig name previewImage'
    });

    const activeTheme = portfolio.appearance?.theme || {
      name: 'Default Light',
      design: { palette: { colors: { primary: '#6366f1' } } },
      layoutConfig: { hero: 'fullscreen' }
    };

    res.json({
      success: true,
      portfolio: {
        ...portfolio.toObject(),
        activeTheme
      }
    });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

export const getPublicPortfolio = async (req, res) => {
  try {
    const { username } = req.params;

    const portfolio = await Portfolio.findOne({ username })
      .populate({
        path: 'appearance.theme',
        select: 'design layoutConfig name previewImage'
      })
      .lean();

    if (!portfolio) {
      return res.status(404).json({ message: 'Portfolio not found' });
    }

    const isPrivate = portfolio.settings?.isPublic === false;
    const isOwner = req.user && req.user.username === username;

    if (isPrivate && !isOwner) {
      return res.status(403).json({ message: 'This portfolio is private', private: true });
    }

    // Increment views only for non-owners
    if (!isOwner) {
      await Portfolio.findOneAndUpdate(
        { username },
        {
          $inc: { 'analytics.views': 1 },
          $set: { 'analytics.lastViewed': new Date() }
        }
      );
    }

    let activeTheme = portfolio.appearance?.theme;

    // Preview mode (only for owner)
    if (req.query.preview && isOwner) {
      const previewTheme = await Theme.findOne({ themeId: req.query.preview })
        .select('design layoutConfig name previewImage')
        .lean();
      if (previewTheme) activeTheme = previewTheme;
    }

    // Fallback default theme
    if (!activeTheme) {
      activeTheme = {
        name: 'Default Light',
        design: {
          palette: { colors: { primary: '#6366f1', text: { primary: '#111827' } } },
          typography: { fontFamily: { heading: 'Inter' } }
        },
        layoutConfig: {
          hero: 'fullscreen',
          projects: 'grid',
          skills: 'bars',
          contact: { enabled: true }
        }
      };
    }

    res.json({
      portfolio: {
        ...portfolio,
        activeTheme
      }
    });
  } catch (err) {
    console.error('getPublicPortfolio error ', err);
    res.status(500).json({ message: 'Server error' });
  }
};