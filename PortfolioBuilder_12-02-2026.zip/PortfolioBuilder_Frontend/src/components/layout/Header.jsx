// src/components/layout/Header.jsx
import { useAuth } from "../../context/AuthContext";

export default function Header() {
  const { user } = useAuth();

  return (
    <header className="bg-gradient-to-r from-purple-600 to-purple-500 text-white px-8 py-4 shadow-md">
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        
        {/* Left: Greeting */}
        <h2 className="text-xl font-semibold">
          Hi, <span className="font-bold">{user?.name}</span>
        </h2>

        {/* Right: Portfolio Link */}
        <div className="flex items-center gap-4">
          <span className="text-sm opacity-90">Your Portfolio:</span>

          <a
            href={`/${user?.username}`}
            target="_blank"
            className="text-sm font-medium bg-white/20 backdrop-blur px-4 py-2 rounded-lg 
                       hover:bg-white/30 transition border border-white/20"
          >
            portfolio.com/{user?.username}
          </a>
        </div>
      </div>
    </header>
  );
}
