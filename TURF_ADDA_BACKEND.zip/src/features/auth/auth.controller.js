import User from './auth.model.js';
import { generateOTP, sendOTP } from '../../utils/otp.js';
import { signToken } from '../../utils/jwt.js';
import { sendError, sendSuccess } from '../../utils/errorHandler.js';

export const register = async (req, res) => {
  try {
    const { firstName, middleName, lastName, mobile, email, password, role } = req.body;

    const allowedRoles = ['player', 'owner', 'staff'];
    if (!allowedRoles.includes(role)) {
      return sendError(res, 400, 'Invalid role');
    }

    let user = await User.findOne({ mobile });
    if (user) {
      return sendError(res, 400, 'Mobile already registered');
    }

    user = new User({
      firstName,
      middleName: middleName || null,
      lastName,
      mobile,
      email: email || null,
      password: password || null,
      role,
    });

    const otp = generateOTP();
    user.otp = otp;
    user.otpExpiry = Date.now() + 10 * 60 * 1000;

    await user.save();
    sendOTP(mobile, otp);

    return sendSuccess(res, { userId: user.id }, `OTP sent to mobile for ${role} registration`);
  } catch (error) {
    return sendError(res, 500, error.message || 'Server error');
  }
};

export const verifyOTP = async (req, res) => {
  try {
    const { mobile, otp } = req.body;

    const user = await User.findOne({ mobile });
    if (!user || user.otp !== otp || user.otpExpiry < Date.now()) {
      return sendError(res, 400, 'Invalid or expired OTP');
    }

    user.isVerifiedMobile = true;
    user.otp = null;
    user.otpExpiry = null;
    await user.save();

    const token = signToken({ id: user.id, role: user.role });

    return sendSuccess(res, {
      token,
      user: {
        id: user.id,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role,
        mobile: user.mobile,
      }
    }, 'OTP verified successfully');
  } catch (error) {
    return sendError(res, 500, 'Server error');
  }
};

export const login = async (req, res) => {
  try {
    const { mobile, password } = req.body;

    const user = await User.findOne({ mobile });
    if (!user || !user.isVerifiedMobile) {
      return sendError(res, 401, 'Invalid credentials or not verified');
    }

    if (!user.password || !(await user.comparePassword(password))) {
      return sendError(res, 401, 'Invalid password');
    }

    const token = signToken({ id: user.id, role: user.role });

    return sendSuccess(res, {
      token,
      user: {
        id: user.id,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role,
      }
    }, 'Login successful');
  } catch (error) {
    return sendError(res, 500, 'Server error');
  }
};

export const updateProfile = async (req, res) => {
  try {
    const userId = req.user.id;
    const updates = req.body;

    if (req.file) {
      updates.profileImage = req.file.path;
    }

    delete updates.role;
    delete updates.status;

    const user = await User.findOneAndUpdate(
      { id: userId },
      { $set: updates },
      { new: true, runValidators: true }
    );

    if (!user) {
      return sendError(res, 404, 'User not found');
    }

    return sendSuccess(res, {
      id: user.id,
      firstName: user.firstName,
      lastName: user.lastName,
      mobile: user.mobile,
      email: user.email,
      profileImage: user.profileImage,
      country: user.country,
      state: user.state,
      city: user.city,
      area: user.area,
      gender: user.gender,
      preferredSports: user.preferredSports,
    }, 'Profile updated successfully');
  } catch (error) {
    return sendError(res, 500, 'Server error');
  }
};