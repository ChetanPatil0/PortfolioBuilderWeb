// src/services/portfolioService.js
import api from './api';

export const portfolioService = {
  // 1. Get my full portfolio (including populated activeTheme)
  getMyPortfolio: () => api.get('/portfolio/me'),

  // 2. Update any part of the portfolio (single or multiple fields)
  //    → Most flexible method — used for everything: settings, sections, theme, etc.
  updatePortfolio: (updates) => api.put('/portfolio/me', updates),

  // 3. Toggle visibility of a single section (enabled/disabled)
  toggleSection: (sectionKey, enabled) =>
    api.put('/portfolio/me', {
      [`sections.${sectionKey}.enabled`]: enabled,
    }),

  // 4. Save/update data of a single section (hero, about, experience, etc.)
  saveSection: (sectionKey, sectionData) =>
    api.put('/portfolio/me', {
      [`sections.${sectionKey}.data`]: sectionData,
      [`sections.${sectionKey}.enabled`]: true, // usually enable when saving
    }),

  // 5. Batch save multiple sections at once (used by "Save All")
  //    Expects: { hero: {...}, about: {...}, experience: [...] }
  saveMultipleSections: (sectionsData) => {
    const payload = {};
    Object.entries(sectionsData).forEach(([key, value]) => {
      payload[`sections.${key}.data`] = value.data ?? value;
      payload[`sections.${key}.enabled`] = value.enabled ?? true;
    });
    return api.put('/portfolio/me', payload);
  },

  // 6. Change active theme
  setActiveTheme: (themeId) =>
    api.put('/portfolio/me', {
      'appearance.theme': themeId,
    }),

  // 7. Toggle portfolio public/private
  setPublic: (isPublic) =>
    api.put('/portfolio/me', {
      'settings.isPublic': isPublic,
    }),

  // 8. Update portfolio URL / username (if allowed)
  updateUsername: (newUsername) =>
    api.put('/portfolio/me', {
      username: newUsername,
    }),

  // 9. Utility: Check if user still needs to complete onboarding
  isOnboardingNeeded: (portfolio) => {
    if (!portfolio) return true;
    if (!portfolio.sections?.hero?.data?.name) return true;
    if (!portfolio.sections?.about?.data?.text) return true;
    // Optional: add more required fields
    // if (!portfolio.sections?.projects?.data?.length) return true;
    return false;
  },

  // 10. (Optional) Get public portfolio by username (for preview or share)
  getPublicPortfolio: (username) => api.get(`/portfolio/public/${username}`),
};

export default portfolioService;