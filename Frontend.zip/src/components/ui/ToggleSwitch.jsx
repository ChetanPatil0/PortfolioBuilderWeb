// src/components/ui/ToggleSwitch.jsx
export default function ToggleSwitch({ checked, onChange, label }) {
  return (
    <label className="flex items-center justify-between cursor-pointer">
      <span className="text-xl font-medium">{label}</span>
      <div className="relative">
        <input type="checkbox" checked={checked} onChange={onChange} className="sr-only" />
        <div className={`w-16 h-9 rounded-full transition ${checked ? 'bg-black' : 'bg-gray-300'}`}>
          <div className={`absolute top-1 w-7 h-7 bg-white rounded-full transition ${checked ? 'translate-x-7' : 'translate-x-1'}`} />
        </div>
      </div>
    </label>
  );
}