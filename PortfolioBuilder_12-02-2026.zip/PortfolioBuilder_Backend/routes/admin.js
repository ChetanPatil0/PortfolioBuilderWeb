
import { Router } from 'express';
import { protect, adminOnly } from '../middleware/auth.js';
import {
  getAllUsers,
  getUserPortfolioAnalytics,
  createPrebuiltTheme,
  getPrebuiltThemes,
  updatePrebuiltTheme,
  deletePrebuiltTheme
} from '../controllers/adminController.js';

const router = Router();

router.use(protect);
router.use(adminOnly);

// User Management
router.get('/users', getAllUsers); // GET /api/admin/users → List all users with basic info + analytics
router.get('/users/:username/analytics', getUserPortfolioAnalytics); // GET /api/admin/users/johndoe/analytics → Specific user analytics

// Prebuilt Theme Management (Admin only)
router.post('/themes/prebuilt', createPrebuiltTheme); // POST /api/admin/themes/prebuilt → Create new prebuilt theme
router.get('/themes/prebuilt', getPrebuiltThemes); // GET /api/admin/themes/prebuilt → List all prebuilt themes
router.put('/themes/prebuilt/:id', updatePrebuiltTheme); // PUT /api/admin/themes/prebuilt/123 → Update theme
router.delete('/themes/prebuilt/:id', deletePrebuiltTheme); // DELETE /api/admin/themes/prebuilt/123 → Delete theme

export default router;