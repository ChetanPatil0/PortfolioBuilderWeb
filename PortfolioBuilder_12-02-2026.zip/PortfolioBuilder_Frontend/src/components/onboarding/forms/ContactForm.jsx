// src/components/onboarding/forms/ContactForm.jsx
import { useState } from "react";

export default function ContactForm({ data = {}, onNext, onBack, isLast }) {
  const [form, setForm] = useState({
    email: data.contact?.email || "",
    phone: data.contact?.phone || "",
    location: data.contact?.location || "",
    availability: data.contact?.availability || "Open to work",
    linkedin: data.contact?.socials?.linkedin || "",
    github: data.contact?.socials?.github || "",
    twitter: data.contact?.socials?.twitter || "",
    instagram: data.contact?.socials?.instagram || "",
  });

  const update = (field, value) => {
    setForm({ ...form, [field]: value });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="bg-white rounded-3xl shadow-xl w-full max-w-4xl overflow-hidden">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-600 to-purple-500 text-white font-bold py-4 text-center text-xl rounded-t-3xl">
          Contact Information
        </div>

        {/* Content Section */}
        <div className="p-8 space-y-8">
          
          {/* Email */}
          <input
            value={form.email}
            onChange={(e) => update("email", e.target.value)}
            placeholder="Email"
            className="w-full px-6 py-4 text-lg border rounded-xl"
          />

          {/* Phone */}
          <input
            value={form.phone}
            onChange={(e) => update("phone", e.target.value)}
            placeholder="Phone (optional)"
            className="w-full px-6 py-4 text-lg border rounded-xl"
          />

          {/* Location */}
          <input
            value={form.location}
            onChange={(e) => update("location", e.target.value)}
            placeholder="City, Country"
            className="w-full px-6 py-4 text-lg border rounded-xl"
          />

          {/* Availability */}
          <input
            value={form.availability}
            onChange={(e) => update("availability", e.target.value)}
            placeholder="Open to freelance"
            className="w-full px-6 py-4 text-lg border rounded-xl"
          />

          {/* Social Links */}
          <div className="grid grid-cols-2 gap-6">
            <input
              value={form.linkedin}
              onChange={(e) => update("linkedin", e.target.value)}
              placeholder="LinkedIn URL"
              className="w-full px-6 py-4 border rounded-xl"
            />

            <input
              value={form.github}
              onChange={(e) => update("github", e.target.value)}
              placeholder="GitHub URL"
              className="w-full px-6 py-4 border rounded-xl"
            />

            <input
              value={form.twitter}
              onChange={(e) => update("twitter", e.target.value)}
              placeholder="Twitter URL"
              className="w-full px-6 py-4 border rounded-xl"
            />

            <input
              value={form.instagram}
              onChange={(e) => update("instagram", e.target.value)}
              placeholder="Instagram URL"
              className="w-full px-6 py-4 border rounded-xl"
            />
          </div>

          {/* Navigation Buttons */}
          <div className="flex justify-between pt-10 border-t">
            <button
              onClick={onBack}
              className="px-10 py-3 text-base font-medium text-gray-700 border-2 border-gray-300 rounded-xl hover:bg-gray-50 transition"
            >
              ← Back
            </button>

            <button
              onClick={() => onNext({ contact: form })}
              className="px-12 py-3 bg-gradient-to-r from-purple-600 to-purple-500 text-white font-bold rounded-xl hover:from-purple-700 hover:to-purple-600 shadow-lg"
            >
              {isLast ? "Finish & Launch Portfolio" : "Next →"}
            </button>
          </div>

        </div>
      </div>
    </div>
  );
}
