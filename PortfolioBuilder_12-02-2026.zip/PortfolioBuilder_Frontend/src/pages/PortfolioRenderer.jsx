// src/components/PortfolioRenderer.jsx
import React from "react";

export default function PortfolioRenderer({
  portfolioData,
  onContactSubmit,
  messageStatus,
  isPreview = false,
}) {

  console.log('portfolio data : ',portfolioData)
  // Early return if no data at all
  if (!portfolioData) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-900 text-white text-2xl">
        No portfolio data available
      </div>
    );
  }

  // Safely destructure with defaults
  const { sections = {}, activeTheme = {}, username } = portfolioData;

  const d = activeTheme?.design || {};
  const l = activeTheme?.layoutConfig || {};

  const palette = d.palette?.colors || {};
  const text = palette.text || {};
  const bg = palette.background || {};
  const typography = d.typography || {};
  const effects = d.effects || {};
  const backgroundConfig = d.background || {};
  const spacing = d.spacing || {};

  const fontSize = typography.fontSizes || {};
  const fs = (key) => fontSize[key] || '1rem';

  let backgroundStyle = {};
  if (backgroundConfig.type === 'gradient' && backgroundConfig.gradient?.colors?.length > 0) {
    backgroundStyle.background = `linear-gradient(${
      backgroundConfig.gradient.direction || 'to bottom'
    }, ${backgroundConfig.gradient.colors.join(', ')})`;
  } else if (backgroundConfig.type === 'image' && backgroundConfig.image?.url) {
    backgroundStyle.background = `url(${backgroundConfig.image.url}) center/cover no-repeat fixed`;
    backgroundStyle.backgroundAttachment = 'fixed';
  } else {
    backgroundStyle.background = backgroundConfig.solid || bg.default || '#0f0f0f';
  }

  const headingFont = typography.fontFamily?.heading || 'serif';
  const bodyFont = typography.fontFamily?.body || 'sans-serif';

  const br = (size) => (effects.borderRadius && effects.borderRadius[size]) || '0.5rem';
  const shadow = (size) => (effects.shadows && effects.shadows[size]) || '0 4px 6px rgba(0,0,0,0.1)';
  const sectionPadding = spacing.sectionVertical || '7rem';

  const navLinks = [];
  if (sections.hero?.enabled) navLinks.push({ id: 'home', label: 'Home' });
  (l.defaultSectionsOrder || []).forEach((section) => {
    if (section !== 'hero' && sections[section]?.enabled) {
      const label = section.charAt(0).toUpperCase() + section.slice(1).replace(/([A-Z])/g, ' $1').trim();
      navLinks.push({ id: section, label });
    }
  });

  const containerClass = 'max-w-7xl mx-auto px-6';

  return (
    <div
      style={{
        ...backgroundStyle,
        color: text.primary || '#ffffff',
        fontFamily: bodyFont,
        minHeight: '100vh',
      }}
      className="relative"
    >
      {/* Navbar */}
      {l.navbar?.enabled !== false && (
        <nav
          className="fixed top-0 left-0 right-0 z-50"
          style={{ background: 'rgba(15, 15, 15, 0.9)', backdropFilter: 'blur(12px)' }}
        >
          <div className={`${containerClass} py-6 flex justify-between items-center`}>
            <h1
              className="text-3xl font-bold"
              style={{ fontFamily: headingFont, color: palette.primary || '#ffd700' }}
            >
              {sections.hero?.data?.name || 'Portfolio'}
            </h1>
            {navLinks.length > 1 && (
              <div className="hidden md:flex items-center gap-10">
                {navLinks.map((link) => (
                  <a
                    key={link.id}
                    href={`#${link.id}`}
                    className="text-lg font-medium hover:opacity-80 transition"
                    style={{ color: text.primary || '#ffffff' }}
                  >
                    {link.label}
                  </a>
                ))}
              </div>
            )}
          </div>
        </nav>
      )}

      <main className={l.navbar?.enabled !== false ? 'pt-32' : ''}>
        {/* Hero - safe access */}
        {sections.hero?.enabled && (
          <section
            id="home"
            style={{ paddingTop: sectionPadding, paddingBottom: sectionPadding }}
            className={
              l.hero === 'fullscreen' || l.hero === 'centered'
                ? 'min-h-screen flex items-center justify-center'
                : ''
            }
          >
            <div
              className={`${containerClass} ${
                l.hero === 'split'
                  ? 'grid md:grid-cols-2 gap-16 items-center'
                  : l.hero === 'centered' || l.hero === 'minimal'
                  ? 'text-center'
                  : 'text-center'
              }`}
            >
              {(l.hero === 'split' || l.hero === 'fullscreen') && sections.hero.data?.avatar && (
                <div className={l.hero === 'split' ? 'order-1' : 'mx-auto mb-12'}>
                  <img
                    src={sections.hero.data.avatar}
                    alt="Avatar"
                    className="w-80 h-80 rounded-full object-cover shadow-2xl"
                    style={{
                      border: `10px solid ${palette.primary || '#ffd700'}`,
                      boxShadow: shadow('lg'),
                    }}
                  />
                </div>
              )}

              <div className={l.hero === 'split' ? 'order-2' : ''}>
                <h1 style={{ fontFamily: headingFont, fontSize: fs('6xl') }} className="font-black mb-6">
                  {sections.hero?.data?.name || ''}
                </h1>
                <p style={{ fontSize: fs('3xl'), color: text.secondary || palette.primary }} className="mb-10 opacity-90">
                  {sections.hero?.data?.title || ''}
                </p>
                <p style={{ fontSize: fs('xl') }} className="max-w-3xl leading-relaxed opacity-80 mb-12">
                  {sections.hero?.data?.bio || ''}
                </p>
                {sections.hero?.data?.ctaText && (
                  <a
                    href={sections.hero?.data?.ctaLink || '#contact'}
                    style={{
                      background: palette.primary || '#ffd700',
                      color: text.onPrimary || '#000',
                      borderRadius: br('full'),
                      fontSize: fs('2xl'),
                    }}
                    className="inline-block px-12 py-5 font-bold shadow-2xl hover:scale-105 transition"
                  >
                    {sections.hero?.data?.ctaText}
                  </a>
                )}
              </div>
            </div>
          </section>
        )}

        {/* About - safe */}
        {sections.about?.enabled && sections.about?.data?.text && (
          <section id="about" style={{ paddingTop: sectionPadding, paddingBottom: sectionPadding }} className="bg-black/50">
            <div className={`${containerClass} text-center`}>
              <h2 style={{ fontFamily: headingFont, fontSize: fs('5xl') }} className="font-bold mb-12">
                {sections.about?.data?.heading || 'About Me'}
              </h2>
              <div style={{ fontSize: fs('lg') }} className="max-w-4xl mx-auto leading-relaxed prose prose-invert">
                {(sections.about?.data?.text || '').split('\n').map((line, i) => (
                  <p key={i} className="mb-6">{line || <br />}</p>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Skills - safe */}
        {sections.skills?.enabled && Array.isArray(sections.skills?.data) && sections.skills.data.length > 0 && (
          <section id="skills" style={{ paddingTop: sectionPadding, paddingBottom: sectionPadding }} className="bg-black/30">
            <div className={containerClass}>
              <h2 style={{ fontFamily: headingFont, fontSize: fs('5xl') }} className="text-center mb-16 font-bold">
                Skills
              </h2>

              {l.skills === 'bars' && (
                <div className="max-w-4xl mx-auto space-y-10">
                  {sections.skills.data.map((skill, i) => (
                    <div key={i}>
                      <div className="flex justify-between mb-3">
                        <span style={{ fontSize: fs('lg') }} className="font-semibold">{skill.name || ''}</span>
                        <span style={{ fontSize: fs('lg') }}>{skill.level || 0}%</span>
                      </div>
                      <div className="h-10 rounded-full overflow-hidden" style={{ background: (palette.neutral && palette.neutral[800]) || '#333' }}>
                        <div
                          style={{
                            width: `${skill.level || 0}%`,
                            background: palette.primary || '#ffd700',
                            borderRadius: br('full'),
                          }}
                          className="h-full transition-all duration-1000"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {l.skills === 'circles' && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-12 max-w-5xl mx-auto">
                  {sections.skills.data.map((skill, i) => (
                    <div key={i} className="text-center">
                      <div className="relative w-40 h-40 mx-auto mb-4">
                        <svg className="w-40 h-40 transform -rotate-90">
                          <circle cx="80" cy="80" r="70" stroke="#333" strokeWidth="12" fill="none" />
                          <circle
                            cx="80"
                            cy="80"
                            r="70"
                            stroke={palette.primary || '#ffd700'}
                            strokeWidth="12"
                            fill="none"
                            strokeDasharray={`${2.2 * (skill.level || 0)} 220`}
                            className="transition-all duration-1000"
                          />
                        </svg>
                        <span className="absolute inset-0 flex items-center justify-center text-3xl font-bold">
                          {skill.level || 0}%
                        </span>
                      </div>
                      <p style={{ fontSize: fs('lg') }} className="font-medium">{skill.name || ''}</p>
                    </div>
                  ))}
                </div>
              )}

              {l.skills === 'grid' && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
                  {sections.skills.data.map((skill, i) => (
                    <div key={i} className="text-center p-6 rounded-2xl" style={{ background: bg.paper || '#1a1a1a', boxShadow: shadow('md') }}>
                      <p style={{ fontSize: fs('3xl') }} className="font-bold mb-2">{skill.level || 0}%</p>
                      <p style={{ fontSize: fs('lg') }}>{skill.name || ''}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </section>
        )}

        {/* Projects - safe */}
        {sections.projects?.enabled && Array.isArray(sections.projects?.data) && sections.projects.data.length > 0 && (
          <section id="projects" style={{ paddingTop: sectionPadding, paddingBottom: sectionPadding }}>
            <div className={containerClass}>
              <h2 style={{ fontFamily: headingFont, fontSize: fs('5xl') }} className="text-center mb-16 font-bold">
                Projects
              </h2>

              {l.projects === 'masonry' && (
                <div className="columns-1 md:columns-2 lg:columns-3 gap-8">
                  {sections.projects.data.map((p, i) => (
                    <div key={i} className="mb-8 break-inside-avoid" style={{ boxShadow: shadow('lg') }}>
                      <div className="overflow-hidden rounded-3xl" style={{ background: bg.paper || '#1a1a1a' }}>
                        {p.image && <img src={p.image} alt={p.title} className="w-full h-64 object-cover" />}
                        <div className="p-8">
                          <h3 style={{ fontFamily: headingFont, fontSize: fs('2xl') }} className="font-bold mb-3">{p.title || ''}</h3>
                          <p className="opacity-80 mb-6">{p.description || ''}</p>
                          <div className="flex gap-6">
                            {p.liveUrl && <a href={p.liveUrl} target="_blank" rel="noopener noreferrer" style={{ color: palette.primary }} className="font-bold hover:underline">Live</a>}
                            {p.githubUrl && <a href={p.githubUrl} target="_blank" rel="noopener noreferrer" className="opacity-70 hover:underline">GitHub</a>}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {l.projects === 'grid' && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
                  {sections.projects.data.map((p, i) => (
                    <div key={i} className="hover:-translate-y-4 transition-all" style={{ boxShadow: shadow('lg') }}>
                      <div className="overflow-hidden rounded-3xl" style={{ background: bg.paper || '#1a1a1a' }}>
                        {p.image && <img src={p.image} alt={p.title} className="w-full h-64 object-cover" />}
                        <div className="p-8">
                          <h3 style={{ fontFamily: headingFont, fontSize: fs('2xl') }} className="font-bold mb-4">{p.title || ''}</h3>
                          <p className="opacity-80 mb-6">{p.description || ''}</p>
                          <div className="flex gap-6">
                            {p.liveUrl && <a href={p.liveUrl} target="_blank" rel="noopener noreferrer" style={{ color: palette.primary }} className="font-bold hover:underline">Live Demo</a>}
                            {p.githubUrl && <a href={p.githubUrl} target="_blank" rel="noopener noreferrer" className="opacity-70 hover:underline">GitHub</a>}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {(l.projects === 'carousel' || l.projects === 'horizontal') && (
                <div className="overflow-x-auto pb-8 scrollbar-hide">
                  <div className="flex gap-12">
                    {sections.projects.data.map((p, i) => (
                      <div key={i} className="min-w-[90%] md:min-w-[60%] lg:min-w-[45%]">
                        <div className="rounded-3xl overflow-hidden" style={{ boxShadow: shadow('lg'), background: bg.paper || '#1a1a1a' }}>
                          {p.image && <img src={p.image} alt={p.title} className="w-full h-96 object-cover" />}
                          <div className="p-12">
                            <h3 style={{ fontFamily: headingFont, fontSize: fs('4xl') }} className="font-bold mb-6">{p.title || ''}</h3>
                            <p style={{ fontSize: fs('xl') }} className="opacity-80 mb-8">{p.description || ''}</p>
                            <div className="flex gap-8">
                              {p.liveUrl && <a href={p.liveUrl} target="_blank" rel="noopener noreferrer" style={{ color: palette.primary }} className="font-bold hover:underline text-xl">Live Demo</a>}
                              {p.githubUrl && <a href={p.githubUrl} target="_blank" rel="noopener noreferrer" className="opacity-70 hover:underline text-xl">GitHub</a>}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </section>
        )}

        {/* Experience */}
        {sections.experience?.enabled && sections.experience.data?.length > 0 && (
          <section id="experience" style={{ paddingTop: sectionPadding, paddingBottom: sectionPadding }} className="bg-black/30">
            <div className={containerClass}>
              <h2 style={{ fontFamily: headingFont, fontSize: fs('5xl') }} className="text-center mb-16 font-bold">
                Experience
              </h2>

              {l.experience === 'timeline' && (
                <div className="max-w-4xl mx-auto relative">
                  <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-1 bg-white/30"></div>
                  {sections.experience.data.map((exp, i) => (
                    <div key={i} className={`flex items-center mb-16 ${i % 2 === 0 ? 'flex-row' : 'flex-row-reverse'}`}>
                      <div className="w-5/12"></div>
                      <div className="w-2/12 flex justify-center">
                        <div className="w-6 h-6 rounded-full bg-white ring-8 ring-black/50" style={{ background: palette.primary }}></div>
                      </div>
                      <div className="w-5/12">
                        <div className="p-8 rounded-3xl" style={{ background: bg.paper || '#1a1a1a', boxShadow: shadow('md') }}>
                          <h3 style={{ fontFamily: headingFont, fontSize: fs('2xl') }} className="font-bold">{exp.position || exp.role || ''}</h3>
                          <p className="text-xl opacity-90 mb-2">{exp.company || ''}</p>
                          <p className="opacity-70 mb-4">{exp.duration || ''}</p>
                          <p>{exp.description || ''}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {l.experience === 'cards' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-5xl mx-auto">
                  {sections.experience.data.map((exp, i) => (
                    <div key={i} className="p-10 rounded-3xl" style={{ background: bg.paper || '#1a1a1a', boxShadow: shadow('lg') }}>
                      <h3 style={{ fontFamily: headingFont, fontSize: fs('2xl') }} className="font-bold mb-3">{exp.position || exp.role || ''}</h3>
                      <p className="text-xl opacity-90 mb-3">{exp.company || ''}</p>
                      <p className="opacity-70 mb-6">{exp.duration || ''}</p>
                      <p>{exp.description || ''}</p>
                    </div>
                  ))}
                </div>
              )}

              {l.experience === 'list' && (
                <div className="max-w-4xl mx-auto space-y-12">
                  {sections.experience.data.map((exp, i) => (
                    <div key={i} className="border-l-4 pl-8" style={{ borderColor: palette.primary }}>
                      <h3 style={{ fontFamily: headingFont, fontSize: fs('2xl') }} className="font-bold">{exp.position || exp.role || ''}</h3>
                      <p className="text-xl opacity-90">{exp.company || ''} • {exp.duration || ''}</p>
                      <p className="mt-4 opacity-80">{exp.description || ''}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </section>
        )}

        {/* Contact - uses passed props */}
        {sections.contact?.enabled && l.contact?.enabled !== false && (
          <section id="contact" style={{ paddingTop: sectionPadding, paddingBottom: sectionPadding }} className="bg-black/50">
            <div className={`${containerClass} text-center`}>
              <h2 style={{ fontFamily: headingFont, fontSize: fs('5xl') }} className="font-bold mb-12">
                {sections.contact.data?.heading || 'Get In Touch'}
              </h2>
              <form onSubmit={onContactSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-3xl mx-auto">
                <input
                  name="name"
                  placeholder="Your Name"
                  required
                  style={{ fontSize: fs('base'), borderRadius: br('lg') }}
                  className="px-6 py-4 bg-white/10 border border-white/20 focus:border-white/50 backdrop-blur"
                />
                <input
                  name="email"
                  type="email"
                  placeholder="Your Email"
                  required
                  style={{ fontSize: fs('base'), borderRadius: br('lg') }}
                  className="px-6 py-4 bg-white/10 border border-white/20 focus:border-white/50 backdrop-blur"
                />
                <textarea
                  name="message"
                  rows={6}
                  placeholder="Your Message"
                  required
                  style={{ fontSize: fs('base'), borderRadius: br('lg') }}
                  className="md:col-span-2 px-6 py-4 bg-white/10 border border-white/20 focus:border-white/50 backdrop-blur resize-none"
                />
                <button
                  type="submit"
                  style={{
                    background: palette.primary || '#ffd700',
                    color: text.onPrimary || '#000',
                    borderRadius: br('full'),
                    fontSize: fs('xl'),
                  }}
                  className="md:col-span-2 py-5 font-bold shadow-2xl hover:scale-105 transition"
                >
                  Send Message
                </button>
              </form>
              {messageStatus === 'success' && <p className="mt-8 text-green-400 text-2xl font-bold">Message sent!</p>}
              {messageStatus === 'error' && <p className="mt-8 text-red-400 text-2xl font-bold">Failed to send.</p>}
            </div>
          </section>
        )}
      </main>

      {l.footer?.enabled !== false && (
        <footer className="py-16 text-center" style={{ background: '#000000' }}>
          <div className={containerClass}>
            <p className="text-xl mb-4 opacity-90">
              {sections.hero?.data?.name || 'Portfolio'} © {new Date().getFullYear()}
            </p>
            <p className="opacity-60">
              Built with <a href="/" className="underline hover:opacity-100">Portfolio Builder</a>
            </p>
          </div>
        </footer>
      )}
    </div>
  );
}