import { Link, useLocation } from 'react-router-dom';
import {
  FiHome,
  FiGrid,
  FiEye,
  FiTool,
  FiSettings,
  FiLogOut,
  FiChevronLeft,
  FiChevronRight,
  FiUsers,
  FiLayout,
} from 'react-icons/fi';
import { useAuth } from '../../context/AuthContext';

export default function Sidebar({ collapsed, setCollapsed }) {
  const { logout, user } = useAuth();
  const location = useLocation();

  const isAdmin = ['superAdmin', 'systemAdmin'].includes(user?.role);

  const userMenu = [
    { icon: FiHome, label: 'Dashboard', path: '/dashboard' },
    { icon: FiGrid, label: 'Themes', path: '/themes' },
    { icon: FiEye, label: 'Preview', path: `/${user?.username}`, external: true },
    { icon: FiTool, label: 'Manage Portfolio', path: '/portfolio-manage' },
    { icon: FiSettings, label: 'Settings', path: '/settings' },
  ];

  const adminMenu = [
    { icon: FiHome, label: 'Admin Dashboard', path: '/admin' },
    { icon: FiUsers, label: 'User Management', path: '/admin/users' },
    { icon: FiLayout, label: 'Theme Management', path: '/admin/themes' },
  ];

  const menu = isAdmin ? adminMenu : userMenu;

  return (
    <aside className="h-full flex flex-col overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-5 border-b border-gray-200">
        <h1
          className={`font-bold text-xl whitespace-nowrap transition-all duration-300
            ${collapsed ? 'opacity-0 w-0 overflow-hidden' : 'opacity-100'}
          `}
        >
          {isAdmin ? 'Admin Panel' : 'Portfolio'}
        </h1>

        <button
          onClick={() => setCollapsed(!collapsed)}
          className="p-2 rounded-lg hover:bg-gray-100 hidden lg:flex"
        >
          {collapsed ? <FiChevronRight size={20} /> : <FiChevronLeft size={20} />}
        </button>
      </div>

      {/* Menu */}
      <nav className="flex-1 px-3 py-4 space-y-1">
        {menu.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;

          const base =
            'flex items-center gap-4 px-4 py-3 rounded-xl text-sm font-medium transition-all';
          const active = isActive
            ? 'bg-black text-white'
            : 'text-gray-700 hover:bg-gray-100';

          return item.external ? (
            <a
              key={item.label}
              href={item.path}
              target="_blank"
              rel="noopener noreferrer"
              className={`${base} ${active}`}
            >
              <Icon size={20} />
              <span
                className={`transition-all duration-300 whitespace-nowrap
                  ${collapsed ? 'opacity-0 w-0 overflow-hidden' : 'opacity-100'}
                `}
              >
                {item.label}
              </span>
              {!collapsed && <span className="ml-auto text-xs">↗</span>}
            </a>
          ) : (
            <Link
              key={item.label}
              to={item.path}
              className={`${base} ${active}`}
            >
              <Icon size={20} />
              <span
                className={`transition-all duration-300 whitespace-nowrap
                  ${collapsed ? 'opacity-0 w-0 overflow-hidden' : 'opacity-100'}
                `}
              >
                {item.label}
              </span>
            </Link>
          );
        })}
      </nav>

      {/* Logout */}
      <div className="p-4 border-t border-gray-200">
        <button
          onClick={logout}
          className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all
            bg-black text-white hover:bg-gray-900
            ${collapsed ? 'justify-center' : ''}
          `}
        >
          <FiLogOut size={20} />
          {!collapsed && <span>Logout</span>}
        </button>
      </div>
    </aside>
  );
}
