// src/pages/LandingPage.jsx
// Using Lucide React icons

import { Link } from 'react-router-dom';
import {
  LayoutGrid,
  Sparkles,
  Eye,
  Globe,
  Smartphone,
  Zap,
  Layers,
  Lock,
  UserPlus,
  Pencil,
  Palette,
  Share2,
} from 'lucide-react';

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50/40 via-white to-purple-50/20">
      {/* Navigation */}
      <header className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-md z-50 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-600 to-pink-600 rounded-lg flex items-center justify-center">
              <Sparkles className="text-white" size={24} />
            </div>
            <span className="text-2xl font-bold text-gray-900">Portfolia</span>
          </div>

          <nav className="hidden md:flex items-center gap-10">
            <a href="#features" className="text-gray-700 font-medium hover:text-purple-600 transition">
              Features
            </a>
            <a href="#how-it-works" className="text-gray-700 font-medium hover:text-purple-600 transition">
              How It Works
            </a>
            <a href="#themes" className="text-gray-700 font-medium hover:text-purple-600 transition">
              Themes
            </a>
            <a href="#pricing" className="text-gray-700 font-medium hover:text-purple-600 transition">
              Pricing
            </a>
          </nav>

          <div className="flex items-center gap-6">
            <a href="/login" className="text-gray-700 font-medium">
              Sign In
            </a>
            <Link
              to="/register"
              className="px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-semibold rounded-full hover:opacity-90 transition shadow-md"
            >
              Get Started Free
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="pt-32 pb-24 px-6 text-center">
        <div className="max-w-4xl mx-auto">
          <div className="inline-block px-4 py-2 bg-purple-100 text-purple-700 rounded-full text-sm font-medium mb-8">
            New: AI-powered content suggestions
          </div>
          <h1 className="text-5xl md:text-7xl font-black mb-6 leading-tight">
            Build Your{' '}
            <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              Professional Portfolio
            </span>{' '}
            in Minutes
          </h1>
          <p className="text-xl text-gray-600 mb-12 max-w-2xl mx-auto">
            Create stunning portfolio websites without any coding. Choose from beautiful themes, add your content, and publish
            instantly.
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
            <Link
              to="/register"
              className="px-10 py-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white text-lg font-bold rounded-full hover:opacity-90 transition shadow-lg"
            >
              Start Building Free →
            </Link>
            <button className="px-10 py-4 border border-gray-300 text-gray-800 text-lg font-bold rounded-full hover:bg-gray-50 transition flex items-center gap-2">
              ▶ Watch Demo
            </button>
          </div>
          <div className="flex justify-center gap-12 mt-16 text-gray-600 flex-wrap">
            <div className="flex items-center gap-2">
              <LayoutGrid className="text-purple-600" size={20} />
              No coding required
            </div>
            <div className="flex items-center gap-2">
              <Palette className="text-purple-600" size={20} />
              Beautiful themes
            </div>
            <div className="flex items-center gap-2">
              <Globe className="text-purple-600" size={20} />
              Free hosting included
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 px-6 bg-gradient-to-b from-white to-purple-50/30">
        <div className="max-w-6xl mx-auto text-center">
          <span className="text-purple-600 uppercase tracking-wider font-semibold">Features</span>
          <h2 className="text-4xl md:text-6xl font-black mt-4 mb-8 bg-gradient-to-r from-black to-purple-600 bg-clip-text text-transparent">
            Everything You Need to Stand Out
          </h2>
          <p className="text-xl text-gray-600 mb-16 max-w-3xl mx-auto">
            Powerful features that make creating and managing your portfolio effortless.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Drag & Drop Builder - Marked as Upcoming */}
            <div className="bg-white rounded-3xl p-8 shadow-lg relative overflow-hidden">
              <div className="absolute top-2 right-2 bg-orange-100 text-orange-700 text-xs font-bold px-3 py-1 rounded-full">
                Upcoming
              </div>
              <div className="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mb-6">
                <LayoutGrid className="text-purple-600" size={32} />
              </div>
              <h3 className="text-2xl font-bold mb-4">Drag & Drop Builder</h3>
              <p className="text-gray-600">
                Create your portfolio with an intuitive visual editor. No coding skills required.
              </p>
            </div>

            <div className="bg-white rounded-3xl p-8 shadow-lg">
              <div className="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mb-6">
                <Palette className="text-purple-600" size={32} />
              </div>
              <h3 className="text-2xl font-bold mb-4">Beautiful Themes</h3>
              <p className="text-gray-600">
                Choose from dozens of professionally designed themes and customize colors to match your brand.
              </p>
            </div>

            <div className="bg-white rounded-3xl p-8 shadow-lg">
              <div className="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mb-6">
                <Eye className="text-purple-600" size={32} />
              </div>
              <h3 className="text-2xl font-bold mb-4">Live Preview</h3>
              <p className="text-gray-600">
                See changes in real-time before publishing. Preview on desktop, tablet, and mobile.
              </p>
            </div>

            <div className="bg-white rounded-3xl p-8 shadow-lg">
              <div className="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mb-6">
                <Globe className="text-purple-600" size={32} />
              </div>
              <h3 className="text-2xl font-bold mb-4">Free Hosting</h3>
              <p className="text-gray-600">
                Your portfolio is hosted on our fast, secure servers with a custom subdomain included.
              </p>
            </div>
          </div>

          {/* Additional features row */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mt-8">
            <div className="bg-white rounded-3xl p-8 shadow-lg">
              <div className="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mb-6">
                <Smartphone className="text-purple-600" size={32} />
              </div>
              <h3 className="text-2xl font-bold mb-4">Mobile Responsive</h3>
              <p className="text-gray-600">
                Every portfolio looks perfect on all devices, from phones to large displays.
              </p>
            </div>

            <div className="bg-white rounded-3xl p-8 shadow-lg">
              <div className="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mb-6">
                <Zap className="text-purple-600" size={32} />
              </div>
              <h3 className="text-2xl font-bold mb-4">Instant Publishing</h3>
              <p className="text-gray-600">
                Go live in seconds. Update your portfolio anytime and changes appear instantly.
              </p>
            </div>

            <div className="bg-white rounded-3xl p-8 shadow-lg">
              <div className="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mb-6">
                <Layers className="text-purple-600" size={32} />
              </div>
              <h3 className="text-2xl font-bold mb-4">Section Management</h3>
              <p className="text-gray-600">
                Add, remove, and reorder sections. Show only what matters for your career.
              </p>
            </div>

            <div className="bg-white rounded-3xl p-8 shadow-lg">
              <div className="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mb-6">
                <Lock className="text-purple-600" size={32} />
              </div>
              <h3 className="text-2xl font-bold mb-4">Secure & Private</h3>
              <p className="text-gray-600">
                Your data is encrypted and secure. Control who sees your portfolio.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="py-24 px-6 bg-white">
        <div className="max-w-5xl mx-auto text-center">
          <span className="text-purple-600 uppercase tracking-wider font-semibold">How It Works</span>
          <h2 className="text-4xl md:text-6xl font-black mt-4 mb-12">
            From Zero to Portfolio in 4 Steps
          </h2>
          <p className="text-xl text-gray-600 mb-16 max-w-3xl mx-auto">
            Creating your professional portfolio has never been easier. Follow these simple steps.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
            <div className="flex flex-col items-center">
              <div className="w-20 h-20 bg-purple-100 rounded-full flex items-center justify-center mb-6 relative">
                <UserPlus className="text-purple-600" size={32} />
                <div className="absolute -top-2 -right-2 bg-purple-600 text-white text-xs font-bold w-8 h-8 rounded-full flex items-center justify-center border-4 border-white">
                  1
                </div>
              </div>
              <h3 className="text-xl font-bold mb-3">Create Account</h3>
              <p className="text-gray-600 text-sm">
                Sign up in seconds with just your email. No credit card required.
              </p>
            </div>

            <div className="flex flex-col items-center">
              <div className="w-20 h-20 bg-purple-100 rounded-full flex items-center justify-center mb-6 relative">
                <Pencil className="text-purple-600" size={32} />
                <div className="absolute -top-2 -right-2 bg-purple-600 text-white text-xs font-bold w-8 h-8 rounded-full flex items-center justify-center border-4 border-white">
                  2
                </div>
              </div>
              <h3 className="text-xl font-bold mb-3">Add Your Content</h3>
              <p className="text-gray-600 text-sm">
                Fill in your professional details, experience, projects, and skills.
              </p>
            </div>

            <div className="flex flex-col items-center">
              <div className="w-20 h-20 bg-purple-100 rounded-full flex items-center justify-center mb-6 relative">
                <Palette className="text-purple-600" size={32} />
                <div className="absolute -top-2 -right-2 bg-purple-600 text-white text-xs font-bold w-8 h-8 rounded-full flex items-center justify-center border-4 border-white">
                  3
                </div>
              </div>
              <h3 className="text-xl font-bold mb-3">Choose a Theme</h3>
              <p className="text-gray-600 text-sm">
                Browse our collection of beautiful themes and pick one that matches your style.
              </p>
            </div>

            <div className="flex flex-col items-center">
              <div className="w-20 h-20 bg-purple-100 rounded-full flex items-center justify-center mb-6 relative">
                <Share2 className="text-purple-600" size={32} />
                <div className="absolute -top-2 -right-2 bg-purple-600 text-white text-xs font-bold w-8 h-8 rounded-full flex items-center justify-center border-4 border-white">
                  4
                </div>
              </div>
              <h3 className="text-xl font-bold mb-3">Publish & Share</h3>
              <p className="text-gray-600 text-sm">
                Go live instantly and share your unique portfolio URL with the world.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-24 px-6 bg-gradient-to-r from-purple-600 to-pink-600 text-white text-center">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-black mb-8">
            Ready to Build Your Portfolio?
          </h2>
          <p className="text-xl mb-10 opacity-90">
            Start creating your professional portfolio today. No credit card required. Go live in minutes.
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <Link
              to="/register"
              className="px-10 py-5 bg-white text-purple-700 font-bold text-lg rounded-full hover:bg-gray-100 transition shadow-xl"
            >
              Start Building Free →
            </Link>
            <a
              href="/login"
              className="px-10 py-5 border-2 border-white text-white font-bold text-lg rounded-full hover:bg-white/10 transition"
            >
              Sign In
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-400 py-12 text-center">
        <div className="max-w-7xl mx-auto px-6">
          <p className="text-lg mb-4">
            © {new Date().getFullYear()} Portfolia. All rights reserved.
          </p>
          <p className="text-sm">Made with ❤️ for professionals everywhere</p>
        </div>
      </footer>
    </div>
  );
}