// // controllers/themeController.js
// import Theme from '../models/Theme.js';
// import Portfolio from '../models/Portfolio.js';

// export const getAllThemes = async (req, res) => {
//   try {
//     const themes = await Theme.find({
//       $or: [{ visibility: 'public' }, { type: 'prebuilt' }]
//     }).sort({ usedByCount: -1 });
//     res.json({ success: true, themes });
//   } catch (err) {
//     res.status(500).json({ message: err.message });
//   }
// };

// export const createCustomTheme = async (req, res) => {
//   try {
//     const { name, description, design, visibility = 'private' } = req.body;
//     const themeId = `custom-${Date.now()}`;

//     const theme = await Theme.create({
//       themeId,
//       name,
//       description,
//       design,
//       visibility,
//       type: 'custom',
//       createdBy: req.user.user_id,
//       createdByUsername: req.user.username
//     });

//     res.json({ success: true, theme });
//   } catch (err) {
//     res.status(500).json({ message: err.message });
//   }
// };

// export const activateTheme = async (req, res) => {
// const { themeId } = req.body;

//   const theme = await Theme.findOne({ themeId });
//   if (!theme) return res.status(404).json({ message: 'Theme not found' });

//   await Portfolio.findOneAndUpdate(
//     { user_id: req.user.user_id },
//     { 
//       'appearance.theme': theme._id  
//     },
//     { new: true }
//   );

//   await Theme.findByIdAndUpdate(theme._id, { $inc: { usedByCount: 1 } });

//   res.json({ message: 'Theme activated!' });
// };




//v2

// controllers/themeController.js
import Theme from '../models/Theme.js';
import Portfolio from '../models/Portfolio.js';

export const getAllThemes = async (req, res) => {
  try {
    const themes = await Theme.find({
      $or: [{ visibility: 'public' }, { type: 'prebuilt' }]
    }).sort({ usedByCount: -1 });

    res.json({ success: true, themes });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

export const createCustomTheme = async (req, res) => {
  try {
    const { name, description, design, layoutConfig, previewImage } = req.body;

    const theme = await Theme.create({
      name,
      description,
      design,
      layoutConfig,
      previewImage,
      type: 'custom',
      visibility: 'private',
      createdBy: req.user.user_id,
      createdByUsername: req.user.username
    });

    res.json({ success: true, theme });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

export const activateTheme = async (req, res) => {
  const { themeId } = req.body;

  const theme = await Theme.findOne({ themeId });
  if (!theme) return res.status(404).json({ message: 'Theme not found' });

  const updatedPortfolio = await Portfolio.findOneAndUpdate(
    { user_id: req.user.user_id },
    {
      'appearance.theme': theme._id,
      sectionsOrder: theme.layoutConfig?.defaultSectionsOrder || undefined
    },
    { new: true }
  ).populate({
    path: 'appearance.theme',
    select: 'design layoutConfig name previewImage'
  });

  await Theme.findByIdAndUpdate(theme._id, { $inc: { usedByCount: 1 } });

  res.json({
    success: true,
    message: 'Theme activated!',
    portfolio: updatedPortfolio
  });
};
