

// import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
// import { useAuth } from './context/AuthContext';
// import DashboardLayout from './components/layout/DashboardLayout';
// import PublicPortfolio from './pages/PublicPortfolio';
// import Login from './pages/Login';
// import Register from './pages/Register';
// import Dashboard from './pages/Dashboard';
// import ThemeGallery from './pages/ThemeGallery';
// import PortfolioManager from './pages/PortfolioManager';
// import UpdatePortfolioDetails from './pages/UpdatePortfolioDetails';
// import Settings from './pages/Settings';
// import Profile from './pages/Profile';
// import AdminPanel from './pages/AdminPanel';
// import LandingPage from './pages/LandingPage';
// import LoadingSpinner from './components/common/LoadingSpinner';
// import AdminDashboard from './pages/Admin/AdminDashboard';
// import AdminUserManagement from './pages/Admin/AdminUserManagement';
// import AdminThemeManagement from './pages/Admin/AdminThemeManagement';


// function ProtectedRoute({ children }) {
//   const { isAuthenticated, loading } = useAuth();
//   if (loading) return <LoadingSpinner />;
//   return isAuthenticated ? children : <Navigate to="/login" />;
// }

// function PublicOnlyRoute({ children }) {
//   const { isAuthenticated, loading } = useAuth();
//   if (loading) return <LoadingSpinner />;
//   return isAuthenticated ? <Navigate to="/dashboard" /> : children;
// }

// function HomeRoute() {
//   const { isAuthenticated, loading } = useAuth();
//   if (loading) return <LoadingSpinner />;
//   return isAuthenticated ? <Navigate to="/dashboard" /> : <LandingPage />;
// }

// export default function App() {
//   return (
//     <BrowserRouter>
//       <Routes>
//         {/* Root - Landing Page for non-logged in, redirect logged-in to dashboard */}
//         <Route path="/" element={<HomeRoute />} />

//         {/* Public Auth */}
//         <Route path="/login" element={<PublicOnlyRoute><Login /></PublicOnlyRoute>} />
//         <Route path="/register" element={<PublicOnlyRoute><Register /></PublicOnlyRoute>} />

//         {/* Protected Dashboard */}
//         <Route path="/" element={<ProtectedRoute><DashboardLayout /></ProtectedRoute>}>
//           <Route path="dashboard" element={<Dashboard />} />
//           <Route path="themes" element={<ThemeGallery />} />
//           <Route path="portfolio-manage" element={<PortfolioManager />} />
//           <Route path="update-portfolio" element={<UpdatePortfolioDetails />} />
//           <Route path="settings" element={<Settings />} />
//           <Route path="profile" element={<Profile />} />
//           <Route path="admin" element={<AdminDashboard />} />
// <Route path="admin/users" element={<AdminUserManagement />} />
// <Route path="admin/themes" element={<AdminThemeManagement />} />
//         </Route>

//         {/* Public Portfolio */}
//         <Route path="/:username" element={<PublicPortfolio />} />

//         {/* 404 */}
//         <Route path="*" element={
//           <div className="min-h-screen flex items-center justify-center bg-gray-50">
//             <h1 className="text-6xl font-bold text-gray-800">404 - Page Not Found</h1>
//           </div>
//         } />
//       </Routes>
//     </BrowserRouter>
//   );
// }



// src/App.jsx (FIXED – Admins now go to Admin Dashboard)

import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './context/AuthContext';
import DashboardLayout from './components/layout/DashboardLayout';
import PublicPortfolio from './pages/PublicPortfolio';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import ThemeGallery from './pages/ThemeGallery';
import PortfolioManager from './pages/PortfolioManager';
import UpdatePortfolioDetails from './pages/UpdatePortfolioDetails';
import Settings from './pages/Settings';
import Profile from './pages/Profile';

import LandingPage from './pages/LandingPage';
import LoadingSpinner from './components/common/LoadingSpinner';
import AdminDashboard from './pages/Admin/AdminDashboard';
import AdminUserManagement from './pages/Admin/AdminUserManagement';
import AdminThemeManagement from './pages/Admin/AdminThemeManagement';
import AddNewTheme from './components/onboarding/forms/AddNewTheme';
import PortfolioEditor from './pages/PortfolioEditor';
import PreviewLocal from './pages/PreviewLocal';

function ProtectedRoute({ children }) {
  const { isAuthenticated, loading, user } = useAuth();
  if (loading) return <LoadingSpinner />;

  if (!isAuthenticated) return <Navigate to="/login" />;

  // Admins go to their dashboard
  if (['superAdmin', 'systemAdmin'].includes(user?.role)) {
    if (location.pathname === '/' || location.pathname.startsWith('/dashboard')) {
      return <Navigate to="/admin" replace />;
    }
  }

  return children;
}

function PublicOnlyRoute({ children }) {
  const { isAuthenticated, loading } = useAuth();
  if (loading) return <LoadingSpinner />;
  return isAuthenticated ? <Navigate to="/dashboard" /> : children;
}

function HomeRoute() {
  const { isAuthenticated, loading, user } = useAuth();
  if (loading) return <LoadingSpinner />;

  if (isAuthenticated) {
    if (['superAdmin', 'systemAdmin'].includes(user?.role)) {
      return <Navigate to="/admin" replace />;
    }
    return <Navigate to="/dashboard" replace />;
  }

  return <LandingPage />;
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Root */}
        <Route path="/" element={<HomeRoute />} />

        {/* Auth */}
        <Route path="/login" element={<PublicOnlyRoute><Login /></PublicOnlyRoute>} />
        <Route path="/register" element={<PublicOnlyRoute><Register /></PublicOnlyRoute>} />

        {/* Protected Dashboard + Admin */}
        <Route path="/" element={<ProtectedRoute><DashboardLayout /></ProtectedRoute>}>
          {/* User Routes */}
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="themes" element={<ThemeGallery />} />
          <Route path="portfolio-manage" element={<PortfolioEditor />} />
          <Route path="update-portfolio" element={<UpdatePortfolioDetails />} />
          <Route path="settings" element={<Settings />} />
          <Route path="profile" element={<Profile />} />

          {/* Admin Routes */}
          <Route path="admin" element={<AdminDashboard />} />
          <Route path="admin/users" element={<AdminUserManagement />} />
          <Route path="admin/themes" element={<AdminThemeManagement />} />
          <Route path="admin/themes/add" element={<AddNewTheme />} />
        </Route>

        {/* Public Portfolio */}
        <Route path="/:username" element={<PublicPortfolio />} />
        <Route path="/preview-local" element={<PreviewLocal />} />

        {/* 404 */}
        <Route path="*" element={
          <div className="min-h-screen flex items-center justify-center bg-gray-50">
            <h1 className="text-6xl font-bold text-gray-800">404 - Not Found</h1>
          </div>
        } />
      </Routes>
    </BrowserRouter>
  );
}