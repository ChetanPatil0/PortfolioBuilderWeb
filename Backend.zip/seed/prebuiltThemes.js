// seed/prebuiltThemes.js
import mongoose from 'mongoose';
import { v4 as uuidv4 } from 'uuid';
import Theme from '../models/Theme.js';
import 'dotenv/config';

// Use a fake admin user ID (create one admin in DB or use this)
const ADMIN_USER_ID = '5499d313-2d4a-4adb-b162-7e27a64dc518';
const ADMIN_USERNAME = 'chetan';

const prebuiltThemes = [

  {
    name: 'Cyber Neon Pro',
    description: 'Futuristic dark theme with neon accents and glowing effects - perfect for tech professionals',
    previewImage: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1200&q=80',
    thumbnail: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&q=80',
    category: 'developer',
    tags: ['dark', 'neon', 'futuristic', 'tech', 'developer'],
    design: {
      palette: {
        mode: 'dark',
        colors: {
          primary: '#00ff41',
          secondary: '#ff00ff',
          accent: '#00d9ff',
          neutral: {
            50: '#f8fafc',
            100: '#f1f5f9',
            200: '#e2e8f0',
            300: '#cbd5e1',
            400: '#94a3b8',
            500: '#64748b',
            600: '#475569',
            700: '#334155',
            800: '#1e293b',
            900: '#0f172a'
          },
          text: {
            primary: '#ffffff',
            secondary: '#00ff41',
            muted: '#94a3b8',
            onPrimary: '#0f172a'
          },
          background: {
            default: '#0a0e27',
            paper: '#151b3d'
          }
        }
      },
      typography: {
        fontFamily: {
          heading: 'Orbitron, sans-serif',
          body: 'Inter, system-ui, sans-serif'
        },
        fontSizes: {
          xs: '0.75rem',
          sm: '0.875rem',
          base: '1rem',
          lg: '1.125rem',
          xl: '1.25rem',
          '2xl': '1.5rem',
          '3xl': '1.875rem',
          '4xl': '2.25rem',
          '5xl': '3rem',
          '6xl': '4rem',
          '7xl': '5rem',
          '8xl': '6rem'
        }
      },
      background: {
        type: 'solid',
        solid: '#0a0e27'
      },
      effects: {
        borderRadius: {
          sm: '0.5rem',
          md: '0.75rem',
          lg: '1rem',
          xl: '1.5rem',
          full: '9999px'
        },
        shadows: {
          md: '0 0 20px rgba(0, 255, 65, 0.3)',
          lg: '0 0 40px rgba(0, 255, 65, 0.5)'
        }
      },
      spacing: {
        sectionVertical: '8rem'
      }
    },
    layoutConfig: {
      hero: 'fullscreen',
      projects: 'carousel',
      skills: 'circles',
      experience: 'timeline',
      contact: { enabled: true },
      navbar: { enabled: true },
      footer: { enabled: true },
      defaultSectionsOrder: ['hero', 'about', 'skills', 'projects', 'experience', 'contact']
    }
  },

  {
    name: 'Luxury Gold Edition',
    description: 'Premium dark theme with elegant gold accents - ideal for high-end portfolios',
    previewImage: 'https://images.unsplash.com/photo-1618005198919-d3d4b5a92ead?w=1200&q=80',
    thumbnail: 'https://images.unsplash.com/photo-1618005198919-d3d4b5a92ead?w=600&q=80',
    category: 'designer',
    tags: ['luxury', 'premium', 'gold', 'elegant', 'dark'],
    design: {
      palette: {
        mode: 'dark',
        colors: {
          primary: '#ffd700',
          secondary: '#c9a227',
          accent: '#fff8dc',
          neutral: {
            50: '#fafaf9',
            100: '#f5f5f4',
            200: '#e7e5e4',
            300: '#d6d3d1',
            400: '#a8a29e',
            500: '#78716c',
            600: '#57534e',
            700: '#44403c',
            800: '#292524',
            900: '#1c1917'
          },
          text: {
            primary: '#ffffff',
            secondary: '#ffd700',
            muted: '#a8a29e',
            onPrimary: '#1c1917'
          },
          background: {
            default: '#0f0f0f',
            paper: '#1a1a1a'
          }
        }
      },
      typography: {
        fontFamily: {
          heading: 'Playfair Display, serif',
          body: 'Montserrat, sans-serif'
        },
        fontSizes: {
          xs: '0.75rem',
          sm: '0.875rem',
          base: '1rem',
          lg: '1.125rem',
          xl: '1.25rem',
          '2xl': '1.5rem',
          '3xl': '2rem',
          '4xl': '2.5rem',
          '5xl': '3.5rem',
          '6xl': '4.5rem',
          '7xl': '6rem',
          '8xl': '8rem'
        }
      },
      background: {
        type: 'gradient',
        gradient: {
          colors: ['#0f0f0f', '#1a1a1a', '#0f0f0f'],
          direction: 'to bottom'
        }
      },
      effects: {
        borderRadius: {
          sm: '0.25rem',
          md: '0.5rem',
          lg: '0.75rem',
          xl: '1rem',
          full: '9999px'
        },
        shadows: {
          md: '0 8px 16px rgba(255, 215, 0, 0.2)',
          lg: '0 16px 32px rgba(255, 215, 0, 0.3)'
        }
      },
      spacing: {
        sectionVertical: '7rem'
      }
    },
    layoutConfig: {
      hero: 'split',
      projects: 'masonry',
      skills: 'bars',
      experience: 'cards',
      contact: { enabled: true },
      navbar: { enabled: true },
      footer: { enabled: true },
      defaultSectionsOrder: ['hero', 'about', 'projects', 'skills', 'experience', 'testimonials', 'contact']
    }
  },

  {
    name: 'Ocean Wave',
    description: 'Fresh blue gradient theme with flowing animations - perfect for clean, modern portfolios',
    previewImage: 'https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=1200&q=80',
    thumbnail: 'https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=600&q=80',
    category: 'freelancer',
    tags: ['blue', 'gradient', 'modern', 'clean', 'light'],
    design: {
      palette: {
        mode: 'light',
        colors: {
          primary: '#0ea5e9',
          secondary: '#06b6d4',
          accent: '#22d3ee',
          neutral: {
            50: '#f8fafc',
            100: '#f1f5f9',
            200: '#e2e8f0',
            300: '#cbd5e1',
            400: '#94a3b8',
            500: '#64748b',
            600: '#475569',
            700: '#334155',
            800: '#1e293b',
            900: '#0f172a'
          },
          text: {
            primary: '#0f172a',
            secondary: '#475569',
            muted: '#94a3b8',
            onPrimary: '#ffffff'
          },
          background: {
            default: '#ffffff',
            paper: '#f8fafc'
          }
        }
      },
      typography: {
        fontFamily: {
          heading: 'Poppins, sans-serif',
          body: 'Inter, sans-serif'
        },
        fontSizes: {
          xs: '0.75rem',
          sm: '0.875rem',
          base: '1rem',
          lg: '1.125rem',
          xl: '1.25rem',
          '2xl': '1.5rem',
          '3xl': '1.875rem',
          '4xl': '2.25rem',
          '5xl': '3rem',
          '6xl': '3.75rem',
          '7xl': '4.5rem',
          '8xl': '6rem'
        }
      },
      background: {
        type: 'gradient',
        gradient: {
          colors: ['#ffffff', '#e0f2fe', '#bae6fd'],
          direction: 'to bottom right'
        }
      },
      effects: {
        borderRadius: {
          sm: '0.5rem',
          md: '0.75rem',
          lg: '1rem',
          xl: '1.5rem',
          full: '9999px'
        },
        shadows: {
          md: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
          lg: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)'
        }
      },
      spacing: {
        sectionVertical: '6rem'
      }
    },
    layoutConfig: {
      hero: 'centered',
      projects: 'grid',
      skills: 'circles',
      experience: 'timeline',
      contact: { enabled: true },
      navbar: { enabled: true },
      footer: { enabled: true },
      defaultSectionsOrder: ['hero', 'about', 'skills', 'projects', 'experience', 'education', 'contact']
    }
  },

  {
    name: 'Sunset Paradise',
    description: 'Warm sunset gradient with vibrant colors - energetic and eye-catching',
    previewImage: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=1200&q=80',
    thumbnail: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600&q=80',
    category: 'bold',
    tags: ['sunset', 'gradient', 'colorful', 'vibrant', 'creative'],
    design: {
      palette: {
        mode: 'dark',
        colors: {
          primary: '#f97316',
          secondary: '#ec4899',
          accent: '#fbbf24',
          neutral: {
            50: '#fef2f2',
            100: '#fee2e2',
            200: '#fecaca',
            300: '#fca5a5',
            400: '#f87171',
            500: '#ef4444',
            600: '#dc2626',
            700: '#b91c1c',
            800: '#991b1b',
            900: '#7f1d1d'
          },
          text: {
            primary: '#ffffff',
            secondary: '#fbbf24',
            muted: '#fca5a5',
            onPrimary: '#1e1b4b'
          },
          background: {
            default: '#1e1b4b',
            paper: '#312e81'
          }
        }
      },
      typography: {
        fontFamily: {
          heading: 'Bebas Neue, sans-serif',
          body: 'Roboto, sans-serif'
        },
        fontSizes: {
          xs: '0.75rem',
          sm: '0.875rem',
          base: '1rem',
          lg: '1.125rem',
          xl: '1.25rem',
          '2xl': '1.5rem',
          '3xl': '1.875rem',
          '4xl': '2.5rem',
          '5xl': '3.5rem',
          '6xl': '4.5rem',
          '7xl': '6rem',
          '8xl': '7rem'
        }
      },
      background: {
        type: 'gradient',
        gradient: {
          colors: ['#1e1b4b', '#7c2d12', '#991b1b'],
          direction: 'to bottom right'
        }
      },
      effects: {
        borderRadius: {
          sm: '0.375rem',
          md: '0.5rem',
          lg: '1rem',
          xl: '1.5rem',
          full: '9999px'
        },
        shadows: {
          md: '0 10px 20px rgba(249, 115, 22, 0.3)',
          lg: '0 20px 40px rgba(236, 72, 153, 0.4)'
        }
      },
      spacing: {
        sectionVertical: '7rem'
      }
    },
    layoutConfig: {
      hero: 'fullscreen',
      projects: 'horizontal',
      skills: 'grid',
      experience: 'cards',
      contact: { enabled: true },
      navbar: { enabled: true },
      footer: { enabled: true },
      defaultSectionsOrder: ['hero', 'projects', 'skills', 'experience', 'services', 'contact']
    }
  },

  {
    name: 'Forest Zen',
    description: 'Calming nature-inspired green theme with organic elements',
    previewImage: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=1200&q=80',
    thumbnail: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=600&q=80',
    category: 'minimal',
    tags: ['nature', 'green', 'minimal', 'organic', 'calm'],
    design: {
      palette: {
        mode: 'dark',
        colors: {
          primary: '#10b981',
          secondary: '#059669',
          accent: '#34d399',
          neutral: {
            50: '#f0fdf4',
            100: '#dcfce7',
            200: '#bbf7d0',
            300: '#86efac',
            400: '#4ade80',
            500: '#22c55e',
            600: '#16a34a',
            700: '#15803d',
            800: '#166534',
            900: '#14532d'
          },
          text: {
            primary: '#ffffff',
            secondary: '#86efac',
            muted: '#4ade80',
            onPrimary: '#14532d'
          },
          background: {
            default: '#064e3b',
            paper: '#065f46'
          }
        }
      },
      typography: {
        fontFamily: {
          heading: 'Quicksand, sans-serif',
          body: 'Lato, sans-serif'
        },
        fontSizes: {
          xs: '0.75rem',
          sm: '0.875rem',
          base: '1rem',
          lg: '1.125rem',
          xl: '1.25rem',
          '2xl': '1.5rem',
          '3xl': '1.875rem',
          '4xl': '2.25rem',
          '5xl': '3rem',
          '6xl': '4rem',
          '7xl': '5rem',
          '8xl': '6rem'
        }
      },
      background: {
        type: 'gradient',
        gradient: {
          colors: ['#064e3b', '#065f46', '#047857'],
          direction: 'to bottom'
        }
      },
      effects: {
        borderRadius: {
          sm: '0.5rem',
          md: '1rem',
          lg: '1.5rem',
          xl: '2rem',
          full: '9999px'
        },
        shadows: {
          md: '0 4px 12px rgba(16, 185, 129, 0.2)',
          lg: '0 12px 24px rgba(16, 185, 129, 0.3)'
        }
      },
      spacing: {
        sectionVertical: '6rem'
      }
    },
    layoutConfig: {
      hero: 'centered',
      projects: 'masonry',
      skills: 'bars',
      experience: 'list',
      contact: { enabled: true },
      navbar: { enabled: true },
      footer: { enabled: true },
      defaultSectionsOrder: ['hero', 'about', 'skills', 'projects', 'experience', 'contact']
    }
  },

  {
    name: 'Royal Purple Glass',
    description: 'Sophisticated purple theme with glassmorphism effects',
    previewImage: 'https://images.unsplash.com/photo-1557672172-298e090bd0f1?w=1200&q=80',
    thumbnail: 'https://images.unsplash.com/photo-1557672172-298e090bd0f1?w=600&q=80',
    category: 'agency',
    tags: ['purple', 'glass', 'modern', 'sophisticated', 'premium'],
    design: {
      palette: {
        mode: 'dark',
        colors: {
          primary: '#8b5cf6',
          secondary: '#a78bfa',
          accent: '#c4b5fd',
          neutral: {
            50: '#faf5ff',
            100: '#f3e8ff',
            200: '#e9d5ff',
            300: '#d8b4fe',
            400: '#c084fc',
            500: '#a855f7',
            600: '#9333ea',
            700: '#7e22ce',
            800: '#6b21a8',
            900: '#581c87'
          },
          text: {
            primary: '#ffffff',
            secondary: '#e9d5ff',
            muted: '#c084fc',
            onPrimary: '#1e1b4b'
          },
          background: {
            default: '#1e1b4b',
            paper: '#312e81'
          }
        }
      },
      typography: {
        fontFamily: {
          heading: 'Space Grotesk, sans-serif',
          body: 'DM Sans, sans-serif'
        },
        fontSizes: {
          xs: '0.75rem',
          sm: '0.875rem',
          base: '1rem',
          lg: '1.125rem',
          xl: '1.25rem',
          '2xl': '1.5rem',
          '3xl': '1.875rem',
          '4xl': '2.25rem',
          '5xl': '3rem',
          '6xl': '4rem',
          '7xl': '5rem',
          '8xl': '6.5rem'
        }
      },
      background: {
        type: 'gradient',
        gradient: {
          colors: ['#1e1b4b', '#4c1d95', '#1e1b4b'],
          direction: 'to bottom right'
        }
      },
      effects: {
        borderRadius: {
          sm: '0.5rem',
          md: '0.75rem',
          lg: '1.25rem',
          xl: '2rem',
          full: '9999px'
        },
        shadows: {
          md: '0 8px 32px rgba(139, 92, 246, 0.25)',
          lg: '0 16px 48px rgba(139, 92, 246, 0.35)'
        }
      },
      spacing: {
        sectionVertical: '8rem'
      }
    },
    layoutConfig: {
      hero: 'fullscreen',
      projects: 'carousel',
      skills: 'circles',
      experience: 'timeline',
      contact: { enabled: true },
      navbar: { enabled: true },
      footer: { enabled: true },
      defaultSectionsOrder: ['hero', 'about', 'projects', 'skills', 'experience', 'testimonials', 'contact']
    }
  },

  {
    name: 'Monochrome Elegance',
    description: 'Timeless black and white theme with perfect contrast',
    previewImage: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=1200&q=80',
    thumbnail: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=600&q=80',
    category: 'minimal',
    tags: ['minimal', 'black', 'white', 'elegant', 'simple'],
    design: {
      palette: {
        mode: 'light',
        colors: {
          primary: '#000000',
          secondary: '#262626',
          accent: '#525252',
          neutral: {
            50: '#fafafa',
            100: '#f5f5f5',
            200: '#e5e5e5',
            300: '#d4d4d4',
            400: '#a3a3a3',
            500: '#737373',
            600: '#525252',
            700: '#404040',
            800: '#262626',
            900: '#171717'
          },
          text: {
            primary: '#000000',
            secondary: '#404040',
            muted: '#737373',
            onPrimary: '#ffffff'
          },
          background: {
            default: '#ffffff',
            paper: '#fafafa'
          }
        }
      },
      typography: {
        fontFamily: {
          heading: 'Archivo, sans-serif',
          body: 'IBM Plex Sans, sans-serif'
        },
        fontSizes: {
          xs: '0.75rem',
          sm: '0.875rem',
          base: '1rem',
          lg: '1.125rem',
          xl: '1.25rem',
          '2xl': '1.5rem',
          '3xl': '1.875rem',
          '4xl': '2.25rem',
          '5xl': '3rem',
          '6xl': '3.75rem',
          '7xl': '4.5rem',
          '8xl': '6rem'
        }
      },
      background: {
        type: 'solid',
        solid: '#ffffff'
      },
      effects: {
        borderRadius: {
          sm: '0.125rem',
          md: '0.25rem',
          lg: '0.5rem',
          xl: '0.75rem',
          full: '0rem'
        },
        shadows: {
          md: '0 2px 8px rgba(0, 0, 0, 0.08)',
          lg: '0 4px 16px rgba(0, 0, 0, 0.12)'
        }
      },
      spacing: {
        sectionVertical: '5rem'
      }
    },
    layoutConfig: {
      hero: 'minimal',
      projects: 'grid',
      skills: 'bars',
      experience: 'list',
      contact: { enabled: true },
      navbar: { enabled: true },
      footer: { enabled: true },
      defaultSectionsOrder: ['hero', 'about', 'projects', 'skills', 'experience', 'education', 'contact']
    }
  },

  {
    name: 'Crimson Fire',
    description: 'Bold red and black theme with high energy and impact',
    previewImage: 'https://images.unsplash.com/photo-1534796636912-3b95b3ab5986?w=1200&q=80',
    thumbnail: 'https://images.unsplash.com/photo-1534796636912-3b95b3ab5986?w=600&q=80',
    category: 'bold',
    tags: ['red', 'bold', 'dark', 'energy', 'powerful'],
    design: {
      palette: {
        mode: 'dark',
        colors: {
          primary: '#dc2626',
          secondary: '#ef4444',
          accent: '#f87171',
          neutral: {
            50: '#fef2f2',
            100: '#fee2e2',
            200: '#fecaca',
            300: '#fca5a5',
            400: '#f87171',
            500: '#ef4444',
            600: '#dc2626',
            700: '#b91c1c',
            800: '#991b1b',
            900: '#7f1d1d'
          },
          text: {
            primary: '#ffffff',
            secondary: '#fca5a5',
            muted: '#f87171',
            onPrimary: '#7f1d1d'
          },
          background: {
            default: '#0c0a09',
            paper: '#1c1917'
          }
        }
      },
      typography: {
        fontFamily: {
          heading: 'Oswald, sans-serif',
          body: 'Raleway, sans-serif'
        },
        fontSizes: {
          xs: '0.75rem',
          sm: '0.875rem',
          base: '1rem',
          lg: '1.125rem',
          xl: '1.25rem',
          '2xl': '1.5rem',
          '3xl': '2rem',
          '4xl': '2.75rem',
          '5xl': '3.5rem',
          '6xl': '4.5rem',
          '7xl': '6rem',
          '8xl': '7.5rem'
        }
      },
      background: {
        type: 'gradient',
        gradient: {
          colors: ['#0c0a09', '#7f1d1d', '#0c0a09'],
          direction: 'to bottom'
        }
      },
      effects: {
        borderRadius: {
          sm: '0.25rem',
          md: '0.5rem',
          lg: '0.75rem',
          xl: '1rem',
          full: '9999px'
        },
        shadows: {
          md: '0 10px 20px rgba(220, 38, 38, 0.4)',
          lg: '0 20px 40px rgba(220, 38, 38, 0.5)'
        }
      },
      spacing: {
        sectionVertical: '7rem'
      }
    },
    layoutConfig: {
      hero: 'fullscreen',
      projects: 'masonry',
      skills: 'grid',
      experience: 'cards',
      contact: { enabled: true },
      navbar: { enabled: true },
      footer: { enabled: true },
      defaultSectionsOrder: ['hero', 'projects', 'about', 'skills', 'experience', 'services', 'contact']
    }
  },

   
];

async function seedPrebuiltThemes() {
  try {
    await mongoose.connect(process.env.MONGO_URI, {
         dbName: process.env.DB_NAME,  
        });

    // Option 1: Delete old prebuilt themes
    await Theme.deleteMany({ type: 'prebuilt' });

    // Option 2: Or use upsert to avoid duplicates (recommended)
    // for (const theme of prebuiltThemes) {
    //   await Theme.findOneAndUpdate({ themeId: theme.themeId }, theme, { upsert: true, setDefaultsOnInsert: true });
    // }

    const response = await Theme.insertMany(prebuiltThemes);

    console.log('PREBUILT THEMES SEEDED SUCCESSFULLY!',response);
    process.exit(0);
  } catch (err) {
    console.error('SEED FAILED:', err.message);
    process.exit(1);
  }
}

seedPrebuiltThemes();