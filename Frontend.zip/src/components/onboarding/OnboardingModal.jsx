// src/components/onboarding/OnboardingModal.jsx
import { useState, useEffect } from 'react';
import HeroForm from './forms/HeroForm';
import AboutForm from './forms/AboutForm';
import ExperienceForm from './forms/ExperienceForm';
import EducationForm from './forms/EducationForm';
import ProjectsForm from './forms/ProjectsForm';
import SkillsForm from './forms/SkillsForm';
import ServicesForm from './forms/ServicesForm';
import TestimonialsForm from './forms/TestimonialsForm';
import ContactForm from './forms/ContactForm';

const STEPS = [
  { id: 'hero', title: 'Tell us about yourself', component: HeroForm },
  { id: 'about', title: 'About You', component: AboutForm },
  { id: 'experience', title: 'Work Experience', component: ExperienceForm },
  { id: 'education', title: 'Education', component: EducationForm },
  { id: 'projects', title: 'Projects', component: ProjectsForm },
  { id: 'skills', title: 'Skills', component: SkillsForm },
  { id: 'services', title: 'Services', component: ServicesForm },
  { id: 'testimonials', title: 'Testimonials', component: TestimonialsForm },
  { id: 'contact', title: 'Contact Info', component: ContactForm },
];

export default function OnboardingModal({ onComplete }) {
  const [step, setStep] = useState(0);
  const [formData, setFormData] = useState({});

  // 🔒 Prevent background page scrolling
  useEffect(() => {
    document.body.style.overflow = "hidden";

    return () => {
      document.body.style.overflow = "auto";
    };
  }, []);

  const CurrentForm = STEPS[step].component;

  const handleNext = (data) => {
    setFormData((prev) => ({ ...prev, ...data }));

    if (step === STEPS.length - 1) {
      onComplete(formData);
    } else {
      setStep(step + 1);
    }
  };

  const handleBack = () => setStep(Math.max(0, step - 1));

  return (
    <div className="fixed inset-0 bg-[rgba(0,0,0,0.25)] flex items-center justify-center z-50 p-3">
      <div className="bg-white rounded-2xl shadow-xl max-w-3xl w-full h-[90vh] flex flex-col">

        {/* FIXED HEADER */}
        <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-4 rounded-t-2xl flex-shrink-0">
          <h2 className="text-2xl font-extrabold">Build Your Portfolio</h2>
          <p className="text-lg  opacity-90">
            Step {step + 1} of {STEPS.length}: {STEPS[step].title}
          </p>
        </div>

        {/* FIXED PROGRESS BAR */}
        <div className="p-2  flex-shrink-0">
          <div className="flex gap-2">
            {STEPS.map((_, i) => (
              <div
                key={i}
                className={`h-3 flex-1 rounded-full transition-all ${
                  i <= step ? "bg-black" : "bg-gray-300"
                }`}
              />
            ))}
          </div>
        </div>

        {/* ONLY CONTENT SCROLLS */}
        <div className="p-4 overflow-y-auto flex-1">
          <CurrentForm
            data={formData}
            onNext={handleNext}
            onBack={handleBack}
            isLast={step === STEPS.length - 1}
          />
        </div>

      </div>
    </div>
  );
}
