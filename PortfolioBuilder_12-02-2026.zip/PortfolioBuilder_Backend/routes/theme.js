// routes/theme.js
import { Router } from 'express';
import { protect } from '../middleware/auth.js';
import { getAllThemes, createCustomTheme, activateTheme } from '../controllers/themeController.js';
import Theme from '../models/Theme.js';

const router = Router();

router.get('/gallery', getAllThemes);
router.post('/create', protect, createCustomTheme);
router.post('/activate', protect, activateTheme);



export default router;

