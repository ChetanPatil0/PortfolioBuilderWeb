// src/components/ui/SectionToggle.jsx
import ToggleSwitch from './ToggleSwitch';

export default function SectionToggle({ section, enabled, onToggle }) {
  return (
    <div className="flex items-center justify-between py-6 border-b border-gray-200">
      <div>
        <h4 className="text-2xl font-medium capitalize">{section}</h4>
        <p className="text-gray-600">Show {section} section on your portfolio</p>
      </div>
      <ToggleSwitch checked={enabled} onChange={() => onToggle(section)} label="" />
    </div>
  );
}