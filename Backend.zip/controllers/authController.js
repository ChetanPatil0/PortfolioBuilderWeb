 
// import bcrypt from 'bcryptjs';
// import jwt from 'jsonwebtoken';
// import User from '../models/User.js';
// import Portfolio from '../models/Portfolio.js';

// const signToken = (id) => jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRE });

// const getTheme = (profession) => {
//   const map = {
//     developer: 'developer-dark', designer: 'creative-agency', freelancer: 'freelancer-gradient',
//     photographer: 'photography-dark', writer: 'writer-minimal', marketer: 'corporate-blue',
//     student: 'minimal-white', teacher: 'clean-professional', other: 'clean-professional'
//   };
//   return map[profession] || 'clean-professional';
// };

// export const register = async (req, res) => {
//   const { name, email, password, username, profession } = req.body;
//   try {
//     const user = await User.create({
//       name, email,
//       password: await bcrypt.hash(password, 12),
//       username: username.toLowerCase(),
//       profession: profession || 'other'
//     });

//     await Portfolio.create({
//       user_id: user.user_id,
//       username: user.username,
//       profession: user.profession,
//       appearance: { theme: getTheme(user.profession) }
//     });

//     const token = signToken(user._id);
//     res.status(201).json({
//       success: true,
//       token,
//       user: { user_id: user.user_id, name: user.name, username: user.username, role: user.role, profession: user.profession }
//     });
//   } catch (err) {
//     res.status(400).json({ success: false, message: err.message });
//   }
// };

// export const login = async (req, res) => {
//   const { identifier, password } = req.body;
//   console.log('req body', req.body);
//   if (!identifier || !password) return res.status(400).json({ message: 'Required fields missing' });

//   const user = await User.findOne({
//     $or: [{ email: identifier }, { username: identifier }]
//   });

//   if (!user || !(await bcrypt.compare(password, user.password))) {
//     return res.status(401).json({ message: 'Invalid credentials' });
//   }

//   const token = signToken(user._id);
//   res.json({ success: true, token, user: { user_id: user.user_id, name: user.name, username: user.username } });
// };

// export const googleSuccess = (req, res) => {
//   if (!req.user) return res.status(401).json({ message: 'Login failed' });
//   const token = signToken(req.user._id);
//   res.json({ success: true, token, user: { user_id: req.user.user_id, name: req.user.name, username: req.user.username, email: req.user.email } });
// };

// export const logout = (req, res) => {
//   req.logout(() => {});
//   res.json({ message: 'Logged out' });
// };

// export const getMe = async (req, res) => {
//   res.json({ success: true, user: req.user });
// };


// controllers/authController.js (UPDATED – Fixed registration: no theme assignment)

import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import User from '../models/User.js';
import Portfolio from '../models/Portfolio.js';

const signToken = (id) => jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRE });

export const register = async (req, res) => {
  const { name, email, password, username, profession } = req.body;

  try {
    const user = await User.create({
      name,
      email,
      password: await bcrypt.hash(password, 12),
      username: username.toLowerCase(),
      profession: profession || 'other'
    });

    // Create empty portfolio – NO theme assigned
    await Portfolio.create({
      user_id: user.user_id,
      username: user.username,
      profession: user.profession,
      appearance: { theme: null }, // ← theme is null (user will choose later)
      sections: {
        hero: { enabled: true, data: {} },
        about: { enabled: true, data: {} },
        contact: { enabled: true, data: { email: user.email } }
      },
      settings: { isPublic: true },
      analytics: { views: 0 }
    });

    const token = signToken(user._id);

    res.status(201).json({
      success: true,
      token,
      user: {
        user_id: user.user_id,
        name: user.name,
        username: user.username,
        role: user.role,
        profession: user.profession
      }
    });
  } catch (err) {
    console.error('Register error:', err);
    res.status(400).json({ success: false, message: err.message });
  }
};

export const login = async (req, res) => {
  const { identifier, password } = req.body;

  if (!identifier || !password) {
    return res.status(400).json({ message: 'Required fields missing' });
  }

  try {
    const user = await User.findOne({
      $or: [{ email: identifier }, { username: identifier }]
    });

    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    const token = signToken(user._id);

    res.json({
      success: true,
      token,
      user: {
        user_id: user.user_id,
        name: user.name,
        username: user.username,
        role: user.role,
        profession: user.profession
      }
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ message: 'Server error' });
  }
};

export const googleSuccess = (req, res) => {
  if (!req.user) return res.status(401).json({ message: 'Login failed' });

  const token = signToken(req.user._id);
  res.json({
    success: true,
    token,
    user: {
      user_id: req.user.user_id,
      name: req.user.name,
      username: req.user.username,
      email: req.user.email
    }
  });
};

export const logout = (req, res) => {
  req.logout(() => {});
  res.json({ message: 'Logged out successfully' });
};

export const getMe = async (req, res) => {
  res.json({ success: true, user: req.user });
};