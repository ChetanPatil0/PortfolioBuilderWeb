import React, { useState } from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { useAuth } from '../context/AuthContext';
import { useMessageModal } from '../context/MessageModalContext';
import Logo from '../components/common/Logo';
import { Link } from 'react-router-dom';

import {
  FiUser,
  FiMail,
  FiLock,
  FiEye,
  FiEyeOff,
  FiCheckCircle,
} from 'react-icons/fi';
import { FcGoogle } from 'react-icons/fc';
import { FaGithub } from 'react-icons/fa';

const validationSchema = Yup.object({
  firstName: Yup.string().required('First Name is required'),
  middleName: Yup.string(),
  lastName: Yup.string().required('Last Name is required'),
  email: Yup.string().email('Invalid email').required('Email is required'),
  username: Yup.string().required('Username is required'),
  password: Yup.string()
    .min(6, 'Password must be at least 6 characters')
    .required('Password is required'),
  confirmPassword: Yup.string()
    .oneOf([Yup.ref('password')], 'Passwords must match')
    .required('Confirm password is required'),
});

export default function Register() {
  const { register, googleLogin } = useAuth();
  const { showMessage } = useMessageModal();

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const handleSubmit = async (values, { setSubmitting, resetForm }) => {
    try {
      await register({
        name: `${values.firstName} ${values.middleName || ''} ${values.lastName}`.trim(),
        email: values.email,
        username: values.username,
        password: values.password,
      });

      showMessage({
        type: 'success',
        title: 'Account Created!',
        message: 'Welcome to Portfolia! Start building your portfolio now.',
        primaryButtonText: 'Go to Dashboard',
        autoCloseMs: 2800,
      });

      resetForm();
    } catch (err) {
      showMessage({
        type: 'error',
        title: 'Registration Failed',
        message: err.message || 'Please try again.',
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleGoogle = async () => {
    try {
      await googleLogin();
    } catch (err) {
      showMessage({
        type: 'error',
        title: 'Google Signup Failed',
        message: 'Unable to sign up with Google.',
      });
    }
  };

  return (
    <div className="min-h-screen flex flex-col lg:flex-row">
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-purple-700 via-purple-600 to-pink-600 items-center justify-center px-8 xl:px-12 text-white relative overflow-hidden h-screen sticky top-0">
        <div className="absolute inset-0 bg-black/10"></div>

        <div className="relative z-10  max-w-lg text-center space-y-10">
          <h2 className="text-4xl xl:text-5xl font-extrabold tracking-tight leading-tight drop-shadow-md">
            Start Building Today
          </h2>

          <p className="text-lg xl:text-xl opacity-90 font-light max-w-sm mx-auto">
            Create your professional portfolio in minutes.<br />
            <span className="font-medium">No coding required.</span>
          </p>

          <ul className="text-left space-y-6 text-base xl:text-lg mt-12">
            <li className="flex items-center gap-4">
              <FiCheckCircle className="text-green-300 flex-shrink-0" size={24} />
              <span>Unlimited portfolio updates</span>
            </li>
            <li className="flex items-center gap-4">
              <FiCheckCircle className="text-green-300 flex-shrink-0" size={24} />
              <span>Beautiful premium themes</span>
            </li>
            <li className="flex items-center gap-4">
              <FiCheckCircle className="text-green-300 flex-shrink-0" size={24} />
              <span>Free hosting included</span>
            </li>
            <li className="flex items-center gap-4">
              <FiCheckCircle className="text-green-300 flex-shrink-0" size={24} />
              <span>No credit card required</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="flex-1 lg:w-1/2 flex items-start justify-center bg-white overflow-y-auto lg:h-screen">
        <div className="w-full max-w-2xl px-5 sm:px-8 lg:px-12 py-8 lg:py-10 space-y-6">
          <div className="flex justify-center lg:justify-start mb-6">
            <Logo size="xl" className="text-4xl lg:text-5xl" />
          </div>

          <div className="text-center lg:text-left">
            <h1 className="text-3xl lg:text-4xl font-bold text-gray-900">
              Create your account
            </h1>
            <p className="mt-2 text-gray-600 text-base lg:text-lg">
              Get started with your free portfolio today
            </p>
          </div>

          <Formik
            initialValues={{
              firstName: '',
              middleName: '',
              lastName: '',
              email: '',
              username: '',
              password: '',
              confirmPassword: '',
            }}
            validationSchema={validationSchema}
            onSubmit={handleSubmit}
          >
            {({ isSubmitting }) => (
              <Form className="space-y-5">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1.5">
                      First Name <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <FiUser className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                      <Field
                        name="firstName"
                        type="text"
                        placeholder="John"
                        className="w-full pl-11 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none transition placeholder-gray-400"
                      />
                    </div>
                    <ErrorMessage name="firstName" component="p" className="mt-1 text-sm text-red-600" />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1.5">
                      Middle Name
                    </label>
                    <Field
                      name="middleName"
                      type="text"
                      placeholder="Optional"
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none transition placeholder-gray-400"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1.5">
                      Last Name <span className="text-red-500">*</span>
                    </label>
                    <Field
                      name="lastName"
                      type="text"
                      placeholder="Doe"
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none transition placeholder-gray-400"
                    />
                    <ErrorMessage name="lastName" component="p" className="mt-1 text-sm text-red-600" />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1.5">
                      Email <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <FiMail className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                      <Field
                        name="email"
                        type="email"
                        placeholder="you@example.com"
                        className="w-full pl-11 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none transition placeholder-gray-400"
                      />
                    </div>
                    <ErrorMessage name="email" component="p" className="mt-1 text-sm text-red-600" />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1.5">
                      Username <span className="text-red-500">*</span>
                    </label>
                    <Field
                      name="username"
                      type="text"
                      placeholder="johndoe"
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none transition placeholder-gray-400"
                    />
                    <ErrorMessage name="username" component="p" className="mt-1 text-sm text-red-600" />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1.5">
                      Password <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <FiLock className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                      <Field
                        name="password"
                        type={showPassword ? 'text' : 'password'}
                        placeholder="Minimum 6 characters"
                        className="w-full pl-11 pr-11 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none transition placeholder-gray-400"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                      >
                        {showPassword ? <FiEyeOff size={20} /> : <FiEye size={20} />}
                      </button>
                    </div>
                    <ErrorMessage name="password" component="p" className="mt-1 text-sm text-red-600" />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1.5">
                      Confirm Password <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <FiLock className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                      <Field
                        name="confirmPassword"
                        type={showConfirmPassword ? 'text' : 'password'}
                        placeholder="Re-type your password"
                        className="w-full pl-11 pr-11 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none transition placeholder-gray-400"
                      />
                      <button
                        type="button"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                        className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                      >
                        {showConfirmPassword ? <FiEyeOff size={20} /> : <FiEye size={20} />}
                      </button>
                    </div>
                    <ErrorMessage name="confirmPassword" component="p" className="mt-1 text-sm text-red-600" />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3.5 mt-2 bg-gradient-to-r from-purple-600 via-purple-500 to-pink-500 text-white font-semibold rounded-xl shadow-lg hover:brightness-105 focus:outline-none focus:ring-2 focus:ring-purple-400 transition disabled:opacity-60 flex items-center justify-center gap-2"
                >
                  {isSubmitting ? (
                    <>
                      <svg className="animate-spin h-5 w-5 text-white" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8h8a8 8 0 01-16 0z" />
                      </svg>
                      Creating...
                    </>
                  ) : (
                    'Create Account →'
                  )}
                </button>
              </Form>
            )}
          </Formik>

          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-200" />
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="bg-white px-5 text-gray-500">OR CONTINUE WITH</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <button
              onClick={handleGoogle}
              className="py-3.5 border border-gray-200 rounded-xl hover:bg-gray-50 transition flex items-center justify-center gap-2.5 text-gray-700"
            >
              <FcGoogle size={22} />
              <span>Google</span>
            </button>

            <button
              className="py-3.5 border border-gray-200 rounded-xl hover:bg-gray-50 transition flex items-center justify-center gap-2.5 text-gray-700"
            >
              <FaGithub size={22} />
              <span>GitHub</span>
            </button>
          </div>

          <div className="text-center text-sm text-gray-600 mt-6 space-y-2">
            <p>
              By creating an account, you agree to our{' '}
              <Link to="/terms" className="text-purple-600 hover:underline">Terms of Service</Link>{' '}
              and{' '}
              <Link to="/privacy" className="text-purple-600 hover:underline">Privacy Policy</Link>
            </p>
            <p>
              Already have an account?{' '}
              <Link to="/login" className="text-purple-600 font-medium hover:underline">
                Sign in
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}