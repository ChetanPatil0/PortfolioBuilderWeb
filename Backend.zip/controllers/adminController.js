
import User from '../models/User.js';
import Portfolio from '../models/Portfolio.js';
import Theme from '../models/Theme.js';

export const getAllUsers = async (req, res) => {
  try {
    const users = await User.find().select('-password');
    const enrichedUsers = await Promise.all(
      users.map(async (user) => {
        const portfolio = await Portfolio.findOne({ username: user.username })
          .select('analytics settings.isPublic')
          .lean();
        return {
          ...user.toObject(),
          analytics: portfolio?.analytics || { views: 0 },
          isPublic: portfolio?.settings?.isPublic ?? true
        };
      })
    );
    res.json({ success: true, users: enrichedUsers });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

export const getUserPortfolioAnalytics = async (req, res) => {
  try {
    const portfolio = await Portfolio.findOne({ username: req.params.username })
      .select('analytics')
      .lean();
    res.json({ success: true, analytics: portfolio?.analytics || { views: 0 } });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

export const createPrebuiltTheme = async (req, res) => {
  try {
    const { name, description, previewImage, design, layoutConfig } = req.body;

    const theme = await Theme.create({
      name,
      description,
      previewImage,
      design,
      layoutConfig,
      type: 'prebuilt',
      visibility: 'public',
      featured: false
    });

    res.status(201).json({ success: true, theme });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

export const getPrebuiltThemes = async (req, res) => {
  try {
    const themes = await Theme.find({ type: 'prebuilt' }).sort({ createdAt: -1 });
    res.json({ success: true, themes });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

export const updatePrebuiltTheme = async (req, res) => {
  try {
    const theme = await Theme.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!theme) return res.status(404).json({ message: 'Theme not found' });
    res.json({ success: true, theme });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

export const deletePrebuiltTheme = async (req, res) => {
  try {
    const theme = await Theme.findByIdAndDelete(req.params.id);
    if (!theme) return res.status(404).json({ message: 'Theme not found' });
    res.json({ success: true, message: 'Theme deleted successfully' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};