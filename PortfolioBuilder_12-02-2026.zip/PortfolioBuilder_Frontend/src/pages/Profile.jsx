
import { useAuth } from '../context/AuthContext';
import { useState } from 'react';

export default function Profile() {
  const { user } = useAuth();
  const [name, setName] = useState(user?.name || '');
  const [profession, setProfession] = useState(user?.profession || 'other');
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    try {
      alert('Profile updated successfully!');
    } catch (err) {
      alert('Failed to save profile');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="p-6 lg:p-10">
      <h1 className="text-4xl font-bold mb-8">My Profile</h1>

      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-3xl shadow-lg p-8 mb-8">
          <div className="flex items-center gap-8 mb-10">
            <div className="w-32 h-32 bg-gray-200 rounded-full flex items-center justify-center">
              <span className="text-5xl font-bold text-gray-600">
                {user?.name.charAt(0).toUpperCase()}
              </span>
            </div>
            <div>
              <h2 className="text-3xl font-bold">{user?.name}</h2>
              <p className="text-xl text-gray-600">@{user?.username}</p>
              <p className="text-lg text-gray-500">{user?.email}</p>
            </div>
          </div>

          <div className="space-y-8">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Full Name
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-6 py-4 border border-gray-300 rounded-xl focus:outline-none focus:border-purple-500 transition text-lg"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Profession
              </label>
              <select
                value={profession}
                onChange={(e) => setProfession(e.target.value)}
                className="w-full px-6 py-4 border border-gray-300 rounded-xl focus:outline-none focus:border-purple-500 transition text-lg"
              >
                <option value="developer">Developer</option>
                <option value="designer">Designer</option>
                <option value="freelancer">Freelancer</option>
                <option value="photographer">Photographer</option>
                <option value="writer">Writer</option>
                <option value="marketer">Marketer</option>
                <option value="student">Student</option>
                <option value="teacher">Teacher</option>
                <option value="other">Other</option>
              </select>
            </div>

            <button
              onClick={handleSave}
              disabled={saving}
              className="px-12 py-4 bg-gradient-to-r from-purple-600 to-purple-500 text-white font-bold text-lg rounded-xl hover:from-purple-700 hover:to-purple-600 transition disabled:opacity-70 shadow-lg"
            >
              {saving ? 'Saving...' : 'Save Profile'}
            </button>
          </div>
        </div>

        <div className="bg-white rounded-3xl shadow-lg p-8">
          <h3 className="text-2xl font-bold mb-6">Portfolio Stats</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center p-6 bg-gray-50 rounded-2xl">
              <p className="text-4xl font-bold text-purple-600">0</p>
              <p className="text-gray-600">Total Views</p>
            </div>
            <div className="text-center p-6 bg-gray-50 rounded-2xl">
              <p className="text-4xl font-bold text-purple-600">Live</p>
              <p className="text-gray-600">Portfolio Status</p>
            </div>
            <div className="text-center p-6 bg-gray-50 rounded-2xl">
              <p className="text-4xl font-bold text-purple-600">1</p>
              <p className="text-gray-600">Active Theme</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}