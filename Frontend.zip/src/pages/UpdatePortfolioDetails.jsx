

// import { useState, useEffect } from "react";
// import { ChevronLeft, ChevronRight, Save } from "lucide-react";
// import AboutForm from "../components/onboarding/forms/AboutForm";
// import EducationForm from "../components/onboarding/forms/EducationForm";
// import ContactForm from "../components/onboarding/forms/ContactForm";
// import { useLocation, useNavigate } from "react-router-dom";

// const steps = [
//   { id: 1, key: "about", title: "About Me", component: AboutForm },
//   { id: 2, key: "education", title: "Education", component: EducationForm },
//   { id: 3, key: "contact", title: "Contact & Socials", component: ContactForm },
// ];

// export default function UpdatePortfolioDetails() {
//   const location = useLocation();
//   const navigate = useNavigate();

//   // Get starting tab from URL or location state
//   const urlParams = new URLSearchParams(location.search);
//   const startTab = urlParams.get("tab"); // e.g. ?tab=education
//   const fromManager = location.state?.fromManager;

//   const [currentStep, setCurrentStep] = useState(() => {
//     if (startTab) {
//       const index = steps.findIndex(s => s.key === startTab);
//       return index >= 0 ? index : 0;
//     }
//     return 0;
//   });

//   const [formData, setFormData] = useState({
//     about: {},
//     education: [],
//     contact: {},
//   });

//   const CurrentForm = steps[currentStep].component;
//   const currentKey = steps[currentStep].key;

//   const handleNext = (newData) => {
//     setFormData(prev => ({ ...prev, ...newData }));

//     if (currentStep < steps.length - 1) {
//       setCurrentStep(currentStep + 1);
//       // Update URL to reflect current tab
//       navigate(`?tab=${steps[currentStep + 1].key}`, { replace: true });
//     } else {
//       console.log("Final Data:", { ...formData, ...newData });
//       alert(`${steps[currentStep].title} updated successfully!`);
//       if (fromManager) {
//         navigate(-1); // Go back to Portfolio Manager
//       }
//     }
//   };

//   const handleBack = () => {
//     if (currentStep > 0) {
//       setCurrentStep(currentStep - 1);
//       navigate(`?tab=${steps[currentStep - 1].key}`, { replace: true });
//     }
//   };

//   const progress = ((currentStep + 1) / steps.length) * 100;

//   // Update URL when step changes
//   useEffect(() => {
//     navigate(`?tab=${currentKey}`, { replace: true });
//   }, [currentStep, navigate, currentKey]);

//   return (
//     <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 py-12 px-4">
//       <div className="max-w-5xl mx-auto">
//         <div className="text-center mb-10">
//           <h1 className="text-4xl md:text-5xl font-bold text-gray-800 flex items-center justify-center gap-3">
//             <Save className="text-purple-600" size={40} />
//             Update Portfolio Details
//           </h1>
//           <p className="text-lg text-gray-600 mt-3">
//             Currently editing: <strong>{steps[currentStep].title}</strong>
//           </p>
//         </div>

//         {/* Progress Steps */}
//         <div className="mb-12">
//           <div className="flex items-center justify-between relative">
//             {steps.map((step, index) => (
//               <div key={step.id} className="flex items-center flex-1">
//                 <div className="relative flex flex-col items-center">
//                   <div
//                     className={`w-14 h-14 rounded-full flex items-center justify-center text-white font-bold text-lg transition-all duration-300 shadow-lg ${
//                       index <= currentStep
//                         ? "bg-purple-600 scale-110"
//                         : "bg-gray-300"
//                     }`}
//                   >
//                     {index + 1}
//                   </div>
//                   <p className="absolute -bottom-8 text-sm font-medium text-gray-700 whitespace-nowrap">
//                     {step.title}
//                   </p>
//                 </div>
//                 {index < steps.length - 1 && (
//                   <div
//                     className={`flex-1 h-1 mx-4 transition-all duration-500 ${
//                       index < currentStep ? "bg-purple-600" : "bg-gray-300"
//                     }`}
//                   />
//                 )}
//               </div>
//             ))}
//           </div>

//           <div className="mt-16">
//             <div className="h-3 bg-gray-200 rounded-full overflow-hidden shadow-inner">
//               <div
//                 className="h-full bg-gradient-to-r from-purple-600 to-pink-500 transition-all duration-700 ease-out"
//                 style={{ width: `${progress}%` }}
//               />
//             </div>
//           </div>
//         </div>

//         <div className="bg-white rounded-3xl shadow-2xl overflow-hidden border border-purple-100">
//           <CurrentForm
//             data={formData}
//             onNext={handleNext}
//             onBack={handleBack}
//             isLast={currentStep === steps.length - 1}
//           />
//         </div>

//         {/* Mobile Nav */}
//         <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4 flex justify-between items-center md:hidden shadow-lg">
//           <button
//             onClick={handleBack}
//             disabled={currentStep === 0}
//             className={`flex items-center gap-2 px-5 py-3 rounded-xl font-medium transition ${
//               currentStep === 0
//                 ? "bg-gray-100 text-gray-400"
//                 : "bg-gray-200 text-gray-700 hover:bg-gray-300"
//             }`}
//           >
//             Back
//           </button>

//           <span className="font-semibold text-purple-600">
//             {currentStep + 1} / {steps.length}
//           </span>

//           <button
//             onClick={() => handleNext({})}
//             className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-600 to-purple-500 text-white font-bold rounded-xl hover:from-purple-700 hover:to-purple-600 shadow-lg"
//           >
//             {currentStep === steps.length - 1 ? "Save & Close" : "Next"}
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// }


//v2


// src/pages/UpdatePortfolioDetails.jsx (UPDATED – Smaller fonts + Full container fit)

import { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight, Save } from "lucide-react";
import HeroForm from "../components/onboarding/forms/HeroForm";
import AboutForm from "../components/onboarding/forms/AboutForm";
import ExperienceForm from "../components/onboarding/forms/ExperienceForm";
import EducationForm from "../components/onboarding/forms/EducationForm";
import ProjectsForm from "../components/onboarding/forms/ProjectsForm";
import SkillsForm from "../components/onboarding/forms/SkillsForm";
import ServicesForm from "../components/onboarding/forms/ServicesForm";
import TestimonialsForm from "../components/onboarding/forms/TestimonialsForm";
import ContactForm from "../components/onboarding/forms/ContactForm";
import { useLocation, useNavigate } from "react-router-dom";
import portfolioService from "../services/portfolioService";
import { useAuth } from "../context/AuthContext";
import { toast } from "react-toastify";

const steps = [
  { id: 1, key: "hero", title: "Hero Section", component: HeroForm },
  { id: 2, key: "about", title: "About Me", component: AboutForm },
  { id: 3, key: "experience", title: "Experience", component: ExperienceForm },
  { id: 4, key: "education", title: "Education", component: EducationForm },
  { id: 5, key: "projects", title: "Projects", component: ProjectsForm },
  { id: 6, key: "skills", title: "Skills", component: SkillsForm },
  { id: 7, key: "services", title: "Services", component: ServicesForm },
  { id: 8, key: "testimonials", title: "Testimonials", component: TestimonialsForm },
  { id: 9, key: "contact", title: "Contact & Socials", component: ContactForm },
];

export default function UpdatePortfolioDetails() {
  const location = useLocation();
  const navigate = useNavigate();
  const { refreshPortfolio } = useAuth();

  const urlParams = new URLSearchParams(location.search);
  const startTab = urlParams.get("tab");
  const fromManager = location.state?.fromManager;

  const [currentStep, setCurrentStep] = useState(() => {
    if (startTab) {
      const index = steps.findIndex(s => s.key === startTab);
      return index >= 0 ? index : 0;
    }
    return 0;
  });

  const CurrentForm = steps[currentStep].component;
  const currentKey = steps[currentStep].key;

  const handleNext = async (newData) => {
    try {
      const updatePayload = {};
      const keyMap = {
        hero: "sections.hero.data",
        about: "sections.about.data",
        experience: "sections.experience.data",
        education: "sections.education.data",
        projects: "sections.projects.data",
        skills: "sections.skills.data",
        services: "sections.services.data",
        testimonials: "sections.testimonials.data",
        contact: "sections.contact.data"
      };

      const path = keyMap[currentKey];
      if (path && newData[currentKey] !== undefined) {
        updatePayload[path] = newData[currentKey];
      }

      if (Object.keys(updatePayload).length > 0) {
        await portfolioService.updatePortfolio(updatePayload);
        await refreshPortfolio();
        toast.success(`${steps[currentStep].title} saved successfully!`);
      }

      if (currentStep < steps.length - 1) {
        setCurrentStep(currentStep + 1);
        navigate(`?tab=${steps[currentStep + 1].key}`, { replace: true });
      } else {
        toast.success("All sections updated!");
        if (fromManager) {
          navigate(-1);
        } else {
          navigate('/portfolio-manage');
        }
      }
    } catch (err) {
      toast.error("Failed to save. Please try again.");
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
      navigate(`?tab=${steps[currentStep - 1].key}`, { replace: true });
    }
  };

  const progress = ((currentStep + 1) / steps.length) * 100;

  useEffect(() => {
    navigate(`?tab=${currentKey}`, { replace: true });
  }, [currentStep, navigate, currentKey]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 py-8 px-4">
      <div className="max-w-5xl mx-auto">
        {/* Header - Smaller fonts */}
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-800 flex items-center justify-center gap-3">
            <Save className="text-purple-600" size={32} />
            Update Portfolio Details
          </h1>
          <p className="text-base text-gray-600 mt-2">
            Currently editing: <strong>{steps[currentStep].title}</strong>
          </p>
        </div>

        {/* Progress Steps - Compact */}
        <div className="mb-8">
          <div className="flex flex-wrap justify-center gap-4">
            {steps.map((step, index) => (
              <div key={step.id} className="flex flex-col items-center">
                <div
                  className={`w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-sm transition-all duration-300 shadow-md ${
                    index <= currentStep
                      ? "bg-purple-600 scale-105"
                      : "bg-gray-300"
                  }`}
                >
                  {index + 1}
                </div>
                <p className="mt-2 text-xs font-medium text-gray-700 text-center max-w-24">
                  {step.title}
                </p>
              </div>
            ))}
          </div>

          <div className="mt-8">
            <div className="h-2 bg-gray-200 rounded-full overflow-hidden shadow-inner">
              <div
                className="h-full bg-gradient-to-r from-purple-600 to-pink-500 transition-all duration-700 ease-out"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        </div>

        {/* Form Container - Full width fit */}
        <div className="bg-white rounded-3xl shadow-xl border border-purple-100">
          <CurrentForm
            onNext={handleNext}
            onBack={handleBack}
            isLast={currentStep === steps.length - 1}
          />
        </div>

        {/* Mobile Navigation - Smaller */}
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-3 flex justify-between items-center md:hidden shadow-lg z-10">
          <button
            onClick={handleBack}
            disabled={currentStep === 0}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition ${
              currentStep === 0
                ? "bg-gray-100 text-gray-400 cursor-not-allowed"
                : "bg-gray-200 text-gray-700 hover:bg-gray-300"
            }`}
          >
            <ChevronLeft size={18} />
            Back
          </button>

          <span className="text-sm font-semibold text-purple-600">
            {currentStep + 1} / {steps.length}
          </span>

          <button
            onClick={() => handleNext({})}
            className="flex items-center gap-2 px-5 py-2 bg-gradient-to-r from-purple-600 to-purple-500 text-white font-medium text-sm rounded-lg hover:from-purple-700 hover:to-purple-600 shadow-md"
          >
            {currentStep === steps.length - 1 ? "Save & Close" : "Next"}
            <ChevronRight size={18} />
          </button>
        </div>
      </div>
    </div>
  );
}