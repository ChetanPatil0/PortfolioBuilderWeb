



// import { useEffect, useState, useMemo } from "react";
// import { useAuth } from "../context/AuthContext";
// import themeService from "../services/themeService";
// import { toast } from "react-toastify";
// import {
//   FiRefreshCw,
//   FiCheck,
//   FiEye,
//   FiTrendingUp,
//   FiLoader,
// } from "react-icons/fi";

// export default function ThemeGallery() {
//   const [allThemes, setAllThemes] = useState([]); // Original list
//   const [themes, setThemes] = useState([]);       // Filtered list
//   const [loading, setLoading] = useState(true);
//   const [activating, setActivating] = useState(null);
//   const [searchTerm, setSearchTerm] = useState("");
//   const { portfolio, setPortfolio } = useAuth();

//   // Load themes
//   const loadThemes = async () => {
//     setLoading(true);
//     try {
//       const res = await themeService.getAllThemes();
//       console.log('themses', res.data.themes);
//       setAllThemes(res.data.themes);
//       setThemes(res.data.themes);
//     } catch (err) {
//       toast.error("Failed to load themes. Please try again.");
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     loadThemes();
//   }, []);

//   // Search filter using useMemo for performance
//   const filteredThemes = useMemo(() => {
//     if (!searchTerm) return allThemes;
//     return allThemes.filter(
//       (theme) =>
//         theme.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
//         (theme.description &&
//           theme.description.toLowerCase().includes(searchTerm.toLowerCase()))
//     );
//   }, [allThemes, searchTerm]);

//   // Activate theme with toast feedback
//   const activateTheme = async (themeId) => {
//     if (portfolio?.theme === themeId) return;

//     setActivating(themeId);
//     try {
//       const res = await themeService.activateTheme(themeId);
//       setPortfolio(res.data.portfolio);
//       toast.success(`Theme "${res.data.portfolio.themeName || "activated"}" activated successfully!`, {
//         icon: <FiCheck className="text-green-600" />,
//       });
//     } catch (err) {
//       toast.error("Failed to activate theme. Try again.");
//     } finally {
//       setActivating(null);
//     }
//   };

//   return (
//     <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 relative">
//       {/* Animated Background */}
//       <div className="fixed inset-0 overflow-hidden pointer-events-none -z-10">
//         <div className="absolute -top-40 -right-40 w-80 h-80 bg-purple-300 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-pulse"></div>
//         <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-indigo-300 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-pulse delay-700"></div>
//         <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-pink-300 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-pulse delay-1000"></div>
//       </div>

//       {/* Header */}
//       <div className="relative backdrop-blur-sm bg-white/80 border-b border-gray-200/50 shadow-sm">
//         <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
//           <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
//             <div>
//               <div className="flex items-center gap-3 mb-2">
//                 <h1 className="text-3xl font-bold text-gray-900">Theme Gallery</h1>
//                 <span className="px-3 py-1 bg-gradient-to-r from-indigo-500 to-purple-600 text-white text-xs font-bold rounded-full">
//                   Premium
//                 </span>
//               </div>
//               <p className="text-gray-600">Choose a stunning theme to elevate your portfolio</p>
//             </div>

//             <div className="flex flex-col sm:flex-row gap-3">
//               <div className="relative">
//                 <input
//                   type="text"
//                   placeholder="Search themes..."
//                   value={searchTerm}
//                   onChange={(e) => setSearchTerm(e.target.value)}
//                   className="pl-10 pr-4 py-2.5 w-full sm:w-64 bg-white border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition"
//                 />
//                 <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
//                 </svg>
//               </div>

//               <button
//                 onClick={loadThemes}
//                 disabled={loading}
//                 className="flex items-center justify-center gap-2 px-5 py-2.5 bg-gray-900 text-white rounded-lg hover:bg-gray-800 disabled:opacity-60 transition font-medium"
//               >
//                 {loading ? <FiLoader className="w-4 h-4 animate-spin" /> : <FiRefreshCw className="w-4 h-4" />}
//                 Refresh
//               </button>
//             </div>
//           </div>
//         </div>
//       </div>

//       {/* Main Content */}
//       <div className="max-w-7xl mx-auto px-6 py-12">
//         {loading ? (
//           <div className="flex flex-col items-center justify-center py-32">
//             <FiLoader className="w-12 h-12 text-indigo-600 animate-spin mb-4" />
//             <p className="text-lg text-gray-700">Loading beautiful themes...</p>
//           </div>
//         ) : filteredThemes.length === 0 ? (
//           <div className="text-center py-32">
//             <div className="max-w-md mx-auto bg-white/90 backdrop-blur-sm rounded-3xl p-12 shadow-2xl">
//               <div className="w-24 h-24 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
//                 <svg className="w-12 h-12 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2m-6 0h6" />
//                 </svg>
//               </div>
//               <h3 className="text-2xl font-bold text-gray-900 mb-3">
//                 {searchTerm ? "No themes found" : "No themes available yet"}
//               </h3>
//               <p className="text-gray-600 mb-8">
//                 {searchTerm ? `Try searching for something else.` : `Check back soon for new designs!`}
//               </p>
//               <button
//                 onClick={loadThemes}
//                 className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-semibold rounded-xl hover:shadow-xl transition"
//               >
//                 <FiRefreshCw /> Refresh
//               </button>
//             </div>
//           </div>
//         ) : (
//           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
//             {filteredThemes.map((theme, index) => {
//               const isActive = portfolio?.theme === theme.themeId;
//               const isActivating = activating === theme.themeId;

//               return (
//                 <div
//                   key={theme.themeId}
//                   className="group relative"
//                   style={{ animation: `fadeInUp 0.7s ease-out forwards ${index * 0.1}s` }}
//                 >
//                   <div className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 overflow-hidden hover:-translate-y-2">
//                     {/* Preview Image */}
//                     <div className="relative h-56 bg-gray-100 overflow-hidden">
//                       <img
//                         src={theme.previewImage || "/api/placeholder/400/320"}
//                         alt={theme.name}
//                         className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
//                       />
//                       <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

//                       {/* Active Badge */}
//                       {isActive && (
//                         <div className="absolute top-4 right-4 bg-green-500 text-white px-3 py-1.5 rounded-full text-xs font-bold flex items-center gap-1 shadow-lg">
//                           <FiCheck className="w-4 h-4" /> Active
//                         </div>
//                       )}

//                       {/* Preview Overlay */}
//                       <div
//                         onClick={() =>
//                           window.open(`/${portfolio?.username}?preview=${theme.themeId}`, "_blank")
//                         }
//                         className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 cursor-pointer"
//                       >
//                         <div className="bg-white px-5 py-3 rounded-xl shadow-2xl flex items-center gap-2 font-bold text-gray-800">
//                           <FiEye className="w-5 h-5" /> Preview
//                         </div>
//                       </div>
//                     </div>

//                     {/* Card Body */}
//                     <div className="p-6">
//                       <div className="flex items-center justify-between mb-3">
//                         <h3 className="text-xl font-bold text-gray-900">{theme.name}</h3>
//                         {theme.popular && <FiTrendingUp className="text-indigo-600 w-5 h-5" />}
//                       </div>
//                       <p className="text-gray-600 text-sm mb-5 line-clamp-2">
//                         {theme.description || "A modern, elegant theme for creative portfolios."}
//                       </p>

//                       <button
//                         onClick={() => activateTheme(theme.themeId)}
//                         disabled={isActive || isActivating}
//                         className={`w-full py-3 rounded-xl font-semibold text-sm transition-all duration-300 flex items-center justify-center gap-2 ${
//                           isActive
//                             ? "bg-green-500 text-white cursor-default"
//                             : isActivating
//                             ? "bg-indigo-600 text-white cursor-wait"
//                             : "bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:from-indigo-700 hover:to-purple-700 shadow-lg hover:shadow-xl"
//                         }`}
//                       >
//                         {isActivating ? (
//                           <>
//                             <FiLoader className="animate-spin" /> Activating...
//                           </>
//                         ) : isActive ? (
//                           <>
//                             <FiCheck /> Active Theme
//                           </>
//                         ) : (
//                           "Activate Theme"
//                         )}
//                       </button>
//                     </div>
//                   </div>
//                 </div>
//               );
//             })}
//           </div>
//         )}
//       </div>

//       {/* Toast Container - Must be in root */}
//       {/* Add this in your root layout or App.js */}
//       {/* <ToastContainer /> */}

//       <style jsx>{`
//         @keyframes fadeInUp {
//           from {
//             opacity: 0;
//             transform: translateY(30px);
//           }
//           to {
//             opacity: 1;
//             transform: translateY(0);
//           }
//         }
//       `}</style>
//     </div>
//   );
// }




import { useEffect, useState } from 'react';
import themeService from '../services/themeService';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';
import LoadingSpinner from '../components/common/LoadingSpinner';


export default function ThemeGallery() {
  const [themes, setThemes] = useState([]);
  const [loading, setLoading] = useState(true);
  const { portfolio, refreshPortfolio } = useAuth();

  useEffect(() => {
    const load = async () => {
      try {
        const res = await themeService.getAllThemes();
        console.log('Themes loaded:', res.data.themes);
        setThemes(res.data.themes);
      } catch (err) {
        toast.error('Failed to load themes');
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const activate = async (themeId) => {

    console.log('Activating theme:', themeId);
    if (!themeId) return;

    try {
     const result =  await themeService.activateTheme(themeId);
      await refreshPortfolio();
      console.log('Theme activated, portfolio refreshed',result);
      toast.success('Theme activated successfully!');
    } catch (err) {
      console.error('Activation error:', err);
      toast.error(err.message || 'Failed to activate theme');
    }
  };

  // Loading State
  if (loading) {
    return <LoadingSpinner />;
  }

  // Empty State
  if (themes.length === 0) {
    return (
      <div className="p-6 lg:p-10 min-h-screen flex flex-col items-center justify-center bg-gray-50">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">No Themes Available</h1>
          <p className="text-xl text-gray-600 mb-8">
            Themes are being added by the admin. Please check back later.
          </p>
          <div className="w-64 h-64 mx-auto opacity-30">
            <img src="/placeholder.jpg" alt="No themes" className="w-full h-full object-cover rounded-3xl" />
          </div>
        </div>
      </div>
    );
  }

  // Main Gallery
  return (
    <div className="p-6 lg:p-10">
      <h1 className="text-4xl font-bold mb-4">Theme Gallery</h1>
      <p className="text-lg text-gray-600 mb-12">
        Choose a beautiful theme for your portfolio
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
        {themes.map((theme) => {
          const isActive = portfolio?.activeTheme?.themeId === theme.themeId;

          return (
            <div
              key={theme.themeId}
              className="bg-white rounded-3xl shadow-lg overflow-hidden hover:shadow-2xl transition-transform hover:-translate-y-2 duration-300"
            >
              {/* Preview Image */}
              <div className="h-64 bg-gray-200 relative group">
                <img
                  src={theme.previewImage || '/placeholder.jpg'}
                  alt={theme.name}
                  className="w-full h-full object-cover"
                />

                {/* Active Badge */}
                {isActive && (
                  <div className="absolute top-4 right-4 bg-green-500 text-white px-4 py-2 rounded-full text-sm font-bold shadow-lg">
                    Active
                  </div>
                )}

                {/* Hover Overlay - Preview Link */}
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                  <a
                    href={`/${portfolio?.username}?preview=${theme.themeId}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-8 py-4 bg-white text-black font-bold rounded-xl hover:bg-gray-100 transition text-lg"
                  >
                    Preview Live
                  </a>
                </div>
              </div>

              {/* Theme Info */}
              <div className="p-6">
                <h3 className="text-2xl font-bold mb-2">{theme.name}</h3>
                <p className="text-gray-600 mb-6 line-clamp-2">
                  {theme.description || 'A beautiful professional theme'}
                </p>

                {/* Activate Button */}
                <button
                  onClick={() => activate(theme.themeId)}
                  disabled={isActive}
                  className={`w-full py-4 rounded-xl font-bold text-lg transition shadow-md ${
                    isActive
                      ? 'bg-green-500 text-white cursor-not-allowed'
                      : 'bg-black text-white hover:bg-gray-800 active:scale-95'
                  }`}
                >
                  {isActive ? 'Currently Active' : 'Activate Theme'}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}