// src/pages/AdminDashboard.jsx (NEW – Admin Home Dashboard)
import { useEffect, useState } from 'react';
import api from '../../services/api';
import { Link } from 'react-router-dom';


export default function AdminDashboard() {
  const [stats, setStats] = useState({ users: 0, portfolios: 0, themes: 0, views: 0 });

  useEffect(() => {
    const load = async () => {
      try {
        const usersRes = await api.get('/admin/users');
        setStats({
          users: usersRes.data.users.length,
          portfolios: usersRes.data.users.filter(u => u.analytics).length,
          themes: 12, // placeholder
          views: usersRes.data.users.reduce((sum, u) => sum + (u.analytics?.views || 0), 0)
        });
      } catch (err) {
        console.error(err);
      }
    };
    load();
  }, []);

  return (
    <div className="p-6 lg:p-10">
      <h1 className="text-4xl font-bold mb-8">Admin Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
        <div className="bg-white rounded-3xl shadow-lg p-8 text-center">
          <p className="text-5xl font-bold text-purple-600 mb-2">{stats.users}</p>
          <p className="text-xl text-gray-600">Total Users</p>
        </div>
        <div className="bg-white rounded-3xl shadow-lg p-8 text-center">
          <p className="text-5xl font-bold text-pink-600 mb-2">{stats.portfolios}</p>
          <p className="text-xl text-gray-600">Live Portfolios</p>
        </div>
        <div className="bg-white rounded-3xl shadow-lg p-8 text-center">
          <p className="text-5xl font-bold text-indigo-600 mb-2">{stats.themes}</p>
          <p className="text-xl text-gray-600">Prebuilt Themes</p>
        </div>
        <div className="bg-white rounded-3xl shadow-lg p-8 text-center">
          <p className="text-5xl font-bold text-green-600 mb-2">{stats.views.toLocaleString()}</p>
          <p className="text-xl text-gray-600">Total Views</p>
        </div>
      </div>

      <div className="bg-white rounded-3xl shadow-lg p-8">
        <h2 className="text-3xl font-bold mb-6">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Link to="/admin/users" className="px-8 py-6 bg-purple-100 text-purple-700 rounded-2xl text-center font-bold text-xl hover:bg-purple-200 transition">
            Manage Users
          </Link>
          <Link to="/admin/themes" className="px-8 py-6 bg-pink-100 text-pink-700 rounded-2xl text-center font-bold text-xl hover:bg-pink-200 transition">
            Manage Themes
          </Link>
        </div>
      </div>
    </div>
  );
}