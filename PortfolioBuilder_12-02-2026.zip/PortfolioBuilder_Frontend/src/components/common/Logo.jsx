import React from 'react';
import { COLORS } from '../../constants/colors';


const Logo = ({ size = 'md', className = '' }) => {
  const sizes = {
    sm: 'text-2xl',
    md: 'text-4xl',
    lg: 'text-5xl',
    xl: 'text-6xl',
  };

  return (
    <div className={`flex items-center gap-2 font-bold ${sizes[size] || sizes.md} ${className}`}>
      <span style={{ color: COLORS.primary }}>Portfolia</span>
    </div>
  );
};

export default Logo;