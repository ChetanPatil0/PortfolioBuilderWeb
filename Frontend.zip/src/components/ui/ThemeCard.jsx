// src/components/ui/ThemeCard.jsx
import { Check } from 'lucide-react';

export default function ThemeCard({ theme, isActive, onClick }) {
  return (
    <div
      onClick={onClick}
      className={`relative rounded-3xl overflow-hidden cursor-pointer transition-all duration-500 group
        ${isActive ? 'ring-8 ring-black ring-offset-8' : 'hover:scale-105'}`}
    >
      <div className={`h-96 ${theme.preview} p-10 flex flex-col justify-between`}>
        <div>
          <h3 className={`text-4xl font-bold ${theme.text}`}>{theme.name}</h3>
          <p className={`text-xl mt-2 opacity-80 ${theme.text}`}>{theme.profession}</p>
        </div>

        <div className={`${theme.card} p-8`}>
          <p className={`text-5xl ${theme.typography} ${theme.text}`}>Your Work</p>
          <div className="mt-6 space-y-2">
            {theme.features.map(f => (
              <p key={f} className="text-sm opacity-70">{f}</p>
            ))}
          </div>
        </div>

        {isActive && (
          <div className="absolute inset-0 bg-black/70 flex items-center justify-center">
            <div className="bg-white text-black px-12 py-6 rounded-full flex items-center gap-4">
              <Check className="w-10 h-10" />
              <span className="text-2xl font-bold">ACTIVE</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}