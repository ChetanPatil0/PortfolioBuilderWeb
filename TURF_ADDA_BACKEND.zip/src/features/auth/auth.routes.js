import express from 'express';
import { register, verifyOTP, login, updateProfile } from './auth.controller.js';
import { authCheck, authorizeRoles } from '../../middlewares/auth.js';
import { uploadFile, processUpload } from '../../middlewares/fileUpload.js';

const router = express.Router();

router.post('/register', register);
router.post('/verify-otp', verifyOTP);
router.post('/login', login);

router.patch(
  '/profile',
  authCheck,
  uploadFile('profileImage'),
  processUpload,
  updateProfile
);

export default router;