// src/constants/themes.js
export const THEMES = [
  {
    id: "developer",
    name: "Developer Mode",
    profession: "Software Engineer",
    preview: "bg-gradient-to-br from-gray-900 to-black",
    card: "border border-gray-700 bg-gray-950/80 backdrop-blur hover:border-cyan-500",
    typography: "font-mono",
    primary: "#06b6d4",
    text: "text-gray-100",
    features: ["Terminal Header", "Tech Badges", "Code Animation", "Dark Grid"]
  },
  {
    id: "designer",
    name: "Creative Designer",
    profession: "UI/UX Designer",
    preview: "bg-gradient-to-br from-purple-900 via-pink-900 to-rose-900",
    card: "rounded-3xl overflow-hidden shadow-2xl hover:scale-105",
    typography: "font-serif",
    primary: "#ec4899",
    text: "text-white",
    features: ["Big Hero", "Parallax", "Cursive Text", "Case Studies"]
  },
  {
    id: "minimalist",
    name: "Executive Minimal",
    profession: "Product Manager",
    preview: "bg-white",
    card: "border-b-4 border-black pb-12",
    typography: "font-sans",
    primary: "#000000",
    text: "text-black",
    features: ["Clean Lines", "Large Type", "Professional", "Resume Style"]
  },
  {
    id: "photographer",
    name: "Visual Artist",
    profession: "Photographer",
    preview: "bg-black",
    card: "group relative overflow-hidden",
    typography: "font-light tracking-widest",
    primary: "#ffffff",
    text: "text-white",
    features: ["Full Images", "Hover Zoom", "Lightbox", "Minimal Text"]
  },
  {
    id: "founder",
    name: "Startup Founder",
    profession: "CEO / Founder",
    preview: "bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600",
    card: "bg-white/10 backdrop-blur-lg rounded-3xl p-10 border border-white/20",
    typography: "font-bold text-5xl",
    primary: "#a855f7",
    text: "text-white",
    features: ["Bold CTA", "Metrics", "Testimonials", "Gradient Text"]
  }
];