// src/context/AuthContext.jsx
import { createContext, useContext, useState, useEffect } from 'react';
import { authService } from '../services/authService';
import { portfolioService } from '../services/portfolioService';

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [portfolio, setPortfolio] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showOnboarding, setShowOnboarding] = useState(false); // ← ONBOARDING STATE

  // Check if user needs onboarding
  const needsOnboarding = (portfolio) => {
    if (!portfolio) return true;
    if (!portfolio.sections?.hero?.data?.name) return true;
    if (!portfolio.sections?.about?.data?.text) return true;
    if (!portfolio.sections?.contact?.data?.email) return true;
    return false;
  };

  const loadUser = async () => {
    try {
      const [userRes, portfolioRes] = await Promise.all([
        authService.getMe(),
        portfolioService.getMyPortfolio()
      ]);

      setUser(userRes.data.user);
      setPortfolio(portfolioRes.data.portfolio);

      // AUTO DETECT ONBOARDING
      const shouldShowOnboarding = needsOnboarding(portfolioRes.data.portfolio);
      setShowOnboarding(shouldShowOnboarding);

    } catch (err) {
      console.error('Auth load failed:', err);
      localStorage.removeItem('token');
      setUser(null);
      setPortfolio(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (localStorage.getItem('token')) {
      loadUser();
    } else {
      setLoading(false);
    }
  }, []);

  const login = async (credentials) => {
    console.log('Logging in with credentials:', credentials);
    const res = await authService.login(credentials);
    console.log('Login response:', res);
    localStorage.setItem('token', res.data.token);
    await loadUser();
  };

  const register = async (data) => {
    const res = await authService.register(data);
    localStorage.setItem('token', res.data.token);
    await loadUser();
  };

  const logout = async () => {
    try {
      await authService.logout();
    } catch (err) {
      console.error(err);
    }
    localStorage.removeItem('token');
    setUser(null);
    setPortfolio(null);
    setShowOnboarding(false);
  };

  // Force reload portfolio (after onboarding)
  const refreshPortfolio = async () => {
    try {
      const res = await portfolioService.getMyPortfolio();
      setPortfolio(res.data.portfolio);
      setShowOnboarding(needsOnboarding(res.data.portfolio));
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <AuthContext.Provider value={{
      user,
      portfolio,
      setPortfolio,
      login,
      register,
      logout,
      loading,
      isAuthenticated: !!user,
      showOnboarding,           // ← Expose to App
      setShowOnboarding,        // ← Allow closing
      refreshPortfolio          // ← Call after onboarding
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);