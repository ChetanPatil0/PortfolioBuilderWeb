
import { create } from 'zustand';

const useAuthStore = create((set) => ({
  user: null,
  token: localStorage.getItem('token') || null,
  isAuthenticated: !!localStorage.getItem('token'),

  setAuth: (userData, newToken) => {
    localStorage.setItem('token', newToken);
    set({ 
      user: userData, 
      token: newToken, 
      isAuthenticated: true 
    });
  },

  logout: () => {
    localStorage.removeItem('token');
    set({ user: null, token: null, isAuthenticated: false });
  },

  updateUser: (updatedUser) => {
    set({ user: updatedUser });
  },
}));

export default useAuthStore;