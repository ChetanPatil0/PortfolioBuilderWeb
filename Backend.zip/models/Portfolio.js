// models/Portfolio.js
import mongoose, { Schema } from 'mongoose';

const portfolioSchema = new mongoose.Schema({
  user_id: { type: String, required: true, unique: true }, 
  username: { type: String, required: true, unique: true, lowercase: true },

  // SEO & Analytics
  seo: {
    title: { type: String, default: 'My Portfolio' },
    description: { type: String, default: 'Professional portfolio' },
    keywords: [String],
    favicon: String,
    ogImage: String
  },

  analytics: {
    views: { type: Number, default: 0 },
    lastViewed: Date
  },

  // Section Order
  sectionsOrder: {
    type: [String],
    default: ['hero', 'about', 'experience', 'education', 'projects', 'skills', 'services', 'testimonials', 'contact']
  },

  // YOUR EXACT SECTIONS – FULLY TYPED
  sections: {
    hero: {
      enabled: { type: Boolean, default: true },
      data: {
        name: String,
        title: String,
        bio: String,
        avatar: String,
        bannerImage: String,
        ctaText: String,
        ctaLink: String
      }
    },
    about: {
      enabled: { type: Boolean, default: true },
      data: {
        heading: { type: String, default: 'About Me' },
        text: String,
        image: String,
        resumeDownload: String
      }
    },
    experience: {
      enabled: { type: Boolean, default: true },
      data: [{
        company: String,
        role: String,
        duration: String,
        location: String,
        description: String,
        current: { type: Boolean, default: false },
        logo: String
      }]
    },
    education: {
      enabled: { type: Boolean, default: true },
      data: [{
        school: String,
        degree: String,
        field: String,
        duration: String,
        grade: String,
        logo: String
      }]
    },
    projects: {
      enabled: { type: Boolean, default: true },
      data: [{
        title: String,
        description: String,
        techStack: [String],
        liveUrl: String,
        githubUrl: String,
        image: String,
        featured: { type: Boolean, default: false },
        videoDemo: String
      }]
    },
    skills: {
      enabled: { type: Boolean, default: true },
      data: [{
        name: String,
        level: { type: Number, min: 0, max: 100 },
        category: String,
        icon: String
      }]
    },
    services: {
      enabled: { type: Boolean, default: true },
      data: [{
        title: String,
        price: String,
        description: String,
        features: [String],
        icon: String,
        popular: { type: Boolean, default: false }
      }]
    },

    testimonials: {
      enabled: { type: Boolean, default: false },
      data: [{
        name: String,
        role: String,
        company: String,
        text: String,
        avatar: String,
        rating: { type: Number, min: 1, max: 5 }
      }]
    },
    contact: {
      enabled: { type: Boolean, default: true },
      data: {
        heading: { type: String, default: 'Get In Touch' },
        email: String,
        phone: String,
        location: String,
        availability: String,
        socials: {
          linkedin: String,
          github: String,
          twitter: String,
          instagram: String,
          youtube: String,
          dribbble: String,
          behance: String
        },
        showForm: { type: Boolean, default: true }
      }
    }
  },

  // Appearance – Uses Theme from DB
appearance: {
    theme: { 
      type: Schema.Types.ObjectId, 
      ref: 'Theme',
      default: null 
    }
  },

  settings: {
    isPublic: { type: Boolean, default: true },
    passwordProtect: String,
    customDomain: String
  }
}, { timestamps: true });

portfolioSchema.index({ user_id: 1 });
portfolioSchema.index({ username: 1 });

export default mongoose.model('Portfolio', portfolioSchema);