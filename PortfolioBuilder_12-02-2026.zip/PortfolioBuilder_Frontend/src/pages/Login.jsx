import React, { useState } from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { useAuth } from '../context/AuthContext';
import { useMessageModal } from '../context/MessageModalContext';
import Logo from '../components/common/Logo';

import { FiMail, FiLock, FiEye, FiEyeOff } from 'react-icons/fi';
import { FaGoogle, FaGithub } from 'react-icons/fa';

const validationSchema = Yup.object({
  identifier: Yup.string().required('Email or Username is required'),
  password: Yup.string()
    .min(6, 'Password must be at least 6 characters')
    .required('Password is required'),
});

export default function Login() {
  const { login } = useAuth();
  const { showMessage } = useMessageModal();

  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = async (values, { setSubmitting, resetForm }) => {
    try {
      await login(values);
      showMessage({
        type: 'success',
        title: 'Welcome back!',
        message: 'You have successfully logged in.',
        primaryButtonText: 'Continue',
        autoCloseMs: 2500,
      });
      resetForm();
    } catch (err) {
      console.error('Login error:', err);
      showMessage({
        type: 'error',
        title: 'Login Failed',
        message: err.message || 'Invalid credentials or server error. Please try again.',
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col lg:flex-row bg-gray-50">
      <div className="w-full lg:w-1/2 flex items-center justify-center px-5 py-8 lg:p-10 bg-white">
        <div className="w-full max-w-md space-y-6">
          <div className="flex justify-center lg:justify-start mb-8">
            <Logo size="lg" />
          </div>

          <div className="text-center lg:text-left">
            <h1 className="text-3xl font-bold text-gray-900">Welcome back</h1>
            <p className="mt-2 text-gray-600 text-base">
              Sign in to continue building your portfolio
            </p>
          </div>

          <Formik
            initialValues={{ identifier: '', password: '' }}
            validationSchema={validationSchema}
            onSubmit={handleSubmit}
          >
            {({ isSubmitting }) => (
              <Form className="space-y-5">
                <div>
                  <label htmlFor="identifier" className="block text-sm font-medium text-gray-700 mb-1.5">
                    Email
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                      <FiMail size={18} className="text-gray-400" />
                    </div>
                    <Field
                      id="identifier"
                      name="identifier"
                      type="text"
                      placeholder="you@example.com"
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none transition placeholder-gray-400 text-base"
                    />
                  </div>
                  <ErrorMessage
                    name="identifier"
                    component="p"
                    className="mt-1.5 text-sm text-red-600"
                  />
                </div>

                <div>
                  <div className="flex justify-between items-center mb-1.5">
                    <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                      Password
                    </label>
                    <a href="/forgot-password" className="text-sm text-purple-600 hover:underline">
                      Forgot password?
                    </a>
                  </div>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                      <FiLock size={18} className="text-gray-400" />
                    </div>
                    <Field
                      id="password"
                      name="password"
                      type={showPassword ? 'text' : 'password'}
                      placeholder="Enter your password"
                      className="w-full pl-10 pr-10 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none transition placeholder-gray-400 text-base"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-gray-400 hover:text-gray-600 focus:outline-none"
                    >
                      {showPassword ? (
                        <FiEyeOff size={18} />
                      ) : (
                        <FiEye size={18} />
                      )}
                    </button>
                  </div>
                  <ErrorMessage
                    name="password"
                    component="p"
                    className="mt-1.5 text-sm text-red-600"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3.5 bg-gradient-to-r from-purple-600 via-purple-500 to-pink-500 text-white font-semibold rounded-lg shadow-md hover:from-purple-700 hover:via-purple-600 hover:to-pink-600 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 transition disabled:opacity-60 text-base mt-2"
                >
                  {isSubmitting ? 'Signing in...' : 'Sign In →'}
                </button>
              </Form>
            )}
          </Formik>

          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-300" />
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-4 bg-white text-gray-500">OR CONTINUE WITH</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <button className="flex items-center justify-center gap-2 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition text-gray-700">
              <FaGoogle size={18} className="text-red-500" />
              <span>Google</span>
            </button>
            <button className="flex items-center justify-center gap-2 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition text-gray-700">
              <FaGithub size={18} className="text-gray-900" />
              <span>GitHub</span>
            </button>
          </div>

          <p className="text-center text-sm text-gray-600 mt-6">
            Don't have an account?{' '}
            <a href="/register" className="text-purple-600 font-medium hover:underline">
              Sign up for free
            </a>
          </p>
        </div>
      </div>

      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-purple-700 via-purple-600 to-pink-600 items-center justify-center px-8 xl:px-12 text-white relative overflow-hidden h-screen sticky top-0">
        <div className="absolute inset-0 bg-black/10"></div>

        <div className="relative z-10 max-w-lg text-center space-y-10">
          <h2 className="text-4xl xl:text-5xl efont-extrabold tracking-tight leading-tight drop-shadow-md">
            Build Your Dream Portfolio
          </h2>

          <p className="text-lg xl:text-xl opacity-90 font-light max-w-sm mx-auto">
            Join thousands of professionals showcasing their work. Beautiful, no-code portfolios.
          </p>
        </div>
      </div>
    </div>
  );
}