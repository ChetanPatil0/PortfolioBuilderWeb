// src/pages/NotFound.jsx
export default function NotFound() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center">
      <div className="text-center text-white">
        <h1 className="text-9xl font-black mb-10">404</h1>
        <p className="text-5xl mb-10">Page Not Found</p>
        <a href="/" className="text-3xl underline">Go Home</a>
      </div>
    </div>
  );
}