
import { Formik, Form, Field, FieldArray, ErrorMessage } from "formik";
import * as Yup from "yup";
import { Plus, Trash2 } from "lucide-react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const validationSchema = Yup.object({
  education: Yup.array()
    .of(
      Yup.object({
        school: Yup.string().required("School / University is required"),
        degree: Yup.string().required("Degree is required"),
        field: Yup.string().required("Field of study is required"),
        duration: Yup.string().required("Duration is required"),
      })
    )
    .min(1, "Add at least one education entry"),
});

export default function EducationForm({ data = {}, onNext, onBack, isLast }) {
  const initialValues = {
    education: data.education || [
      // If you want to start with a single empty entry by default, uncomment next line:
      // { school: "", degree: "", field: "", duration: "" },
    ],
  };

  const handleSubmit = (values, { setSubmitting }) => {
    setTimeout(() => {
      onNext({ education: values.education });
      toast.success("Education saved!");
      setSubmitting(false);
    }, 600);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <ToastContainer position="top-right" autoClose={3000} />

      <div className="bg-white rounded-3xl shadow-xl w-full max-w-4xl overflow-hidden">
        {/* Purple Header */}
        <div className="bg-gradient-to-r from-purple-600 to-purple-500 text-white font-bold py-4 text-center text-xl rounded-t-3xl">
          Add Your Education
        </div>

        <div className="p-4 lg:p-6">
          <Formik
            initialValues={initialValues}
            validationSchema={validationSchema}
            onSubmit={handleSubmit}
            enableReinitialize
          >
            {({ values, isSubmitting }) => (
              <Form className="space-y-8">
                <FieldArray name="education">
                  {({ push, remove }) => (
                    <>
                      {/* Add Button */}
                      <button
                        type="button"
                        onClick={() =>
                          push({
                            school: "",
                            degree: "",
                            field: "",
                            duration: "",
                          })
                        }
                        className="flex items-center gap-3 px-6 py-3 bg-gradient-to-r from-purple-600 to-purple-500 text-white font-semibold rounded-lg shadow hover:from-purple-700 hover:to-purple-600 transition"
                      >
                        <Plus size={20} /> Add Education
                      </button>

                      {/* List of education items */}
                      {values.education && values.education.length > 0 ? (
                        values.education.map((edu, index) => (
                          <div
                            key={index}
                            className="p-6 border border-gray-300 rounded-2xl space-y-6 shadow-sm"
                          >
                            {/* School / University */}
                            <div>
                              <label className="block text-gray-700 text-sm font-medium mb-1">
                                School / University <span className="text-red-500">*</span>
                              </label>
                              <Field
                                name={`education.${index}.school`}
                                placeholder="University / College"
                                className="w-full px-4 py-3 text-base border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500 transition"
                              />
                              <ErrorMessage
                                name={`education.${index}.school`}
                                component="div"
                                className="text-red-500 text-xs mt-1"
                              />
                            </div>

                            {/* Degree */}
                            <div>
                              <label className="block text-gray-700 text-sm font-medium mb-1">
                                Degree <span className="text-red-500">*</span>
                              </label>
                              <Field
                                name={`education.${index}.degree`}
                                placeholder="Degree (e.g. B.Tech)"
                                className="w-full px-4 py-3 text-base border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500 transition"
                              />
                              <ErrorMessage
                                name={`education.${index}.degree`}
                                component="div"
                                className="text-red-500 text-xs mt-1"
                              />
                            </div>

                            {/* Field of Study */}
                            <div>
                              <label className="block text-gray-700 text-sm font-medium mb-1">
                                Field of Study <span className="text-red-500">*</span>
                              </label>
                              <Field
                                name={`education.${index}.field`}
                                placeholder="Computer Science"
                                className="w-full px-4 py-3 text-base border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500 transition"
                              />
                              <ErrorMessage
                                name={`education.${index}.field`}
                                component="div"
                                className="text-red-500 text-xs mt-1"
                              />
                            </div>

                            {/* Duration */}
                            <div>
                              <label className="block text-gray-700 text-sm font-medium mb-1">
                                Duration <span className="text-red-500">*</span>
                              </label>
                              <Field
                                name={`education.${index}.duration`}
                                placeholder="2018 - 2022"
                                className="w-full px-4 py-3 text-base border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500 transition"
                              />
                              <ErrorMessage
                                name={`education.${index}.duration`}
                                component="div"
                                className="text-red-500 text-xs mt-1"
                              />
                            </div>

                            {/* Remove button */}
                            <div className="flex justify-end">
                              <button
                                type="button"
                                onClick={() => remove(index)}
                                className="text-red-600 flex items-center gap-2 font-medium"
                              >
                                <Trash2 size={18} /> Remove
                              </button>
                            </div>
                          </div>
                        ))
                      ) : (
                        <div className="text-sm text-gray-500">No education added yet. Click "Add Education" to create one.</div>
                      )}
                    </>
                  )}
                </FieldArray>

                {/* Navigation Buttons */}
                <div className="flex justify-between items-center pt-8 border-t border-gray-200 mt-6">
                  <button
                    type="button"
                    onClick={onBack}
                    className="px-8 py-3 text-base font-medium text-gray-700 border-2 border-gray-300 rounded-lg hover:bg-gray-50 transition"
                  >
                    ← Back
                  </button>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-12 py-3 bg-gradient-to-r from-purple-600 to-purple-500 text-white font-bold text-base rounded-lg hover:from-purple-700 hover:to-purple-600 transition disabled:opacity-70 shadow-lg"
                  >
                    {isSubmitting ? "Saving..." : isLast ? "Finish Setup" : "Next →"}
                  </button>
                </div>
              </Form>
            )}
          </Formik>
        </div>
      </div>
    </div>
  );
}
