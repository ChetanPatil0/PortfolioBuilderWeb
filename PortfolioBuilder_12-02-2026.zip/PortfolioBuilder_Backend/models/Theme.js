// import mongoose from 'mongoose';

// const themeSchema = new mongoose.Schema({
//   themeId: { type: String, required: true, unique: true },
//   name: { type: String, required: true },
//   description: String,
//   previewImage: String,

//   createdBy: { type: String, required: true }, 
//   createdByUsername: { type: String, required: true },

//   type: { type: String, enum: ['prebuilt', 'custom'], default: 'custom' },
//   visibility: { type: String, enum: ['private', 'public'], default: 'private' },

//   design: {
//     background: mongoose.Schema.Types.Mixed,
//     colors: mongoose.Schema.Types.Mixed,
//     font: String,
//     borderRadius: String,
//     shadow: String,
//     animation: String,
//     customCode: String
//   },

//   usedByCount: { type: Number, default: 0 },
//   likes: { type: Number, default: 0 }
// }, { timestamps: true });

// export default mongoose.model('Theme', themeSchema);



// import mongoose from 'mongoose';
// import { v4 as uuidv4 } from 'uuid';

// const themeSchema = new mongoose.Schema({
//   themeId: {
//     type: String,
//     required: true,
//     unique: true,
//     default: () => uuidv4()
//   },
//   name: { type: String, required: true },
//   description: { type: String },
//   previewImage: { type: String },
//   thumbnail: { type: String },
//   createdBy: { type: String },
//   createdByUsername: { type: String },
//   type: { type: String, enum: ['prebuilt', 'custom'], default: 'prebuilt' },
//   visibility: { type: String, enum: ['private', 'public'], default: 'public' },
//   tags: [String],
//   category: {
//     type: String,
//     enum: ['all', 'developer', 'designer', 'photographer', 'freelancer', 'agency', 'writer', 'minimal', 'bold'],
//     default: 'all'
//   },
//   usedByCount: { type: Number, default: 0 },
//   likes: { type: Number, default: 0 },
//   featured: { type: Boolean, default: false },

//   design: {
//     palette: {
//       mode: { type: String, enum: ['light', 'dark', 'auto'], default: 'light' },
//       colors: {
//         primary: { type: String, default: '#6366f1' },
//         secondary: { type: String, default: '#8b5cf6' },
//         accent: { type: String, default: '#ec4899' },
//         neutral: {
//           50: { type: String, default: '#f9fafb' },
//           100: { type: String, default: '#f3f4f6' },
//           200: { type: String, default: '#e5e7eb' },
//           300: { type: String, default: '#d1d5db' },
//           400: { type: String, default: '#9ca3af' },
//           500: { type: String, default: '#6b7280' },
//           600: { type: String, default: '#4b5563' },
//           700: { type: String, default: '#374151' },
//           800: { type: String, default: '#1f2937' },
//           900: { type: String, default: '#111827' }
//         },
//         text: {
//           primary: { type: String, default: '#111827' },
//           secondary: { type: String, default: '#6b7280' },
//           muted: { type: String, default: '#9ca3af' },
//           onPrimary: { type: String, default: '#ffffff' }
//         },
//         background: {
//           default: { type: String, default: '#ffffff' },
//           paper: { type: String, default: '#f9fafb' }
//         }
//       }
//     },

//     typography: {
//       fontFamily: {
//         heading: { type: String, default: 'Inter, system-ui, sans-serif' },
//         body: { type: String, default: 'Inter, system-ui, sans-serif' }
//       },
//       fontSizes: {
//         xs: { type: String, default: '0.75rem' },
//         sm: { type: String, default: '0.875rem' },
//         base: { type: String, default: '1rem' },
//         lg: { type: String, default: '1.125rem' },
//         xl: { type: String, default: '1.25rem' },
//         '2xl': { type: String, default: '1.5rem' },
//         '3xl': { type: String, default: '1.875rem' },
//         '4xl': { type: String, default: '2.25rem' },
//         '5xl': { type: String, default: '3rem' },
//         '6xl': { type: String, default: '3.75rem' },
//         '7xl': { type: String, default: '4.5rem' },
//         '8xl': { type: String, default: '6rem' }
//       }
//     },

//     background: {
//       type: { type: String, enum: ['solid', 'gradient', 'image'], default: 'solid' },
//       solid: { type: String },
//       gradient: {
//         colors: [{ type: String }],
//         direction: { type: String, default: 'to bottom right' }
//       },
//       image: {
//         url: { type: String },
//         overlayOpacity: { type: Number, default: 0.3 }
//       }
//     },

//     effects: {
//       borderRadius: {
//         sm: { type: String, default: '0.375rem' },
//         md: { type: String, default: '0.5rem' },
//         lg: { type: String, default: '0.75rem' },
//         xl: { type: String, default: '1rem' },
//         full: { type: String, default: '9999px' }
//       },
//       shadows: {
//         md: { type: String, default: '0 4px 6px -1px rgb(0 0 0 / 0.1)' },
//         lg: { type: String, default: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }
//       }
//     },

//     spacing: {
//       sectionVertical: { type: String, default: '6rem' }
//     },

//     customCSS: { type: String }
//   },

//   layoutConfig: {
//     hero: { type: String, enum: ['fullscreen', 'split', 'centered', 'minimal'], default: 'fullscreen' },
//     projects: { type: String, enum: ['grid', 'masonry', 'carousel', 'horizontal'], default: 'grid' },
//     skills: { type: String, enum: ['bars', 'circles', 'grid'], default: 'bars' },
//     experience: { type: String, enum: ['timeline', 'cards', 'list'], default: 'cards' },
//     contact: {
//       enabled: { type: Boolean, default: true }
//     },
//     navbar: {
//       enabled: { type: Boolean, default: true }
//     },
//     footer: {
//       enabled: { type: Boolean, default: true }
//     },
//     defaultSectionsOrder: {
//       type: [String],
//       default: [
//         'hero',
//         'about',
//         'skills',
//         'projects',
//         'experience',
//         'education',
//         'services',
//         'testimonials',
//         'contact'
//       ]
//     }
//   }
// }, { timestamps: true });

// // Indexes
// themeSchema.index({ type: 1, visibility: 1 });
// themeSchema.index({ category: 1 });
// themeSchema.index({ tags: 1 });

// export default mongoose.model('Theme', themeSchema);




import mongoose from 'mongoose';
import { v4 as uuidv4 } from 'uuid';

const themeSchema = new mongoose.Schema({
  themeId: {
    type: String,
    required: true,
    unique: true,
    default: () => uuidv4()
  },

  // Basic Info
  name: { type: String, required: true },
  description: { type: String },
  previewImage: { type: String },
  thumbnail: { type: String },

  // Metadata
  createdBy: { type: String }, // user_id for custom themes
  createdByUsername: { type: String },
  type: { type: String, enum: ['prebuilt', 'custom'], default: 'prebuilt' },
  visibility: { type: String, enum: ['private', 'public'], default: 'public' },
  tags: [String],
  category: {
    type: String,
    enum: ['all', 'developer', 'designer', 'photographer', 'freelancer', 'agency', 'writer', 'minimal', 'bold'],
    default: 'all'
  },

  // Stats
  usedByCount: { type: Number, default: 0 },
  likes: { type: Number, default: 0 },
  featured: { type: Boolean, default: false },

  // DESIGN SYSTEM
  design: {
    palette: {
      mode: { type: String, enum: ['light', 'dark', 'auto'], default: 'light' },
      colors: {
        primary: { type: String, default: '#6366f1' },
        secondary: { type: String, default: '#8b5cf6' },
        accent: { type: String, default: '#ec4899' },
        neutral: {
          50: { type: String, default: '#f9fafb' },
          100: { type: String, default: '#f3f4f6' },
          200: { type: String, default: '#e5e7eb' },
          300: { type: String, default: '#d1d5db' },
          400: { type: String, default: '#9ca3af' },
          500: { type: String, default: '#6b7280' },
          600: { type: String, default: '#4b5563' },
          700: { type: String, default: '#374151' },
          800: { type: String, default: '#1f2937' },
          900: { type: String, default: '#111827' }
        },
        text: {
          primary: { type: String, default: '#111827' },
          secondary: { type: String, default: '#6b7280' },
          muted: { type: String, default: '#9ca3af' },
          onPrimary: { type: String, default: '#ffffff' }
        },
        background: {
          default: { type: String, default: '#ffffff' },
          paper: { type: String, default: '#f9fafb' }
        }
      }
    },

    typography: {
      fontFamily: {
        heading: { type: String, default: 'Inter, system-ui, sans-serif' },
        body: { type: String, default: 'Inter, system-ui, sans-serif' }
      },
      fontSizes: {
        xs: { type: String, default: '0.75rem' },
        sm: { type: String, default: '0.875rem' },
        base: { type: String, default: '1rem' },
        lg: { type: String, default: '1.125rem' },
        xl: { type: String, default: '1.25rem' },
        '2xl': { type: String, default: '1.5rem' },
        '3xl': { type: String, default: '1.875rem' },
        '4xl': { type: String, default: '2.25rem' },
        '5xl': { type: String, default: '3rem' },
        '6xl': { type: String, default: '3.75rem' },
        '7xl': { type: String, default: '4.5rem' },
        '8xl': { type: String, default: '6rem' }
      }
    },

    background: {
      type: { type: String, enum: ['solid', 'gradient', 'image'], default: 'solid' },
      solid: { type: String },
      gradient: {
        colors: [{ type: String }],
        direction: { type: String, default: 'to bottom right' }
      },
      image: {
        url: { type: String },
        overlayOpacity: { type: Number, min: 0, max: 1, default: 0.3 }
      }
    },

    effects: {
      borderRadius: {
        sm: { type: String, default: '0.375rem' },
        md: { type: String, default: '0.5rem' },
        lg: { type: String, default: '0.75rem' },
        xl: { type: String, default: '1rem' },
        full: { type: String, default: '9999px' }
      },
      shadows: {
        md: { type: String, default: '0 4px 6px -1px rgb(0 0 0 / 0.1)' },
        lg: { type: String, default: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }
      }
    },

    spacing: {
      sectionVertical: { type: String, default: '6rem' }
    },

    customCSS: { type: String }
  },

  // LAYOUT CONFIG
  layoutConfig: {
    hero: { type: String, enum: ['fullscreen', 'split', 'centered', 'minimal'], default: 'fullscreen' },
    projects: { type: String, enum: ['grid', 'masonry', 'carousel', 'horizontal'], default: 'grid' },
    skills: { type: String, enum: ['bars', 'circles', 'grid'], default: 'bars' },
    experience: { type: String, enum: ['timeline', 'cards', 'list'], default: 'cards' },
    contact: { enabled: { type: Boolean, default: true } },
    navbar: { enabled: { type: Boolean, default: true } },
    footer: { enabled: { type: Boolean, default: true } },
    defaultSectionsOrder: {
      type: [String],
      default: [
        'hero',
        'about',
        'skills',
        'projects',
        'experience',
        'education',
        'services',
        'testimonials',
        'contact'
      ]
    }
  }
}, { timestamps: true });

// Performance Indexes
themeSchema.index({ type: 1, visibility: 1 });
themeSchema.index({ category: 1 });
themeSchema.index({ tags: 1 });
themeSchema.index({ themeId: 1 });

export default mongoose.model('Theme', themeSchema);