 
import mongoose from 'mongoose';
import { v4 as uuidv4 } from 'uuid';

const userSchema = new mongoose.Schema({
  user_id: { type: String, default: uuidv4, unique: true, required: true },
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  username: { type: String, required: true, unique: true, lowercase: true },
  role: { type: String, enum: ['user', 'superAdmin', 'systemAdmin'], default: 'user' },
  profession: {
    type: String,
    enum: ['developer','designer','freelancer','photographer','writer','marketer','student','teacher','other'],
    default: 'other'
  },
  avatar: { type: String, default: '' }
}, { timestamps: true });

export default mongoose.model('User', userSchema);