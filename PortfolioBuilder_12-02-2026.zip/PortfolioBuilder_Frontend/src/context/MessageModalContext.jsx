
import React, { createContext, useContext, useState } from 'react';
import { MessageModal } from '../components/common/MessageModal';


const MessageModalContext = createContext(undefined);

export const MessageModalProvider = ({ children }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [modalProps, setModalProps] = useState({
    message: '',
  });

  const showMessage = (options = {}) => {
    setModalProps({
      type: options.type || 'info',
      title: options.title || '',
      message: options.message || '',
      primaryButtonText: options.primaryButtonText,
      onPrimaryPress: options.onPrimaryPress,
      secondaryButtonText: options.secondaryButtonText,
      onSecondaryPress: options.onSecondaryPress,
      icon: options.icon,
      customColor: options.customColor,     
      autoCloseMs: options.autoCloseMs,
    });
    setIsOpen(true);
  };

  const hideMessage = () => setIsOpen(false);

  return (
    <MessageModalContext.Provider value={{ showMessage, hideMessage }}>
      {children}

      <MessageModal
        visible={isOpen}
        type={modalProps.type}
        title={modalProps.title}
        message={modalProps.message}
        primaryButtonText={modalProps.primaryButtonText}
        onPrimaryPress={modalProps.onPrimaryPress}
        secondaryButtonText={modalProps.secondaryButtonText}
        onSecondaryPress={modalProps.onSecondaryPress}
        icon={modalProps.icon}
        customColor={modalProps.customColor}
        autoCloseMs={modalProps.autoCloseMs}
        onClose={hideMessage}
      />
    </MessageModalContext.Provider>
  );
};

export const useMessageModal = () => {
  const context = useContext(MessageModalContext);
  if (!context) {
    throw new Error('useMessageModal must be used within MessageModalProvider');
  }
  return context;
};