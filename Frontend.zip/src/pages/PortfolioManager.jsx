


import { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import portfolioService from '../services/portfolioService';
import { Link } from 'react-router-dom';
import {
  FiEye,
  FiEyeOff,
  FiEdit3,
  FiGlobe,
  FiLock,
  FiExternalLink,
  FiCopy,
  FiCheck,
  FiSearch,
  FiRefreshCw,
  FiSettings,
  FiMonitor,
  FiTablet,
  FiSmartphone,
  FiShare2,
} from 'react-icons/fi';

export default function PortfolioManager() {
  const { portfolio, refreshPortfolio, user } = useAuth();
  const [isPublic, setIsPublic] = useState(true);
  const [saving, setSaving] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [copied, setCopied] = useState(false);
  const [viewMode, setViewMode] = useState('desktop');
  const iframeRef = useRef(null);

  useEffect(() => {
    if (portfolio) setIsPublic(portfolio.settings?.isPublic ?? true);
  }, [portfolio]);

  const refreshPreview = () => {
    if (iframeRef.current) {
      iframeRef.current.src = iframeRef.current.src;
    }
  };

  const togglePublic = async () => {
    setSaving(true);
    try {
      await portfolioService.setPublic(!isPublic);
      await refreshPortfolio();
      setIsPublic(!isPublic);
      refreshPreview();
    } catch (err) {
      alert('Failed to update visibility');
    } finally {
      setSaving(false);
    }
  };

  const toggleSection = async (key) => {
    const enabled = portfolio.sections?.[key]?.enabled !== false;
    await portfolioService.toggleSection(key, !enabled);
    await refreshPortfolio();
    refreshPreview();
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(liveUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const sharePortfolio = () => {
    if (navigator.share) {
      navigator.share({
        title: `${user.username}'s Portfolio`,
        url: liveUrl,
      });
    } else {
      copyToClipboard();
      alert('Link copied to clipboard!');
    }
  };

  if (!portfolio || !user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-lg">Loading...</div>
      </div>
    );
  }

  const liveUrl = `${window.location.origin}/${user.username}`;

  const filteredSections = Object.keys(portfolio.sections || {}).filter((key) =>
    key.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="h-screen flex flex-col bg-white">
      {/* Top Navigation Bar - Now with View Live & Share */}
      <nav className="h-16 border-b border-gray-200 flex items-center justify-between px-6 bg-white z-50 flex-shrink-0">
        <h1 className="text-xl font-bold text-gray-900">Portfolio Manager</h1>

        <div className="flex items-center gap-4">
          {/* URL + Copy */}
          <div className="flex items-center gap-3 px-4 py-2 bg-gray-50 rounded-xl border border-gray-200">
            <FiGlobe className="text-gray-500" size={16} />
            <span className="text-sm font-medium text-gray-700 truncate max-w-xs">{liveUrl}</span>
            <button
              onClick={copyToClipboard}
              className="p-1.5 hover:bg-gray-200 rounded-lg transition"
            >
              {copied ? <FiCheck className="text-green-600" size={16} /> : <FiCopy className="text-gray-500" size={16} />}
            </button>
          </div>

          {/* Visibility Status */}
          <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gray-50">
            {isPublic ? (
              <>
                <FiGlobe className="text-green-600" size={18} />
                <span className="text-sm font-semibold text-green-600">Public</span>
              </>
            ) : (
              <>
                <FiLock className="text-gray-600" size={18} />
                <span className="text-sm font-semibold text-gray-600">Private</span>
              </>
            )}
          </div>

          {/* Action Buttons: View Live & Share (only if public) */}
          <a
            href={liveUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="px-5 py-2 bg-indigo-600 text-white text-sm font-medium rounded-xl hover:bg-indigo-700 transition flex items-center gap-2"
          >
            <FiExternalLink size={16} />
            View Live
          </a>

          {isPublic && (
            <button
              onClick={sharePortfolio}
              className="px-5 py-2 bg-green-600 text-white text-sm font-medium rounded-xl hover:bg-green-700 transition flex items-center gap-2"
            >
              <FiShare2 size={16} />
              Share
            </button>
          )}
        </div>
      </nav>

      {/* Main Content Area */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Sidebar - Settings */}
        <aside className="w-80 border-r border-gray-200 bg-white overflow-y-auto flex-shrink-0">
          <div className="p-6 space-y-8">
            <div className="flex items-center gap-3">
              <FiSettings size={22} className="text-gray-700" />
              <h2 className="text-lg font-semibold text-gray-900">Settings</h2>
            </div>

            {/* Visibility Control */}
            <div className="space-y-3">
              <label className="text-sm font-medium text-gray-700">Portfolio Visibility</label>
              <button
                onClick={togglePublic}
                disabled={saving}
                className={`w-full flex items-center justify-between p-5 rounded-xl border-2 transition ${
                  isPublic ? 'border-green-500 bg-green-50' : 'border-gray-300 bg-gray-50'
                }`}
              >
                <div className="flex items-center gap-4">
                  {isPublic ? (
                    <>
                      <FiGlobe className="text-green-600" size={24} />
                      <div className="text-left">
                        <div className="font-semibold text-green-700">Public</div>
                        <div className="text-xs text-green-600">Anyone can view your portfolio</div>
                      </div>
                    </>
                  ) : (
                    <>
                      <FiLock className="text-gray-600" size={24} />
                      <div className="text-left">
                        <div className="font-semibold text-gray-700">Private</div>
                        <div className="text-xs text-gray-600">Only you can access it</div>
                      </div>
                    </>
                  )}
                </div>
                <div
                  className={`relative inline-flex h-7 w-12 rounded-full transition ${
                    isPublic ? 'bg-green-500' : 'bg-gray-300'
                  }`}
                >
                  <span
                    className={`inline-block h-6 w-6 rounded-full bg-white shadow transform transition m-0.5 ${
                      isPublic ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </div>
              </button>
            </div>

            {/* Active Theme */}
            <div className="space-y-3">
              <label className="text-sm font-medium text-gray-700">Active Theme</label>
              <div className="flex items-center justify-between p-4 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl text-white">
                <span className="font-medium">
                  {portfolio.activeTheme?.name || 'Default Light'}
                </span>
                <Link
                  to="/themes"
                  className="px-4 py-1.5 bg-white text-indigo-600 text-sm font-medium rounded-lg hover:bg-gray-100 transition"
                >
                  Change
                </Link>
              </div>
            </div>

            {/* Sections Management */}
            <div className="space-y-4">
              <label className="text-sm font-medium text-gray-700">Manage Sections</label>
              <div className="relative">
                <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                <input
                  type="text"
                  placeholder="Search sections..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 text-sm border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="space-y-3">
                {filteredSections.map((key) => {
                  const section = portfolio.sections[key];
                  const enabled = section?.enabled !== false;
                  const title = key.charAt(0).toUpperCase() + key.slice(1);

                  return (
                    <div
                      key={key}
                      className={`flex items-center justify-between p-4 rounded-xl border transition ${
                        enabled ? 'border-green-300 bg-green-50' : 'border-gray-200 bg-gray-50'
                      }`}
                    >
                      <span className="font-medium text-gray-900">{title}</span>
                      <div className="flex items-center gap-3">
                        <Link
                          to={`/update-portfolio?tab=${key}`}
                          className="p-2 text-indigo-600 hover:bg-indigo-100 rounded-lg transition"
                        >
                          <FiEdit3 size={18} />
                        </Link>
                        <button
                          onClick={() => toggleSection(key)}
                          className={`p-2 rounded-lg transition ${
                            enabled
                              ? 'text-green-600 hover:bg-green-100'
                              : 'text-gray-400 hover:bg-gray-200'
                          }`}
                        >
                          {enabled ? <FiEye size={18} /> : <FiEyeOff size={18} />}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </aside>

        {/* Right Side - Preview Area */}
        <main className="flex-1 bg-gradient-to-br from-gray-50 to-gray-100 flex flex-col overflow-hidden">
          {/* Device Switcher + Refresh Icon Only */}
          <div className="px-8 pt-6 pb-4 flex items-center justify-center">
            <div className="flex items-center gap-3 bg-white rounded-xl shadow-md p-2">
              <button
                onClick={() => setViewMode('desktop')}
                className={`px-5 py-3 rounded-lg flex items-center gap-3 transition font-medium ${
                  viewMode === 'desktop'
                    ? 'bg-indigo-600 text-white'
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <FiMonitor size={20} />
                Desktop
              </button>
              <button
                onClick={() => setViewMode('tablet')}
                className={`px-5 py-3 rounded-lg flex items-center gap-3 transition font-medium ${
                  viewMode === 'tablet'
                    ? 'bg-indigo-600 text-white'
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <FiTablet size={20} />
                Tablet
              </button>
              <button
                onClick={() => setViewMode('mobile')}
                className={`px-5 py-3 rounded-lg flex items-center gap-3 transition font-medium ${
                  viewMode === 'mobile'
                    ? 'bg-indigo-600 text-white'
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <FiSmartphone size={20} />
                Mobile
              </button>

              {/* Refresh Icon Inside Toolbar */}
              <div className="ml-4 pl-4 border-l border-gray-300">
                <button
                  onClick={refreshPreview}
                  className="p-3 text-gray-600 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition"
                  title="Refresh Preview"
                >
                  <FiRefreshCw size={20} />
                </button>
              </div>
            </div>
          </div>

          {/* Preview Frame - Reduced Device Sizes */}
          <div className="flex-1 flex items-center justify-center px-8 pb-8">
            <div className="w-full h-full flex items-center justify-center">
              {/* Desktop View - Smaller Monitor */}
              {viewMode === 'desktop' && (
                <div
                  className="bg-gray-900 rounded-2xl shadow-2xl p-3 border-8 border-gray-800 relative overflow-hidden"
                  style={{ width: '1000px', height: '620px', maxWidth: '95%', maxHeight: '85%' }}
                >
                  <div className="absolute bottom-1 left-1/2 transform -translate-x-1/2 w-40 h-4 bg-gray-700 rounded-t-lg"></div>
                  <iframe
                    ref={iframeRef}
                    src={liveUrl}
                    title="Desktop Preview"
                    className="w-full h-full bg-white rounded"
                    sandbox="allow-scripts allow-same-origin allow-modals allow-popups allow-forms"
                  />
                </div>
              )}

              {/* Tablet View - Reduced Size */}
              {viewMode === 'tablet' && (
                <div
                  className="bg-gray-900 rounded-3xl shadow-2xl overflow-hidden border-8 border-gray-800 relative"
                  style={{ width: '640px', height: '860px', maxHeight: '90vh' }}
                >
                  <div className="absolute top-5 left-1/2 transform -translate-x-1/2 w-28 h-2 bg-gray-700 rounded-full z-10"></div>
                  <iframe
                    ref={iframeRef}
                    src={liveUrl}
                    title="Tablet Preview"
                    className="w-full h-full bg-white"
                    sandbox="allow-scripts allow-same-origin allow-modals allow-popups allow-forms"
                  />
                </div>
              )}

              {/* Mobile View - Reduced Size */}
              {viewMode === 'mobile' && (
                <div
                  className="bg-gray-900 rounded-3xl shadow-2xl overflow-hidden border-8 border-gray-800 relative"
                  style={{ width: '340px', height: '720px', maxHeight: '90vh' }}
                >
                  <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-36 h-7 bg-gray-900 rounded-b-3xl z-10 flex items-center justify-center">
                    <div className="w-16 h-1 bg-gray-700 rounded-full"></div>
                  </div>
                  <iframe
                    ref={iframeRef}
                    src={liveUrl}
                    title="Mobile Preview"
                    className="w-full h-full bg-white"
                    sandbox="allow-scripts allow-same-origin allow-modals allow-popups allow-forms"
                  />
                </div>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}