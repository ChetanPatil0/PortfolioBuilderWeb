import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../../services/api';
import LoadingSpinner from '../../components/common/LoadingSpinner';


export default function AdminThemeManagement() {
  const [themes, setThemes] = useState([]);
  const [loading, setLoading] = useState(true);

  const navigate = useNavigate();

  useEffect(() => {
    const loadThemes = async () => {
      try {
        const res = await api.get('/admin/themes/prebuilt');
        setThemes(res.data?.themes || []);
      } catch (err) {
        alert('Failed to load themes');
      } finally {
        setLoading(false);
      }
    };

    loadThemes();
  }, []);

  const handleDelete = async (id) => {
    if (!confirm('Delete this theme?')) return;

    try {
      await api.delete(`/admin/themes/prebuilt/${id}`);
      setThemes(prev => prev.filter(theme => theme._id !== id));
    } catch (err) {
      alert('Failed to delete theme');
    }
  };

  // 🔄 Loader state
  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <LoadingSpinner />
      </div>
    );
  }

  return (
    <div className="p-6 lg:p-10">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-4xl font-bold">Theme Management</h1>

        <button
          onClick={() => navigate('/admin/themes/add')}
          className="px-8 py-4 bg-black text-white font-bold rounded-xl hover:bg-gray-800 transition"
        >
          Add New Theme
        </button>
      </div>

      {/* 📭 Empty state */}
      {themes.length === 0 ? (
        <div className="text-center text-gray-500 text-xl py-20">
          No themes available
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {themes.map(theme => (
            <div
              key={theme._id}
              className="bg-white rounded-3xl shadow-lg overflow-hidden"
            >
              <img
                src={theme.previewImage || '/placeholder.jpg'}
                alt={theme.name}
                className="w-full h-64 object-cover"
              />

              <div className="p-6">
                <h3 className="text-2xl font-bold mb-2">{theme.name}</h3>
                <p className="text-gray-600 mb-4">
                  {theme.description || 'No description'}
                </p>

                <div className="flex justify-between items-center">
                  <p className="text-sm text-gray-500">
                    Used by {theme.usedByCount ?? 0} users
                  </p>

                  <button
                    onClick={() => handleDelete(theme._id)}
                    className="text-red-600 hover:underline font-medium"
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
