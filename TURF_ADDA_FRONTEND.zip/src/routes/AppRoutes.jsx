
import { Routes, Route, Navigate } from 'react-router-dom';
import ProtectedRoute from './ProtectedRoute';
import DashboardLayout from '../components/layout/DashboardLayout';

// Auth pages (public)
import Signup from '../pages/Signup';
import OTPVerify from '../pages/OTPVerify';
import Login from '../pages/Login';

// Player pages
import PlayerHome from '../pages/player/PlayerHome';
import FindTurfs from '../pages/player/FindTurfs';
import PlayerBookings from '../pages/player/Bookings';
import Favorites from '../pages/player/Favorites';

// Owner pages
import OwnerDashboard from '../pages/owner/OwnerDashboard';
import MyTurfs from '../pages/owner/MyTurfs';
import AddTurf from '../pages/owner/AddTurf';
import OwnerBookings from '../pages/owner/OwnerBookings';
import Revenue from '../pages/owner/Revenue';

// Shared
import Profile from '../pages/Profile';
import { Typography } from '@mui/material';
import useAuthStore from '../store/authStore';


const AppRoutes = () => {
  return (
    <Routes>
      {/* Public */}
      <Route path="/signup" element={<Signup />} />
      <Route path="/verify-otp" element={<OTPVerify />} />
      <Route path="/login" element={<Login />} />

   
      <Route path="/" element={<NavigateToRoleHome />} />

   
      <Route element={<ProtectedRoute />}>
     
        <Route
          path="/player"
          element={<DashboardLayout role="player" />}
        >
          <Route index element={<PlayerHome />} />
          <Route path="find-turfs" element={<FindTurfs />} />
          <Route path="bookings" element={<PlayerBookings />} />
          <Route path="favorites" element={<Favorites />} />
          <Route path="profile" element={<Profile />} />
        </Route>

   
        <Route
          path="/owner"
          element={<DashboardLayout role="owner" />}
        >
          <Route index element={<OwnerDashboard />} />
          <Route path="turfs" element={<MyTurfs />} />
          <Route path="turfs/add" element={<AddTurf />} />
          <Route path="bookings" element={<OwnerBookings />} />
          <Route path="revenue" element={<Revenue />} />
          <Route path="profile" element={<Profile />} />
         
        </Route>

    
        <Route path="/dashboard" element={<PlayerHome />} />
      </Route>

      <Route path="*" element={<Typography variant="h4">404 - Page Not Found</Typography>} />
    </Routes>
  );
};


const NavigateToRoleHome = () => {
  const { isAuthenticated, user } = useAuthStore();

  if (!isAuthenticated) return <Navigate to="/login" replace />;

  if (user?.role === 'owner') return <Navigate to="/owner" replace />;
  if (user?.role === 'player') return <Navigate to="/player" replace />;

  return <Navigate to="/" replace />;
};

export default AppRoutes;