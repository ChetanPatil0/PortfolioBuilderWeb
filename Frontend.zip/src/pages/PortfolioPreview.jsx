// src/components/PortfolioPreview.jsx
import React, { useEffect, useRef, useState } from 'react';

export default function PortfolioPreview({ localPortfolio, viewMode = 'desktop', setViewMode }) {
  const iframeRef = useRef(null);
  const [isLoading, setIsLoading] = useState(true);

  console.log('local portfoio data  2: ', localPortfolio);

  const getPreviewUrl = () => {
    if (!localPortfolio || Object.keys(localPortfolio).length === 0) {
      return '/preview-local';
    }

    try {
      const dataStr = encodeURIComponent(JSON.stringify(localPortfolio));
      return `/preview-local?data=${dataStr}&t=${Date.now()}`;
    } catch (err) {
      console.error('Failed to encode portfolio data:', err);
      return '/preview-local';
    }
  };

  useEffect(() => {
    if (iframeRef.current) {
      setIsLoading(true);
      iframeRef.current.src = getPreviewUrl();
    }
  }, [localPortfolio, viewMode]);

  const handleIframeLoad = () => {
    setIsLoading(false);
  };

  const getDeviceStyle = () => {
    switch (viewMode) {
      case 'desktop':
        return 'w-[1100px] h-[680px]';
      case 'tablet':
        return 'w-[768px] h-[1024px]';
      case 'mobile':
        return 'w-[380px] h-[740px]';
      default:
        return 'w-full h-full';
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-gradient-to-br from-gray-50 to-gray-100 overflow-hidden">
      {/* Device Tabs */}
      <div className="p-4 border-b bg-white flex justify-center">
        <div className="inline-flex bg-white rounded-lg shadow-sm border overflow-hidden">
          {['Desktop', 'Tablet', 'Mobile'].map(mode => (
            <button
              key={mode}
              onClick={() => setViewMode(mode.toLowerCase())}
              className={`px-6 py-2 text-sm font-medium transition ${
                viewMode === mode.toLowerCase()
                  ? 'bg-purple-600 text-white'
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              {mode}
            </button>
          ))}
        </div>
      </div>

      {/* Device Frame with vertical scroll allowed */}
      <div className="flex-1 flex items-center justify-center p-8 overflow-y-auto">
        <div
          className={`border-8 border-gray-900 rounded-3xl shadow-2xl overflow-y-auto overflow-x-hidden bg-white relative ${getDeviceStyle()}`}
          style={{ maxWidth: '100%', maxHeight: '100%' }}
        >
          {isLoading && (
            <div className="absolute inset-0 flex items-center justify-center bg-white/90 z-10">
              <div className="animate-spin rounded-full h-12 w-12 border-t-4 border-purple-600"></div>
            </div>
          )}

          <iframe
            ref={iframeRef}
            src={getPreviewUrl()}
            title="Live Local Preview"
            className="w-full h-full border-none"
            sandbox="allow-scripts allow-same-origin allow-modals allow-popups allow-forms"
            onLoad={handleIframeLoad}
          />
        </div>
      </div>
    </div>
  );
}