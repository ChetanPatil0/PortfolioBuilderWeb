import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { useNavigate, Link } from 'react-router-dom';

import {
  Box,
  Button,
  CircularProgress,
  IconButton,
  InputAdornment,
  Link as MuiLink,
  TextField,
  Typography,
  Divider,
} from '@mui/material';
import { Visibility, VisibilityOff } from '@mui/icons-material';
import { toast } from 'react-toastify';

import AuthLayout from '../components/layout/AuthLayout';
import { loginUser } from '../api/authApi';
import useAuthStore from '../store/authStore';
import GoogleLoginButton from '../components/common/GoogleLoginButton';

const Login = () => {
  const navigate = useNavigate();
  const { setAuth } = useAuthStore();

  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const onSubmit = async (data) => {
    setLoading(true);

    try {
      const res = await loginUser(data);

      // Handle both success true/false cases (most common backend behavior)
      if (res?.success === true) {
        setAuth(res.user, res.token);

        toast.success('Welcome back! You’re now logged in.', {
          position: 'top-center',
          autoClose: 2500,
          hideProgressBar: false,
        });

        setTimeout(() => {
          navigate('/', { replace: true }); // or '/dashboard' / '/player' etc.
        }, 1500);
      } else {
        // Backend returned 200 but success: false
        toast.error(res?.message || 'Login failed. Please check your credentials.', {
          position: 'top-center',
          autoClose: 4000,
        });
      }
    } catch (err) {
      // Network error / 4xx/5xx status
      console.error('Login error:', err); // ← debug log

      const errorMsg =
        err.response?.data?.message ||
        err.message ||
        'Something went wrong. Please try again later.';

      toast.error(errorMsg, {
        position: 'top-center',
        autoClose: 5000,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthLayout title="Welcome Back">
      <Box
        sx={{
          width: '100%',
          maxWidth: 420,
          mx: 'auto',
          px: { xs: 2, sm: 3 },
        }}
      >
        <Typography
          variant="body2"
          align="center"
          color="text.secondary"
          sx={{ mb: 4 }}
        >
          Sign in to continue your journey
        </Typography>

        <form onSubmit={handleSubmit(onSubmit)} noValidate>
          <Box
            sx={{
              display: 'flex',
              flexDirection: 'column',
              gap: 3,
              width: '100%',
            }}
          >
            {/* Mobile Number */}
            <TextField
              label="Mobile Number"
              fullWidth
              {...register('mobile', {
                required: 'Mobile number is required',
                pattern: {
                  value: /^[6-9][0-9]{9}$/,
                  message: 'Enter a valid 10-digit number',
                },
              })}
              error={!!errors.mobile}
              helperText={errors.mobile?.message}
              inputProps={{ maxLength: 10 }}
            />

            {/* Password */}
            <TextField
              label="Password"
              type={showPassword ? 'text' : 'password'}
              fullWidth
              {...register('password', {
                required: 'Password is required',
              })}
              error={!!errors.password}
              helperText={errors.password?.message}
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton
                      onClick={() => setShowPassword(!showPassword)}
                      edge="end"
                    >
                      {showPassword ? <VisibilityOff /> : <Visibility />}
                    </IconButton>
                  </InputAdornment>
                ),
              }}
            />

            {/* Forgot Password */}
            <MuiLink
              component={Link}
              to="/forgot-password"
              variant="body2"
              sx={{
                textAlign: 'right',
                textDecoration: 'none',
                '&:hover': { textDecoration: 'underline' },
              }}
            >
              Forgot Password?
            </MuiLink>

            {/* Login Button */}
            <Button
              type="submit"
              variant="contained"
              fullWidth
              disabled={loading}
              sx={{
                py: 1.5,
                fontWeight: 600,
                borderRadius: 2,
              }}
            >
              {loading ? (
                <CircularProgress size={26} color="inherit" />
              ) : (
                'Login'
              )}
            </Button>

            {/* Divider */}
            <Divider>OR</Divider>

            {/* Google Login */}
            <Box sx={{ width: '100%' }}>
              <GoogleLoginButton onSuccessRedirect="/" />
            </Box>

            {/* Register Link */}
            <Typography
              variant="body2"
              align="center"
              color="text.secondary"
              sx={{ mt: 2 }}
            >
              Don’t have an account?{' '}
              <MuiLink
                component={Link}
                to="/signup"
                sx={{
                  fontWeight: 600,
                  textDecoration: 'none',
                  '&:hover': { textDecoration: 'underline' },
                }}
              >
                Register
              </MuiLink>
            </Typography>
          </Box>
        </form>
      </Box>
    </AuthLayout>
  );
};

export default Login;