
// // import { Formik, Form, Field, ErrorMessage } from "formik";
// // import * as Yup from "yup";
// // import { ToastContainer, toast } from "react-toastify";
// // import "react-toastify/dist/ReactToastify.css";

// // const validationSchema = Yup.object({
// //   name: Yup.string().required("Full Name is required"),
// //   title: Yup.string().required("Professional title is required"),
// //   bio: Yup.string()
// //     .min(20, "Bio should be at least 20 characters")
// //     .required("Please write a short bio"),
// //   avatar: Yup.string().url("Must be a valid URL").optional(),
// //   bannerImage: Yup.string().url("Must be a valid URL").optional(),
// //   ctaText: Yup.string().required("CTA text is required"),
// //   ctaLink: Yup.string().url("Must be a valid URL").required("CTA link is required"),
// // });

// // export default function HeroForm({ data = {}, onNext, onBack, isLast }) {
// //   const initialValues = {
// //     name: data.hero?.name || "",
// //     title: data.hero?.title || "",
// //     bio: data.hero?.bio || "",
// //     avatar: data.hero?.avatar || "",
// //     bannerImage: data.hero?.bannerImage || "",
// //     ctaText: data.hero?.ctaText || "Hire Me",
// //     ctaLink: data.hero?.ctaLink || "",
// //   };

// //   const handleSubmit = (values, { setSubmitting }) => {
// //     setTimeout(() => {
// //       onNext({ hero: values });
// //       toast.success("Hero section saved!");
// //       setSubmitting(false);
// //     }, 600);
// //   };

// //   return (
// //     <div className="min-h-screen flex items-center justify-center bg-gray-50 ">
// //       <ToastContainer position="top-right" autoClose={3000} />

// //       <div className="bg-white rounded-3xl shadow-xl w-full max-w-4xl overflow-hidden">
// //         {/* Purple Header */}
// //         <div className="bg-gradient-to-r from-purple-600 to-purple-500 text-white font-bold py-4 text-center text-xl rounded-t-3xl">
// //           Tell us about yourself
// //         </div>

// //         <div className="p-4 lg:p-6">
// //           <Formik
// //             initialValues={initialValues}
// //             validationSchema={validationSchema}
// //             onSubmit={handleSubmit}
// //           >
// //             {({ isSubmitting }) => (
// //               <Form className="space-y-7">

// //                 {/* Row 1: Full Name + Title */}
// //                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
// //                   <div>
// //                     <label className="block text-gray-700 text-sm font-medium mb-2">
// //                       Full Name <span className="text-red-500">*</span>
// //                     </label>
// //                     <Field
// //                       name="name"
// //                       type="text"
// //                       placeholder="John Doe"
// //                       className="w-full px-4 py-3 text-base border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500 transition"
// //                     />
// //                     <ErrorMessage name="name" component="div" className="text-red-500 text-xs mt-1" />
// //                   </div>

// //                   <div>
// //                     <label className="block text-gray-700 text-sm font-medium mb-2">
// //                       Professional Title <span className="text-red-500">*</span>
// //                     </label>
// //                     <Field
// //                       name="title"
// //                       type="text"
// //                       placeholder="Full Stack Developer"
// //                       className="w-full px-4 py-3 text-base border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500 transition"
// //                     />
// //                     <ErrorMessage name="title" component="div" className="text-red-500 text-xs mt-1" />
// //                   </div>
// //                 </div>

// //                 {/* Row 2: Bio (full width) */}
// //                 <div>
// //                   <label className="block text-gray-700 text-sm font-medium mb-2">
// //                     Short Bio <span className="text-red-500">*</span>
// //                   </label>
// //                   <Field
// //                     as="textarea"
// //                     rows={4}
// //                     name="bio"
// //                     placeholder="I'm a passionate developer who loves crafting beautiful, functional web experiences with React, Node.js, and modern design..."
// //                     className="w-full px-4 py-3 text-base border border-gray-300 rounded-lg resize-none focus:outline-none focus:border-purple-500 transition"
// //                   />
// //                   <ErrorMessage name="bio" component="div" className="text-red-500 text-xs mt-1" />
// //                 </div>

// //                 {/* Row 3: Avatar + Banner Image */}
// //                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
// //                   <div>
// //                     <label className="block text-gray-700 text-sm font-medium mb-2">
// //                       Avatar Image URL <span className="text-gray-400">(optional)</span>
// //                     </label>
// //                     <Field
// //                       name="avatar"
// //                       type="url"
// //                       placeholder="https://example.com/avatar.jpg"
// //                       className="w-full px-4 py-3 text-base border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500 transition"
// //                     />
// //                     <ErrorMessage name="avatar" component="div" className="text-red-500 text-xs mt-1" />
// //                   </div>

// //                   <div>
// //                     <label className="block text-gray-700 text-sm font-medium mb-2">
// //                       Banner Image URL <span className="text-gray-400">(optional)</span>
// //                     </label>
// //                     <Field
// //                       name="bannerImage"
// //                       type="url"
// //                       placeholder="https://example.com/banner.jpg"
// //                       className="w-full px-4 py-3 text-base border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500 transition"
// //                     />
// //                     <ErrorMessage name="bannerImage" component="div" className="text-red-500 text-xs mt-1" />
// //                   </div>
// //                 </div>

// //                 {/* Row 4: CTA Text + Link */}
// //                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
// //                   <div>
// //                     <label className="block text-gray-700 text-sm font-medium mb-2">
// //                       CTA Button Text <span className="text-red-500">*</span>
// //                     </label>
// //                     <Field
// //                       name="ctaText"
// //                       type="text"
// //                       placeholder="Hire Me"
// //                       className="w-full px-4 py-3 text-base border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500 transition"
// //                     />
// //                     <ErrorMessage name="ctaText" component="div" className="text-red-500 text-xs mt-1" />
// //                   </div>

// //                   <div>
// //                     <label className="block text-gray-700 text-sm font-medium mb-2">
// //                       CTA Link <span className="text-red-500">*</span>
// //                     </label>
// //                     <Field
// //                       name="ctaLink"
// //                       type="url"
// //                       placeholder="https://linkedin.com/in/johndoe"
// //                       className="w-full px-4 py-3 text-base border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500 transition"
// //                     />
// //                     <ErrorMessage name="ctaLink" component="div" className="text-red-500 text-xs mt-1" />
// //                   </div>
// //                 </div>

// //                 {/* Navigation Buttons */}
// //                 <div className="flex justify-between items-center pt-8 border-t border-gray-200 mt-10">
// //                   <button
// //                     type="button"
// //                     onClick={onBack}
// //                     className="px-8 py-3 text-base font-medium text-gray-700 border-2 border-gray-300 rounded-lg hover:bg-gray-50 transition"
// //                   >
// //                     ← Back
// //                   </button>

// //                   <button
// //                     type="submit"
// //                     disabled={isSubmitting}
// //                     className="px-12 py-3 bg-gradient-to-r from-purple-600 to-purple-500 text-white font-bold text-base rounded-lg hover:from-purple-700 hover:to-purple-600 transition disabled:opacity-70 shadow-lg"
// //                   >
// //                     {isSubmitting ? "Saving..." : isLast ? "Finish Setup" : "Next →"}
// //                   </button>
// //                 </div>
// //               </Form>
// //             )}
// //           </Formik>
// //         </div>
// //       </div>
// //     </div>
// //   );
// // }



// import { Formik, Form, Field, ErrorMessage } from "formik";
// import * as Yup from "yup";
// import { ToastContainer, toast } from "react-toastify";
// import "react-toastify/dist/ReactToastify.css";
// import { portfolioService } from "../../../services/portfolioService";


// const validationSchema = Yup.object({
//   name: Yup.string().required("Full Name is required"),
//   title: Yup.string().required("Professional title is required"),
//   bio: Yup.string()
//     .min(20, "Bio should be at least 20 characters")
//     .required("Please write a short bio"),
//   avatar: Yup.string().url("Must be a valid URL").optional(),
//   bannerImage: Yup.string().url("Must be a valid URL").optional(),
//   ctaText: Yup.string().required("CTA text is required"),
//   ctaLink: Yup.string().url("Must be a valid URL").required("CTA link is required"),
// });

// export default function HeroForm({ data = {}, onNext, onBack, isLast }) {

//   const initialValues = {
//     name: data.hero?.name || "",
//     title: data.hero?.title || "",
//     bio: data.hero?.bio || "",
//     avatar: data.hero?.avatar || "",
//     bannerImage: data.hero?.bannerImage || "",
//     ctaText: data.hero?.ctaText || "Hire Me",
//     ctaLink: data.hero?.ctaLink || "",
//   };

//   const handleSubmit = async (values, { setSubmitting }) => {
//     try {
//      const response = await portfolioService.saveSection("hero", values);
//         console.log('Hero section saved:', response);

//       toast.success("Hero section saved!");
//       onNext?.(); 
//     } catch (err) {
//       toast.error("Failed to save hero section");
//       console.error(err);
//     } finally {
//       setSubmitting(false);
//     }
//   };

//   return (
//     <div className="min-h-screen flex items-center justify-center bg-gray-50 ">
//       <ToastContainer position="top-right" autoClose={3000} />

//       <div className="bg-white rounded-3xl shadow-xl w-full max-w-4xl overflow-hidden">

//         {/* Header */}
//         <div className="bg-gradient-to-r from-purple-600 to-purple-500 text-white font-bold py-4 text-center text-xl rounded-t-3xl">
//           Tell us about yourself
//         </div>

//         <div className="p-4 lg:p-6">

//           <Formik
//             initialValues={initialValues}
//             validationSchema={validationSchema}
//             onSubmit={handleSubmit}
//           >

//             {({ isSubmitting }) => (
//               <Form className="space-y-7">

//                 {/* Name + Title */}
//                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
//                   <div>
//                     <label className="block text-gray-700 text-sm font-medium mb-2">
//                       Full Name <span className="text-red-500">*</span>
//                     </label>
//                     <Field
//                       name="name"
//                       type="text"
//                       placeholder="John Doe"
//                       className="w-full px-4 py-3 text-base border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500 transition"
//                     />
//                     <ErrorMessage name="name" component="div" className="text-red-500 text-xs mt-1" />
//                   </div>

//                   <div>
//                     <label className="block text-gray-700 text-sm font-medium mb-2">
//                       Professional Title <span className="text-red-500">*</span>
//                     </label>
//                     <Field
//                       name="title"
//                       type="text"
//                       placeholder="Full Stack Developer"
//                       className="w-full px-4 py-3 text-base border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500 transition"
//                     />
//                     <ErrorMessage name="title" component="div" className="text-red-500 text-xs mt-1" />
//                   </div>
//                 </div>

//                 {/* Bio */}
//                 <div>
//                   <label className="block text-gray-700 text-sm font-medium mb-2">
//                     Short Bio <span className="text-red-500">*</span>
//                   </label>
//                   <Field
//                     as="textarea"
//                     rows={4}
//                     name="bio"
//                     placeholder="I'm a passionate developer who loves crafting beautiful web experiences..."
//                     className="w-full px-4 py-3 text-base border border-gray-300 rounded-lg resize-none focus:outline-none focus:border-purple-500 transition"
//                   />
//                   <ErrorMessage name="bio" component="div" className="text-red-500 text-xs mt-1" />
//                 </div>

//                 {/* Avatar + Banner */}
//                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
//                   <div>
//                     <label className="block text-gray-700 text-sm font-medium mb-2">
//                       Avatar Image URL <span className="text-gray-400">(optional)</span>
//                     </label>
//                     <Field
//                       name="avatar"
//                       type="url"
//                       placeholder="https://example.com/avatar.jpg"
//                       className="w-full px-4 py-3 text-base border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500 transition"
//                     />
//                     <ErrorMessage name="avatar" component="div" className="text-red-500 text-xs mt-1" />
//                   </div>

//                   <div>
//                     <label className="block text-gray-700 text-sm font-medium mb-2">
//                       Banner Image URL <span className="text-gray-400">(optional)</span>
//                     </label>
//                     <Field
//                       name="bannerImage"
//                       type="url"
//                       placeholder="https://example.com/banner.jpg"
//                       className="w-full px-4 py-3 text-base border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500 transition"
//                     />
//                     <ErrorMessage name="bannerImage" component="div" className="text-red-500 text-xs mt-1" />
//                   </div>
//                 </div>

//                 {/* CTA */}
//                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
//                   <div>
//                     <label className="block text-gray-700 text-sm font-medium mb-2">
//                       CTA Button Text <span className="text-red-500">*</span>
//                     </label>
//                     <Field
//                       name="ctaText"
//                       type="text"
//                       placeholder="Hire Me"
//                       className="w-full px-4 py-3 text-base border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500 transition"
//                     />
//                     <ErrorMessage name="ctaText" component="div" className="text-red-500 text-xs mt-1" />
//                   </div>

//                   <div>
//                     <label className="block text-gray-700 text-sm font-medium mb-2">
//                       CTA Link <span className="text-red-500">*</span>
//                     </label>
//                     <Field
//                       name="ctaLink"
//                       type="url"
//                       placeholder="https://linkedin.com/in/johndoe"
//                       className="w-full px-4 py-3 text-base border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500 transition"
//                     />
//                     <ErrorMessage name="ctaLink" component="div" className="text-red-500 text-xs mt-1" />
//                   </div>
//                 </div>

//                 {/* Buttons */}
//                 <div className="flex justify-between items-center pt-8 border-t border-gray-200 mt-10">
//                   <button
//                     type="button"
//                     onClick={onBack}
//                     className="px-8 py-3 text-base font-medium text-gray-700 border-2 border-gray-300 rounded-lg hover:bg-gray-50 transition"
//                   >
//                     ← Back
//                   </button>

//                   <button
//                     type="submit"
//                     disabled={isSubmitting}
//                     className="px-12 py-3 bg-gradient-to-r from-purple-600 to-purple-500 text-white font-bold text-base rounded-lg hover:from-purple-700 hover:to-purple-600 transition disabled:opacity-70 shadow-lg"
//                   >
//                     {isSubmitting ? "Saving..." : isLast ? "Finish Setup" : "Next →"}
//                   </button>
//                 </div>

//               </Form>
//             )}

//           </Formik>
//         </div>
//       </div>
//     </div>
//   );
// }



import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import portfolioService from "../../../services/portfolioService";

const validationSchema = Yup.object({
  name: Yup.string().required("Full Name is required"),
  title: Yup.string().required("Professional title is required"),
  bio: Yup.string().min(20, "Bio should be at least 20 characters").required("Bio is required"),
  avatar: Yup.string().url().optional(),
  bannerImage: Yup.string().url().optional(),
  ctaText: Yup.string().required("CTA text is required"),
  ctaLink: Yup.string().url().required("CTA link is required"),
});

export default function HeroForm({ data = {}, onNext, onBack, isLast }) {
  const initialValues = {
    name: data.hero?.data?.name || "",
    title: data.hero?.data?.title || "",
    bio: data.hero?.data?.bio || "",
    avatar: data.hero?.data?.avatar || "",
    bannerImage: data.hero?.data?.bannerImage || "",
    ctaText: data.hero?.data?.ctaText || "Hire Me",
    ctaLink: data.hero?.data?.ctaLink || "",
  };

  const handleSubmit = async (values, { setSubmitting }) => {
    try {
      await portfolioService.updatePortfolio({
        "sections.hero.data": values
      });
      toast.success("Hero section saved!");
      onNext?.();
    } catch (err) {
      toast.error("Failed to save hero section");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <ToastContainer position="top-right" autoClose={3000} />

      <div className="bg-white rounded-3xl shadow-xl w-full max-w-4xl overflow-hidden">
        <div className="bg-gradient-to-r from-purple-600 to-purple-500 text-white font-bold py-4 text-center text-xl rounded-t-3xl">
          Tell us about yourself
        </div>

        <div className="p-6 lg:p-10">
          <Formik
            initialValues={initialValues}
            validationSchema={validationSchema}
            onSubmit={handleSubmit}
          >
            {({ isSubmitting }) => (
              <Form className="space-y-8">
                {/* Name + Title */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-gray-700 text-sm font-medium mb-2">
                      Full Name <span className="text-red-500">*</span>
                    </label>
                    <Field name="name" type="text" placeholder="John Doe" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500" />
                    <ErrorMessage name="name" component="div" className="text-red-500 text-xs mt-1" />
                  </div>

                  <div>
                    <label className="block text-gray-700 text-sm font-medium mb-2">
                      Professional Title <span className="text-red-500">*</span>
                    </label>
                    <Field name="title" type="text" placeholder="Full Stack Developer" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500" />
                    <ErrorMessage name="title" component="div" className="text-red-500 text-xs mt-1" />
                  </div>
                </div>

                {/* Bio */}
                <div>
                  <label className="block text-gray-700 text-sm font-medium mb-2">
                    Short Bio <span className="text-red-500">*</span>
                  </label>
                  <Field as="textarea" rows={4} name="bio" placeholder="I'm a passionate developer..." className="w-full px-4 py-3 border border-gray-300 rounded-lg resize-none focus:outline-none focus:border-purple-500" />
                  <ErrorMessage name="bio" component="div" className="text-red-500 text-xs mt-1" />
                </div>

                {/* Avatar + Banner */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-gray-700 text-sm font-medium mb-2">
                      Avatar Image URL (optional)
                    </label>
                    <Field name="avatar" type="url" placeholder="https://..." className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500" />
                  </div>

                  <div>
                    <label className="block text-gray-700 text-sm font-medium mb-2">
                      Banner Image URL (optional)
                    </label>
                    <Field name="bannerImage" type="url" placeholder="https://..." className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500" />
                  </div>
                </div>

                {/* CTA */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-gray-700 text-sm font-medium mb-2">
                      CTA Button Text <span className="text-red-500">*</span>
                    </label>
                    <Field name="ctaText" type="text" placeholder="Hire Me" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500" />
                  </div>

                  <div>
                    <label className="block text-gray-700 text-sm font-medium mb-2">
                      CTA Link <span className="text-red-500">*</span>
                    </label>
                    <Field name="ctaLink" type="url" placeholder="https://linkedin.com" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500" />
                  </div>
                </div>

                <div className="flex justify-between pt-8 border-t border-gray-200">
                  <button type="button" onClick={onBack} className="px-8 py-3 text-base font-medium text-gray-700 border-2 border-gray-300 rounded-lg hover:bg-gray-50 transition">
                    ← Back
                  </button>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-12 py-3 bg-gradient-to-r from-purple-600 to-purple-500 text-white font-bold text-base rounded-lg hover:from-purple-700 hover:to-purple-600 transition disabled:opacity-70 shadow-lg"
                  >
                    {isSubmitting ? "Saving..." : isLast ? "Finish Setup" : "Next →"}
                  </button>
                </div>
              </Form>
            )}
          </Formik>
        </div>
      </div>
    </div>
  );
}