// routes/portfolio.js
import { Router } from 'express';
import { protect } from '../middleware/auth.js';
import { getMyPortfolio, updatePortfolio, getPublicPortfolio } from '../controllers/portfolioController.js';

const router = Router();

router.get('/me', protect, getMyPortfolio);
router.put('/me', protect, updatePortfolio);
router.get('/public/:username', getPublicPortfolio);

export default router;