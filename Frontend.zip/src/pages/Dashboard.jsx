import { useAuth } from '../context/AuthContext';
import { Eye, Palette, Settings, ArrowRight, TrendingUp, Globe, ExternalLink, Sparkles, Copy, Check } from 'lucide-react';
import { useState } from 'react';

export default function Dashboard() {
  const { user, portfolio } = useAuth();
  const [copied, setCopied] = useState(false);

  const portfolioUrl = `${window.location.origin}/${portfolio?.username}`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(portfolioUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const stats = [
    { 
      label: 'Portfolio Views', 
      value: portfolio?.analytics?.views || 0, 
      icon: Eye, 
      color: 'bg-blue-500',
      trend: portfolio?.analytics?.viewsTrend || '+0%'
    },
    { 
      label: 'Active Theme', 
      value: portfolio?.theme || 'Default', 
      icon: Palette, 
      color: 'bg-purple-500',
      subtitle: 'Current design'
    },
    { 
      label: 'Profile Status', 
      value: portfolio?.isPublic ? 'Live' : 'Private', 
      icon: Globe, 
      color: portfolio?.isPublic ? 'bg-green-500' : 'bg-gray-500',
      subtitle: portfolio?.isPublic ? 'Visible to everyone' : 'Only visible to you'
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="w-5 h-5 text-indigo-600" />
            <span className="text-sm font-medium text-gray-600">Dashboard</span>
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Welcome back, {user?.name?.split(' ')[0] || user?.username}
          </h1>
          <p className="text-gray-600">
            Manage your portfolio and track your performance
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <div
                key={index}
                className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className={`w-10 h-10 ${stat.color} rounded-lg flex items-center justify-center`}>
                    <Icon className="w-5 h-5 text-white" />
                  </div>
                  {stat.trend && (
                    <span className="text-xs font-medium text-green-600 bg-green-50 px-2 py-1 rounded">
                      {stat.trend}
                    </span>
                  )}
                </div>
                <p className="text-2xl font-bold text-gray-900 mb-1">{stat.value}</p>
                <p className="text-sm text-gray-600">{stat.label}</p>
                {stat.subtitle && (
                  <p className="text-xs text-gray-500 mt-1">{stat.subtitle}</p>
                )}
              </div>
            );
          })}
        </div>

        {/* Portfolio Link Card */}
        <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl p-6 mb-8 text-white">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h3 className="text-lg font-semibold mb-1">Your Portfolio Link</h3>
              <p className="text-indigo-100 text-sm">Share this link to showcase your work</p>
            </div>
            {portfolio?.isPublic && (
              <span className="bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-medium flex items-center gap-1">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                Live
              </span>
            )}
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 flex items-center justify-between">
            <div className="flex items-center gap-3 flex-1 min-w-0">
              <ExternalLink className="w-5 h-5 flex-shrink-0" />
              <span className="font-medium truncate">{portfolioUrl}</span>
            </div>
            <button
              onClick={handleCopyLink}
              className="ml-4 flex items-center gap-2 bg-white text-indigo-600 px-4 py-2 rounded-lg hover:bg-indigo-50 transition-colors font-medium text-sm flex-shrink-0"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4" />
                  Copied!
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  Copy Link
                </>
              )}
            </button>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="mb-8">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Quick Actions</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* View Portfolio */}
            <a
              href={`/${portfolio?.username}`}
              target="_blank"
              rel="noopener noreferrer"
              className="group bg-white border border-gray-200 rounded-xl p-6 hover:shadow-md hover:border-gray-300 transition-all"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <Eye className="w-6 h-6 text-green-600" />
                </div>
                <ArrowRight className="w-5 h-5 text-gray-400 group-hover:text-green-600 group-hover:translate-x-1 transition-all" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">View Portfolio</h3>
              <p className="text-sm text-gray-600">
                Preview your live portfolio and see how visitors will experience it
              </p>
            </a>

            {/* Change Theme */}
            <a
              href="/themes"
              className="group bg-white border border-gray-200 rounded-xl p-6 hover:shadow-md hover:border-gray-300 transition-all"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                  <Palette className="w-6 h-6 text-purple-600" />
                </div>
                <ArrowRight className="w-5 h-5 text-gray-400 group-hover:text-purple-600 group-hover:translate-x-1 transition-all" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Change Theme</h3>
              <p className="text-sm text-gray-600">
                Browse and activate professional themes to customize your portfolio
              </p>
            </a>

            {/* Settings */}
            <a
              href="/settings"
              className="group bg-white border border-gray-200 rounded-xl p-6 hover:shadow-md hover:border-gray-300 transition-all"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Settings className="w-6 h-6 text-blue-600" />
                </div>
                <ArrowRight className="w-5 h-5 text-gray-400 group-hover:text-blue-600 group-hover:translate-x-1 transition-all" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Settings</h3>
              <p className="text-sm text-gray-600">
                Manage your account, privacy settings, and portfolio preferences
              </p>
            </a>
          </div>
        </div>

        {/* Recent Activity */}
        {portfolio?.analytics?.recentViews && (
          <div className="bg-white border border-gray-200 rounded-xl p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Recent Activity</h2>
            <div className="space-y-3">
              {portfolio.analytics.recentViews.slice(0, 5).map((view, index) => (
                <div key={index} className="flex items-center justify-between py-2 border-b border-gray-100 last:border-0">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
                      <Eye className="w-4 h-4 text-gray-600" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-900">Portfolio viewed</p>
                      <p className="text-xs text-gray-500">{view.location || 'Unknown location'}</p>
                    </div>
                  </div>
                  <span className="text-xs text-gray-500">{view.time || 'Just now'}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}