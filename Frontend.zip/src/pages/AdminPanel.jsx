// src/pages/AdminPanel.jsx
import { useEffect, useState } from 'react';
import api from '../services/api';

export default function AdminPanel() {
  const [users, setUsers] = useState([]);
  const [themes, setThemes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const [usersRes, themesRes] = await Promise.all([
          api.get('/admin/users'),
          api.get('/admin/themes/prebuilt')
        ]);
        setUsers(usersRes.data.users);
        setThemes(themesRes.data.themes);
      } catch (err) {
        alert('Admin access required');
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  if (loading) return <div className="p-10 text-center text-xl">Loading admin data...</div>;

  return (
    <div className="p-6 lg:p-10">
      <h1 className="text-4xl font-bold mb-8">Admin Panel</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* Users */}
        <div className="bg-white rounded-3xl shadow-lg p-8">
          <h2 className="text-2xl font-bold mb-6">All Users ({users.length})</h2>
          <div className="space-y-4 max-h-96 overflow-y-auto">
            {users.map(u => (
              <div key={u._id} className="p-4 bg-gray-50 rounded-xl">
                <p className="font-semibold">{u.name} (@{u.username})</p>
                <p className="text-sm text-gray-600">{u.email}</p>
                <p className="text-sm">Views: {u.analytics?.views || 0} • {u.isPublic ? 'Public' : 'Private'}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Prebuilt Themes */}
        <div className="bg-white rounded-3xl shadow-lg p-8">
          <h2 className="text-2xl font-bold mb-6">Prebuilt Themes ({themes.length})</h2>
          <div className="space-y-4">
            {themes.map(t => (
              <div key={t._id} className="p-4 bg-gray-50 rounded-xl flex justify-between items-center">
                <div>
                  <p className="font-semibold">{t.name}</p>
                  <p className="text-sm text-gray-600">Used by {t.usedByCount} users</p>
                </div>
                <button className="text-red-600 hover:underline">Delete</button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}