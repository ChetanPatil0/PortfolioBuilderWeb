import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

import { toast } from 'react-toastify';
import api from '../../../services/api';

export default function AddNewTheme() {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    previewImage: '',
    thumbnail: '',
    category: 'all',
    tags: '',
    design: {
      palette: {
        mode: 'light',
        colors: {
          primary: '#6366f1',
          secondary: '#8b5cf6',
          accent: '#ec4899',
          text: { primary: '#111827', secondary: '#6b7280' },
          background: { default: '#ffffff', paper: '#f9fafb' }
        }
      },
      typography: {
        fontFamily: {
          heading: 'Inter, sans-serif',
          body: 'Inter, sans-serif'
        }
      },
      background: {
        type: 'solid',
        solid: '#ffffff'
      }
    },
    layoutConfig: {
      hero: 'fullscreen',
      projects: 'grid',
      skills: 'bars',
      experience: 'cards',
      contact: { enabled: true },
      navbar: { enabled: true },
      footer: { enabled: true }
    }
  });

  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;

    if (name.includes('.')) {
      const parts = name.split('.');
      if (parts.length === 2) {
        setFormData(prev => ({
          ...prev,
          [parts[0]]: {
            ...prev[parts[0]],
            [parts[1]]: value
          }
        }));
      } else if (parts.length === 3) {
        setFormData(prev => ({
          ...prev,
          [parts[0]]: {
            ...prev[parts[0]],
            [parts[1]]: {
              ...prev[parts[0]][parts[1]],
              [parts[2]]: value
            }
          }
        }));
      }
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const payload = {
        ...formData,
        tags: formData.tags.split(',').map(t => t.trim()).filter(t => t.length > 0)
      };

      await api.post('/admin/themes/prebuilt', payload);
      toast.success('New theme added successfully!');
      navigate('/admin/themes');
    } catch (err) {
      toast.error(err.message || 'Failed to add theme');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 lg:p-10">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-bold mb-8">Add New Prebuilt Theme</h1>

        <form onSubmit={handleSubmit} className="bg-white rounded-3xl shadow-2xl p-8 space-y-8">
          {/* Basic Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Theme Name *</label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:border-purple-500 transition"
                placeholder="e.g. Clean Professional"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
              <select
                name="category"
                value={formData.category}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:border-purple-500 transition"
              >
                <option value="all">All</option>
                <option value="developer">Developer</option>
                <option value="designer">Designer</option>
                <option value="photographer">Photographer</option>
                <option value="freelancer">Freelancer</option>
                <option value="minimal">Minimal</option>
                <option value="bold">Bold</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
            <textarea
              name="description"
              value={formData.description}
              onChange={handleChange}
              rows={3}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:border-purple-500 transition resize-none"
              placeholder="Brief description of the theme..."
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Preview Image URL *</label>
              <input
                type="url"
                name="previewImage"
                value={formData.previewImage}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:border-purple-500 transition"
                placeholder="https://example.com/preview.jpg"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Thumbnail URL (optional)</label>
              <input
                type="url"
                name="thumbnail"
                value={formData.thumbnail}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:border-purple-500 transition"
                placeholder="https://example.com/thumb.jpg"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Tags (comma separated)</label>
            <input
              type="text"
              name="tags"
              value={formData.tags}
              onChange={handleChange}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:border-purple-500 transition"
              placeholder="minimal, clean, professional, light"
            />
          </div>

          {/* Design Colors */}
          <div className="bg-gray-50 rounded-2xl p-6">
            <h3 className="text-xl font-bold mb-4">Design Colors</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Primary Color</label>
                <input
                  type="text"
                  name="design.palette.colors.primary"
                  value={formData.design.palette.colors.primary}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:border-purple-500 transition"
                  placeholder="#6366f1"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Secondary Color</label>
                <input
                  type="text"
                  name="design.palette.colors.secondary"
                  value={formData.design.palette.colors.secondary}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:border-purple-500 transition"
                  placeholder="#8b5cf6"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Accent Color</label>
                <input
                  type="text"
                  name="design.palette.colors.accent"
                  value={formData.design.palette.colors.accent}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:border-purple-500 transition"
                  placeholder="#ec4899"
                />
              </div>
            </div>
          </div>

          {/* Layout Config */}
          <div className="bg-gray-50 rounded-2xl p-6">
            <h3 className="text-xl font-bold mb-4">Layout Configuration</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Hero Style</label>
                <select
                  name="layoutConfig.hero"
                  value={formData.layoutConfig.hero}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:border-purple-500 transition"
                >
                  <option value="fullscreen">Full Screen</option>
                  <option value="split">Split</option>
                  <option value="centered">Centered</option>
                  <option value="minimal">Minimal</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Projects Layout</label>
                <select
                  name="layoutConfig.projects"
                  value={formData.layoutConfig.projects}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:border-purple-500 transition"
                >
                  <option value="grid">Grid</option>
                  <option value="masonry">Masonry</option>
                  <option value="carousel">Carousel</option>
                  <option value="horizontal">Horizontal Scroll</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Skills Style</label>
                <select
                  name="layoutConfig.skills"
                  value={formData.layoutConfig.skills}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:border-purple-500 transition"
                >
                  <option value="bars">Progress Bars</option>
                  <option value="circles">Circular</option>
                  <option value="grid">Grid Icons</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Contact Form</label>
                <select
                  name="layoutConfig.contact.enabled"
                  value={formData.layoutConfig.contact.enabled}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:border-purple-500 transition"
                >
                  <option value={true}>Enabled</option>
                  <option value={false}>Disabled</option>
                </select>
              </div>
            </div>
          </div>

          {/* Submit */}
          <div className="flex justify-end gap-4 pt-6">
            <button
              type="button"
              onClick={() => navigate('/admin/themes')}
              className="px-8 py-4 text-lg font-medium border-2 border-gray-300 rounded-xl hover:bg-gray-100 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-12 py-4 bg-gradient-to-r from-purple-600 to-purple-500 text-white font-bold text-lg rounded-xl hover:from-purple-700 hover:to-purple-600 transition disabled:opacity-70 shadow-xl"
            >
              {loading ? 'Adding Theme...' : 'Add Theme'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}