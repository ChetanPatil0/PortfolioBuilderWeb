
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const validationSchema = Yup.object({
  heading: Yup.string().required("Heading is required"),
  text: Yup.string()
    .min(30, "About section should be at least 30 characters long")
    .required("About description is required"),
  image: Yup.string().url("Image must be a valid URL").optional(),
  resumeDownload: Yup.string().url("Resume link must be a valid URL").optional(),
});

export default function AboutForm({ data = {}, onNext, onBack, isLast }) {
  const initialValues = {
    heading: data.about?.heading || "About Me",
    text: data.about?.text || "",
    image: data.about?.image || "",
    resumeDownload: data.about?.resumeDownload || "",
  };

  const handleSubmit = (values, { setSubmitting }) => {
    setTimeout(() => {
      onNext({ about: values });
      toast.success("About section saved!");
      setSubmitting(false);
    }, 600);
  };

  return (
    <div className="min-h-screen">
      <ToastContainer position="top-right" autoClose={3000} />

      <div className="bg-white rounded-3xl shadow-xl w-full max-w-4xl overflow-hidden">
        {/* Purple Header */}
        <div className="bg-gradient-to-r from-purple-600 to-purple-500 text-white font-bold py-4 text-center text-xl rounded-t-3xl">
          Tell us your story
        </div>

        <div className="p-4 lg:p-6">
          <Formik
            initialValues={initialValues}
            validationSchema={validationSchema}
            onSubmit={handleSubmit}
          >
            {({ isSubmitting }) => (
              <Form className="space-y-7">

                {/* Heading */}
                <div>
                  <label className="block text-gray-700 text-sm font-medium mb-2">
                    Section Heading <span className="text-red-500">*</span>
                  </label>
                  <Field
                    name="heading"
                    type="text"
                    placeholder="About Me"
                    className="w-full px-4 py-3 text-base border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500 transition"
                  />
                  <ErrorMessage name="heading" component="div" className="text-red-500 text-xs mt-1" />
                </div>

                {/* About Text */}
                <div>
                  <label className="block text-gray-700 text-sm font-medium mb-2">
                    About Description <span className="text-red-500">*</span>
                  </label>
                  <Field
                    as="textarea"
                    name="text"
                    rows={5}
                    placeholder="Tell your story..."
                    className="w-full px-4 py-3 text-base border border-gray-300 rounded-lg resize-none focus:outline-none focus:border-purple-500 transition"
                  />
                  <ErrorMessage name="text" component="div" className="text-red-500 text-xs mt-1" />
                </div>

                {/* Image + Resume URL */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  
                  <div>
                    <label className="block text-gray-700 text-sm font-medium mb-2">
                      Profile Image URL <span className="text-gray-400">(optional)</span>
                    </label>
                    <Field
                      name="image"
                      type="url"
                      placeholder="https://example.com/profile.jpg"
                      className="w-full px-4 py-3 text-base border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500 transition"
                    />
                    <ErrorMessage name="image" component="div" className="text-red-500 text-xs mt-1" />
                  </div>

                  <div>
                    <label className="block text-gray-700 text-sm font-medium mb-2">
                      Resume PDF URL <span className="text-gray-400">(optional)</span>
                    </label>
                    <Field
                      name="resumeDownload"
                      type="url"
                      placeholder="https://example.com/resume.pdf"
                      className="w-full px-4 py-3 text-base border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500 transition"
                    />
                    <ErrorMessage name="resumeDownload" component="div" className="text-red-500 text-xs mt-1" />
                  </div>

                </div>

                {/* Navigation Buttons */}
                <div className="flex justify-between items-center ">
                  <button
                    type="button"
                    onClick={onBack}
                    className="px-8 py-3 text-base font-medium text-gray-700 border-2 border-gray-300 rounded-lg hover:bg-gray-50 transition"
                  >
                    ← Back
                  </button>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-12 py-3 bg-gradient-to-r from-purple-600 to-purple-500 text-white font-bold text-base rounded-lg hover:from-purple-700 hover:to-purple-600 transition disabled:opacity-70 shadow-lg"
                  >
                    {isSubmitting ? "Saving..." : isLast ? "Finish Setup" : "Next →"}
                  </button>
                </div>

              </Form>
            )}
          </Formik>
        </div>
      </div>
    </div>
  );
}
